--
-- PostgreSQL database dump
--

\restrict MJAp0NMe0bdEs12dwVgiVIs7Qi3GPIQNfd2xfDyp90VhfdzLhp6dZE0uXqa3UJQ

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: bulk_add_note_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_add_note_tag(note_ids uuid[], tag_to_add text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_append(array_remove(tags, tag_to_add), tag_to_add)
  where id = any(note_ids);
$$;


--
-- Name: bulk_add_trade_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_add_trade_tag(trade_ids uuid[], tag_to_add text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_append(array_remove(tags, tag_to_add), tag_to_add)
  where id = any(trade_ids);
$$;


--
-- Name: bulk_remove_note_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_remove_note_tag(note_ids uuid[], tag_to_remove text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_remove(tags, tag_to_remove)
  where id = any(note_ids);
$$;


--
-- Name: bulk_remove_trade_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_remove_trade_tag(trade_ids uuid[], tag_to_remove text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_remove(tags, tag_to_remove)
  where id = any(trade_ids);
$$;


--
-- Name: bulk_rename_note_tag(uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_rename_note_tag(note_ids uuid[], tag_from text, tag_to text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_append(array_remove(array_remove(tags, tag_from), tag_to), tag_to)
  where id = any(note_ids);
$$;


--
-- Name: bulk_rename_trade_tag(uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_rename_trade_tag(trade_ids uuid[], tag_from text, tag_to text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_append(array_remove(array_remove(tags, tag_from), tag_to), tag_to)
  where id = any(trade_ids);
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    broker text,
    currency text DEFAULT 'USD'::text NOT NULL,
    is_demo boolean DEFAULT false NOT NULL,
    starting_balance numeric DEFAULT 0 NOT NULL,
    journal_start_date date DEFAULT CURRENT_DATE NOT NULL,
    target_risk_pct numeric,
    target_monthly_pnl numeric,
    target_monthly_winrate numeric,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_archived boolean DEFAULT false NOT NULL
);


--
-- Name: dropdown_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dropdown_settings (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    category text NOT NULL,
    value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dropdown_settings_category_check CHECK ((category = ANY (ARRAY['asset_class'::text, 'strategy'::text, 'session'::text, 'emotion'::text])))
);


--
-- Name: exness_contract_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exness_contract_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    symbol text NOT NULL,
    contract_size numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    title text DEFAULT 'Untitled'::text NOT NULL,
    content jsonb DEFAULT '{"type": "doc", "content": [{"type": "paragraph"}]}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    linked_trade_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    linked_strategy text
);


--
-- Name: trades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trades (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    entry_date date NOT NULL,
    instrument text NOT NULL,
    asset_class text,
    strategy text,
    session text,
    emotion text,
    direction text,
    entry_price numeric,
    exit_price numeric,
    size numeric,
    pnl numeric DEFAULT 0 NOT NULL,
    r_multiple numeric,
    rules_followed boolean,
    notes text,
    screenshot_url text,
    tags text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    stop_loss_price numeric,
    entry_time time without time zone,
    broker_ticket text,
    exit_date date,
    exit_time time without time zone,
    take_profit_price numeric,
    exit_reason text,
    sl_movement text,
    tp_movement text,
    screenshot_file_id text,
    CONSTRAINT trades_direction_check CHECK ((direction = ANY (ARRAY['long'::text, 'short'::text]))),
    CONSTRAINT trades_exit_reason_check CHECK ((exit_reason = ANY (ARRAY['stop_loss'::text, 'take_profit'::text, 'manual'::text, 'other'::text]))),
    CONSTRAINT trades_sl_movement_check CHECK ((sl_movement = ANY (ARRAY['held'::text, 'tightened'::text, 'widened'::text]))),
    CONSTRAINT trades_tp_movement_check CHECK ((tp_movement = ANY (ARRAY['held'::text, 'tightened'::text, 'widened'::text])))
);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, name, broker, currency, is_demo, starting_balance, journal_start_date, target_risk_pct, target_monthly_pnl, target_monthly_winrate, created_at, is_archived) FROM stdin;
00000000-0000-0000-0000-000000000001	Demo account	Paper broker	USD	t	25000	2026-04-22	1	2150	55	2026-07-21 09:46:15.442403+00	f
e9cf9139-a1e0-4248-b458-3c90573a8681	DoubleBirr	Exness	USD	f	30	2026-07-27	15	30	70	2026-07-27 09:19:59.954008+00	f
b6d3186b-8e05-45e2-a325-33195c6b07ca	Test	\N	USD	f	290	2026-07-31	\N	\N	\N	2026-07-31 19:08:29.480825+00	f
fd86dcb8-0392-443b-8836-34aa2c69d6a7	2ndTest	Exness	USD	f	30	2026-08-08	\N	\N	\N	2026-08-08 18:02:32.235456+00	f
\.


--
-- Data for Name: dropdown_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dropdown_settings (id, account_id, category, value, sort_order, created_at) FROM stdin;
a67773e4-872f-4200-9a3b-cbc56108c94e	00000000-0000-0000-0000-000000000001	session	London	1	2026-07-21 09:46:15.442403+00
1450b3b8-3461-42ee-98ce-ae4ca6e1f8c0	00000000-0000-0000-0000-000000000001	session	New York	2	2026-07-21 09:46:15.442403+00
adef61dc-69db-4a84-a9ab-9b7df0f3c9e1	00000000-0000-0000-0000-000000000001	session	Asia	3	2026-07-21 09:46:15.442403+00
43dbb37a-a1fc-4bd6-83ab-4681a0b8c4dd	00000000-0000-0000-0000-000000000001	emotion	Calm	1	2026-07-21 09:46:15.442403+00
c03b3710-016b-49e4-b320-8df9f8e57847	00000000-0000-0000-0000-000000000001	emotion	Confident	2	2026-07-21 09:46:15.442403+00
baad954f-741a-4914-8729-9b5a5be4ec75	00000000-0000-0000-0000-000000000001	emotion	Anxious	3	2026-07-21 09:46:15.442403+00
ff51bf6e-c038-4eb5-a435-2a8e178f9951	00000000-0000-0000-0000-000000000001	emotion	Impatient	4	2026-07-21 09:46:15.442403+00
3a64ade5-4801-4a51-a38a-54cb23cd7f46	00000000-0000-0000-0000-000000000001	strategy	Test strat	5	2026-07-21 15:24:05.545073+00
8833f635-d7f2-4607-a78d-7c372261950e	e9cf9139-a1e0-4248-b458-3c90573a8681	strategy	Trend following	4	2026-07-27 09:20:00.340429+00
0490637d-aed4-4d5a-a497-d4c22fbafc5d	00000000-0000-0000-0000-000000000001	strategy	Trend following	4	2026-07-21 09:46:15.442403+00
29fc6acf-dc48-4790-8add-ac0fbbd75343	00000000-0000-0000-0000-000000000001	strategy	Breakout	2	2026-07-23 18:46:21.131929+00
89e9eb0f-0d0e-4b51-8042-33530c9ffaac	00000000-0000-0000-0000-000000000001	strategy	Mean reversion	3	2026-07-21 09:46:15.442403+00
59b8caf7-d273-4011-8e54-1fe07a05eb98	b6d3186b-8e05-45e2-a325-33195c6b07ca	asset_class	Forex	1	2026-07-31 19:08:29.799318+00
9ee7c222-5ac3-445a-a4eb-d62591101729	b6d3186b-8e05-45e2-a325-33195c6b07ca	asset_class	Indices	2	2026-07-31 19:08:29.799318+00
9a0097f5-75e3-4e6c-9308-9520cad686a3	b6d3186b-8e05-45e2-a325-33195c6b07ca	asset_class	Crypto	3	2026-07-31 19:08:29.799318+00
9a40cb4a-8e08-4848-9d2a-775bd2bb7e4e	b6d3186b-8e05-45e2-a325-33195c6b07ca	strategy	Breakout	1	2026-07-31 19:08:29.799318+00
2ba9cc23-9731-457f-86f3-59894829b6c4	b6d3186b-8e05-45e2-a325-33195c6b07ca	strategy	Mean reversion	2	2026-07-31 19:08:29.799318+00
3349a710-09fb-4b75-a304-0a0b700397bc	b6d3186b-8e05-45e2-a325-33195c6b07ca	strategy	Trend following	3	2026-07-31 19:08:29.799318+00
ea1697d8-6813-425e-bf4e-37590c7c19cc	b6d3186b-8e05-45e2-a325-33195c6b07ca	session	London	1	2026-07-31 19:08:29.799318+00
b644c0a0-0596-4bbe-bb45-ba889771502c	b6d3186b-8e05-45e2-a325-33195c6b07ca	session	New York	2	2026-07-31 19:08:29.799318+00
80576ed3-adc0-41f2-97a1-7ce33c2cdb39	b6d3186b-8e05-45e2-a325-33195c6b07ca	session	Asia	3	2026-07-31 19:08:29.799318+00
a2c3e667-916c-461a-93b0-1ff6735cc271	b6d3186b-8e05-45e2-a325-33195c6b07ca	emotion	Calm	1	2026-07-31 19:08:29.799318+00
1828402d-a0ae-43d1-978d-2b791c05f125	b6d3186b-8e05-45e2-a325-33195c6b07ca	emotion	Confident	2	2026-07-31 19:08:29.799318+00
4e970b41-9eb4-4dba-bc8d-9645d030fc39	b6d3186b-8e05-45e2-a325-33195c6b07ca	emotion	Anxious	3	2026-07-31 19:08:29.799318+00
1f062003-1919-49c2-9fb4-1e95a118a716	b6d3186b-8e05-45e2-a325-33195c6b07ca	emotion	Impatient	4	2026-07-31 19:08:29.799318+00
a1bb9077-10b5-4c63-a9f5-a406396c737c	b6d3186b-8e05-45e2-a325-33195c6b07ca	strategy	Test_strat	4	2026-07-31 19:11:02.369116+00
f74c8fd7-ebf5-43b8-9af3-9c00d15166bd	b6d3186b-8e05-45e2-a325-33195c6b07ca	strategy	Strat2	5	2026-07-31 19:11:39.815918+00
27b4a593-1dd8-443b-888e-04f8468e3899	b6d3186b-8e05-45e2-a325-33195c6b07ca	asset_class	Metals	4	2026-08-01 09:08:25.962839+00
2250f4fa-da63-49fb-ac13-0331a8767d3c	e9cf9139-a1e0-4248-b458-3c90573a8681	asset_class	Forex	1	2026-07-27 09:20:00.340429+00
c1fb8efa-0c2b-4a60-b027-46b5ee060ad2	e9cf9139-a1e0-4248-b458-3c90573a8681	asset_class	Indices	2	2026-07-27 09:20:00.340429+00
6e0d97ff-30ed-4265-945b-de02d7f8df99	00000000-0000-0000-0000-000000000001	asset_class	Crypto	3	2026-07-21 09:46:15.442403+00
9a362cbf-fd1e-43b3-9964-b3b72aa5a3a0	e9cf9139-a1e0-4248-b458-3c90573a8681	asset_class	Crypto	3	2026-07-27 09:20:00.340429+00
28495160-5766-4885-a033-69ff8a83379c	00000000-0000-0000-0000-000000000001	asset_class	Indices	2	2026-07-21 09:46:15.442403+00
618b758b-577f-4d94-80f5-0589982e7e46	00000000-0000-0000-0000-000000000001	asset_class	Forex	1	2026-07-21 09:46:15.442403+00
145a30d1-3069-46e0-aa38-890463598d40	e9cf9139-a1e0-4248-b458-3c90573a8681	session	London	1	2026-07-27 09:20:00.340429+00
48db002c-39fa-4233-b302-08c2ff1a43b7	e9cf9139-a1e0-4248-b458-3c90573a8681	session	New York	2	2026-07-27 09:20:00.340429+00
e3134546-d66c-4db5-9ef8-ba838a518cc9	e9cf9139-a1e0-4248-b458-3c90573a8681	session	Asia	3	2026-07-27 09:20:00.340429+00
55b6c91d-bd62-4280-b2da-f85811f52a1b	e9cf9139-a1e0-4248-b458-3c90573a8681	asset_class	Commodity	4	2026-07-27 09:20:31.795052+00
4be100e6-9723-4ea7-a488-442ae4394840	e9cf9139-a1e0-4248-b458-3c90573a8681	asset_class	Metal	5	2026-07-27 09:20:40.356977+00
4dc58ba8-8f14-45df-b7eb-568fe0434fd1	e9cf9139-a1e0-4248-b458-3c90573a8681	strategy	Break & retest	2	2026-07-27 11:04:47.482489+00
e4fe05d8-21eb-4089-85ea-ff13e8578e4a	e9cf9139-a1e0-4248-b458-3c90573a8681	strategy	Mean reversion	3	2026-07-27 09:20:00.340429+00
dc3421d1-98ae-450f-a7c5-e532214d9df9	e9cf9139-a1e0-4248-b458-3c90573a8681	emotion	Impatient	5	2026-07-27 09:20:00.340429+00
8d65cc03-7afc-4f86-ac53-9b4cef9693a5	e9cf9139-a1e0-4248-b458-3c90573a8681	emotion	Anxious	4	2026-07-27 09:20:00.340429+00
4e0332ac-27e9-484c-adb9-f57156d54493	e9cf9139-a1e0-4248-b458-3c90573a8681	emotion	Confident	3	2026-07-27 09:20:00.340429+00
5706db9e-2a8d-4836-aecd-ad9f80a6e311	e9cf9139-a1e0-4248-b458-3c90573a8681	emotion	FOMO	1	2026-07-27 11:34:10.786824+00
496c6979-0086-486e-9334-3de77a7b0088	e9cf9139-a1e0-4248-b458-3c90573a8681	emotion	Calm	2	2026-07-27 09:20:00.340429+00
bf530b0f-e7e3-44f4-907d-6494c5f7a9c8	e9cf9139-a1e0-4248-b458-3c90573a8681	strategy	Stupid	5	2026-07-27 11:35:19.978186+00
1d717f6c-3e37-4732-92f3-77b71806315f	e9cf9139-a1e0-4248-b458-3c90573a8681	strategy	Scalp	6	2026-07-27 14:31:43.717184+00
78d7b03d-db1e-4eeb-91dc-de21bc362102	fd86dcb8-0392-443b-8836-34aa2c69d6a7	asset_class	Forex	1	2026-08-08 18:02:32.623975+00
b213cca5-cac5-4f03-9e43-32c6756efd8b	fd86dcb8-0392-443b-8836-34aa2c69d6a7	asset_class	Indices	2	2026-08-08 18:02:32.623975+00
9aeea829-cccf-433b-a696-a9d2370af7ce	fd86dcb8-0392-443b-8836-34aa2c69d6a7	asset_class	Crypto	3	2026-08-08 18:02:32.623975+00
a6156841-aaf6-4a4c-9765-bf28c71fd896	fd86dcb8-0392-443b-8836-34aa2c69d6a7	strategy	Breakout	1	2026-08-08 18:02:32.623975+00
fb5c3baf-3252-4a01-a125-53ede43793e6	fd86dcb8-0392-443b-8836-34aa2c69d6a7	strategy	Mean reversion	2	2026-08-08 18:02:32.623975+00
25b9de1e-5770-45ab-9e20-a09d04700595	fd86dcb8-0392-443b-8836-34aa2c69d6a7	strategy	Trend following	3	2026-08-08 18:02:32.623975+00
b9d81d9f-9e9b-4d16-bab9-8857892e68d3	fd86dcb8-0392-443b-8836-34aa2c69d6a7	session	London	1	2026-08-08 18:02:32.623975+00
2bc5bec8-372a-453b-8044-90a8b2d60dc3	fd86dcb8-0392-443b-8836-34aa2c69d6a7	session	New York	2	2026-08-08 18:02:32.623975+00
187f1d33-3a34-43ec-968a-201b7eb891fc	fd86dcb8-0392-443b-8836-34aa2c69d6a7	session	Asia	3	2026-08-08 18:02:32.623975+00
62310111-fe80-4e2e-b1b7-47159e6f4fd3	fd86dcb8-0392-443b-8836-34aa2c69d6a7	emotion	Calm	1	2026-08-08 18:02:32.623975+00
cbdb4464-68d8-4b13-a965-08f6835e36ac	fd86dcb8-0392-443b-8836-34aa2c69d6a7	emotion	Confident	2	2026-08-08 18:02:32.623975+00
b8ca57b6-9a4e-4b34-9177-673e22caa7db	fd86dcb8-0392-443b-8836-34aa2c69d6a7	emotion	Anxious	3	2026-08-08 18:02:32.623975+00
53a95a4a-b414-46be-9c7a-4489727eee6f	fd86dcb8-0392-443b-8836-34aa2c69d6a7	emotion	Impatient	4	2026-08-08 18:02:32.623975+00
\.


--
-- Data for Name: exness_contract_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exness_contract_overrides (id, account_id, symbol, contract_size, created_at, updated_at) FROM stdin;
9ab084bd-50c1-4f5d-850b-cd362d08d788	fd86dcb8-0392-443b-8836-34aa2c69d6a7	XAGUSD	5000	2026-08-09 06:44:49.344222+00	2026-08-09 06:44:49.112+00
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, account_id, title, content, created_at, updated_at, tags, linked_trade_ids, linked_strategy) FROM stdin;
678fe87d-f3a1-48d6-8fca-0abb1ea8ed82	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 13:14:13.202726+00	2026-08-07 13:14:13.202726+00	{}	{}	\N
3ecc1683-3f11-47ec-81d1-c0883ad71822	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:49:13.011+00	2026-08-07 14:49:13.011+00	{}	{}	\N
b4c83375-ea57-48a1-9261-61deabd10783	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:50:04.96975+00	2026-08-07 14:50:04.96975+00	{}	{}	\N
bc1bb058-7d52-4349-b4cc-7b720e9cc2b9	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 16:44:03.631032+00	2026-08-07 16:44:03.631032+00	{}	{}	\N
2837a1b5-c5bf-429b-9a66-76fe8dac06b5	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-08 06:38:07.173057+00	2026-08-08 06:38:12.681+00	{}	{}	\N
8e44bc5e-5cec-4ee6-aad4-1db99d9e3fea	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 17:51:02.954753+00	2026-08-07 17:51:12.969+00	{}	{}	\N
433112ce-c32e-404e-9764-68c4dcc1a68d	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 18:07:43.956665+00	2026-08-05 09:48:26.949+00	{}	{}	\N
72c721ac-73ac-4502-9e8a-cb1cb39826f2	b6d3186b-8e05-45e2-a325-33195c6b07ca	XAUUSD loss, Jul 29	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Hello", "type": "text", "marks": [{"type": "highlight", "attrs": {"color": "var(--highlight-yellow)"}}]}, {"text": " ", "type": "text"}]}]}	2026-08-09 21:17:18.799077+00	2026-08-09 21:18:02.457+00	{}	{ac201275-c414-440f-8807-4aa3cf7127c9}	\N
4371c81d-91bd-4c2b-8aa8-c0f6058d3afb	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:33.276211+00	2026-08-10 06:19:33.276211+00	{}	{}	\N
af8d6d6b-e468-428d-85af-f2b39d851a94	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:35.090156+00	2026-08-10 06:19:35.090156+00	{}	{}	\N
a2a5ee33-74e3-4d8b-b610-93fb6734a67e	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:36.609192+00	2026-08-10 06:19:36.609192+00	{}	{}	\N
ad5f555b-bf9e-44cb-aa5b-9b8136fbd5a0	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:38.595918+00	2026-08-10 06:19:38.595918+00	{}	{}	\N
6e38aee2-b448-4350-8970-28f1ab89ab5a	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:41.244546+00	2026-08-10 06:19:41.244546+00	{}	{}	\N
dbdd20f4-9995-480f-9132-785d7d0c9ead	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:42.755044+00	2026-08-10 06:19:42.755044+00	{}	{}	\N
047a09be-2cc9-44cc-8367-942bfa6fbfad	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:44.11375+00	2026-08-10 06:19:44.11375+00	{}	{}	\N
e646ce6e-5e3a-49f1-a0a1-d364139649a8	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:46.12542+00	2026-08-10 06:19:46.12542+00	{}	{}	\N
fd79e655-fc91-433d-aa5f-9437b8c507ce	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:53.072944+00	2026-08-10 06:19:53.072944+00	{}	{}	\N
85500b95-b3f9-4745-8069-87b74c99008e	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:54.592347+00	2026-08-10 06:19:54.592347+00	{}	{}	\N
e796e281-ad4e-4ac7-9113-05b661502460	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:55.972801+00	2026-08-10 06:19:55.972801+00	{}	{}	\N
cee485fc-0396-43b0-a364-db656877633f	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:57.330267+00	2026-08-10 06:19:57.330267+00	{}	{}	\N
d27b61b4-f7f5-4251-b208-957858242f65	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:19:58.753758+00	2026-08-10 06:19:58.753758+00	{}	{}	\N
dc49c064-c782-4b2a-a28b-a4b6eec56117	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:19 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:00.039893+00	2026-08-10 06:20:00.039893+00	{}	{}	\N
21bbad3d-5785-48b7-94a4-5a88be62e65a	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 13:13:21.784561+00	2026-08-07 13:13:21.784561+00	{}	{}	\N
1fb12451-5fae-4684-9b69-ba9cf5af6ae1	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:01.297359+00	2026-08-10 06:20:01.297359+00	{}	{}	\N
6603fd78-1f13-443a-9a7b-1905e1c07e74	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:02.596182+00	2026-08-10 06:20:02.596182+00	{}	{}	\N
d9605a1f-9ec7-4af0-bfbf-8dd39e8b30f4	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:03.880878+00	2026-08-10 06:20:03.880878+00	{}	{}	\N
c6bd2350-2b17-4e07-9794-5d39226e336a	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:05.354801+00	2026-08-10 06:20:05.354801+00	{}	{}	\N
63f58e89-0df1-47cd-8cae-d7bec1e5f275	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:07.543623+00	2026-08-10 06:20:07.543623+00	{}	{}	\N
7d17c897-d899-459a-b622-7c122352a5f3	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:55:46.611603+00	2026-08-04 17:55:46.611603+00	{}	{}	\N
c088fbb4-fbff-4ccb-a482-492814e06fa5	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:56:38.568545+00	2026-08-04 17:56:38.568545+00	{}	{}	\N
a6453e8b-fce5-433a-8883-5b8d96e37ef9	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:59:07.436136+00	2026-08-04 17:59:07.436136+00	{}	{}	\N
23a2b8d3-565b-43be-9ab8-62d561fea563	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:59:11.451497+00	2026-08-04 17:59:11.451497+00	{}	{}	\N
415b0ed3-4d4f-401f-b7ed-963374816593	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:59:17.052126+00	2026-08-04 17:59:17.052126+00	{}	{}	\N
81ff423a-91be-469d-ada7-e31dc3deeb7b	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:59:26.725182+00	2026-08-04 17:59:26.725182+00	{}	{}	\N
6d20e28a-d67d-4f19-bbe5-a2e09a24f191	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 17:59:34.083595+00	2026-08-04 17:59:34.083595+00	{}	{}	\N
3e07570b-0c33-489e-8ad2-57c31a5a4ab9	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 18:01:14.66772+00	2026-08-04 18:01:14.66772+00	{}	{}	\N
2130a38a-699a-4be0-b059-b46e7734b0f2	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 18:01:17.087609+00	2026-08-04 18:01:17.087609+00	{}	{}	\N
5c1871bd-0f88-40ba-be97-06eded62072f	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 18:06:54.798632+00	2026-08-04 18:06:54.798632+00	{}	{}	\N
9b05b102-e722-4313-ab49-49d325f4bb07	00000000-0000-0000-0000-000000000001	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-04 18:07:40.283588+00	2026-08-04 18:07:40.283588+00	{}	{}	\N
6f908765-247c-41b9-81ac-d0f1493567f7	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:09.097146+00	2026-08-10 06:20:09.097146+00	{}	{}	\N
4477bca3-6681-40d4-b7f8-c0c33ff39950	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:27:36.872784+00	2026-08-07 14:27:36.872784+00	{}	{}	\N
36c3b3e2-7495-408e-a3df-b9f77bfed2f8	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:49:20.834225+00	2026-08-07 14:49:20.834225+00	{}	{}	\N
cc5cc3c8-0d57-4f4d-ace0-29afe2f24c53	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:50:07.476611+00	2026-08-07 14:50:07.476611+00	{}	{}	\N
7c426251-988b-447b-ba5d-9c67e593bd57	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:50:12.662014+00	2026-08-07 14:50:12.662014+00	{}	{}	\N
836ef06a-5c41-437c-80e8-6b2c4af48522	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 14:50:38.465927+00	2026-08-07 14:50:38.465927+00	{}	{}	\N
1809ee67-9072-4b6a-94bd-8576449fba0f	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 17:02:09.175773+00	2026-08-07 17:02:09.175773+00	{}	{}	\N
e80bf48e-ecbe-4cb8-8235-d2829917b2e5	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 09:15:56.042865+00	2026-08-07 10:47:37.295+00	{}	{}	\N
31e30bb5-558a-4297-b5b8-2fbff6888598	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 13:13:17.644001+00	2026-08-07 13:13:17.644001+00	{}	{}	\N
7e28e742-7aff-4a8f-b846-e54403f2c764	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled2	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "T", "type": "text"}]}]}	2026-08-07 13:13:55.798951+00	2026-08-07 13:14:02.975+00	{}	{}	\N
3bb656a9-eee3-46e6-b270-c2995d6afe7e	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-08 10:10:17.717871+00	2026-08-08 10:10:17.717871+00	{}	{}	\N
7911ec39-a1b0-423d-a8db-b61ca3825d42	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 17:02:11.845725+00	2026-08-07 20:36:48.909+00	{}	{}	\N
b42b6fc3-d8d1-4365-bf94-3b09c5c7123d	b6d3186b-8e05-45e2-a325-33195c6b07ca	Untitled	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-07 20:36:09.648617+00	2026-08-07 20:36:38.094+00	{B}	{}	\N
b0c9a5f2-1eeb-4bff-844e-26154ea671cf	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:03.519795+00	2026-08-09 21:35:03.519795+00	{}	{}	\N
feebaaf6-2d7d-4c17-b08e-b6246303198f	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:06.375275+00	2026-08-09 21:35:06.375275+00	{}	{}	\N
5690e042-d818-4ba4-a4f2-8f277b7fc31f	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:09.166883+00	2026-08-09 21:35:09.166883+00	{}	{}	\N
d9fea834-e401-428a-af6f-58769e19f3e3	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:11.432557+00	2026-08-09 21:35:11.432557+00	{}	{}	\N
e87590f9-38e1-4c06-bb02-a05d99ada5b9	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:13.003003+00	2026-08-09 21:35:13.003003+00	{}	{}	\N
f68c7645-528c-4e0d-adae-becef5bfd3ca	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:14.557044+00	2026-08-09 21:35:14.557044+00	{}	{}	\N
d483adee-8f86-453c-ba05-d5b8a915e2c4	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:16.362802+00	2026-08-09 21:35:16.362802+00	{}	{}	\N
a553b174-348c-4962-b362-504cf1cc4dd7	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:18.13028+00	2026-08-09 21:35:18.13028+00	{}	{}	\N
73785181-2394-4015-b81b-94e4442e4286	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:19.569536+00	2026-08-09 21:35:19.569536+00	{}	{}	\N
cfddde1e-5b4c-4632-958e-71f3f197307f	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:21.083445+00	2026-08-09 21:35:21.083445+00	{}	{}	\N
5fbcf628-9a92-4506-8c39-9ee09e2c230b	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:22.682127+00	2026-08-09 21:35:22.682127+00	{}	{}	\N
6ba86480-3087-4c07-b94d-967ebe1f8f9a	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 12:35 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-09 21:35:24.134831+00	2026-08-09 21:35:24.134831+00	{}	{}	\N
887331a9-8840-4106-9999-2af68badf2e8	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 9:20 AM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 06:20:10.617879+00	2026-08-10 06:20:10.617879+00	{}	{}	\N
e95cceaf-08b6-4592-a39a-f8bb51f3c2f4	b6d3186b-8e05-45e2-a325-33195c6b07ca	EURUSD win, Aug 10	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 13:17:43.550491+00	2026-08-10 13:17:57.835+00	{}	{862cba52-6b26-4929-b489-fdb94bf5b39b,0b62cdcf-709d-44a9-8649-f47941c1b390}	\N
034b549a-0c7f-4255-a084-4ae9f00df030	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 4:17 PM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Test me", "type": "text"}]}]}	2026-08-10 13:17:14.927993+00	2026-08-10 13:19:47.642+00	{}	{0b62cdcf-709d-44a9-8649-f47941c1b390,f685be8d-d2ef-410c-8888-d2cde75b8e13,167ec9b5-49a4-4abd-998d-91b3af3acd96,862cba52-6b26-4929-b489-fdb94bf5b39b}	\N
a1136a1b-5c56-4503-bf06-d45f4cb58e4a	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 4:23 PM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 13:23:04.817966+00	2026-08-10 13:23:04.817966+00	{}	{}	\N
907492ae-3b3b-4ca4-b030-6483e34cb24e	b6d3186b-8e05-45e2-a325-33195c6b07ca	Aug 10, 2026 — 4:34 PM	{"type": "doc", "content": [{"type": "paragraph"}]}	2026-08-10 13:34:24.33048+00	2026-08-10 13:34:24.33048+00	{}	{}	\N
\.


--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trades (id, account_id, entry_date, instrument, asset_class, strategy, session, emotion, direction, entry_price, exit_price, size, pnl, r_multiple, rules_followed, notes, screenshot_url, tags, created_at, stop_loss_price, entry_time, broker_ticket, exit_date, exit_time, take_profit_price, exit_reason, sl_movement, tp_movement, screenshot_file_id) FROM stdin;
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: dropdown_settings dropdown_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dropdown_settings
    ADD CONSTRAINT dropdown_settings_pkey PRIMARY KEY (id);


--
-- Name: exness_contract_overrides exness_contract_overrides_account_id_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_account_id_symbol_key UNIQUE (account_id, symbol);


--
-- Name: exness_contract_overrides exness_contract_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (id);


--
-- Name: accounts_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_name_unique ON public.accounts USING btree (lower(name));


--
-- Name: exness_contract_overrides_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exness_contract_overrides_account_idx ON public.exness_contract_overrides USING btree (account_id);


--
-- Name: notes_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_account_idx ON public.notes USING btree (account_id);


--
-- Name: notes_linked_trade_ids_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_linked_trade_ids_idx ON public.notes USING gin (linked_trade_ids);


--
-- Name: notes_tags_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_tags_idx ON public.notes USING gin (tags);


--
-- Name: notes_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_updated_idx ON public.notes USING btree (account_id, updated_at DESC);


--
-- Name: trades_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_account_idx ON public.trades USING btree (account_id);


--
-- Name: trades_broker_ticket_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_broker_ticket_idx ON public.trades USING btree (account_id, broker_ticket);


--
-- Name: trades_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_date_idx ON public.trades USING btree (entry_date);


--
-- Name: dropdown_settings dropdown_settings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dropdown_settings
    ADD CONSTRAINT dropdown_settings_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: exness_contract_overrides exness_contract_overrides_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: notes notes_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: trades trades_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts authenticated read/write accounts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write accounts" ON public.accounts USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: dropdown_settings authenticated read/write dropdown_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write dropdown_settings" ON public.dropdown_settings USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: exness_contract_overrides authenticated read/write exness_contract_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write exness_contract_overrides" ON public.exness_contract_overrides USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: notes authenticated read/write notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write notes" ON public.notes USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: trades authenticated read/write trades; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write trades" ON public.trades USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: dropdown_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dropdown_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: exness_contract_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.exness_contract_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: trades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict MJAp0NMe0bdEs12dwVgiVIs7Qi3GPIQNfd2xfDyp90VhfdzLhp6dZE0uXqa3UJQ

