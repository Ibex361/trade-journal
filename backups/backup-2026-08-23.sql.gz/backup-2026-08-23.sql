--
-- PostgreSQL database dump
--

\restrict 0XNGeJhDs6zaxblH7cTiXbvBnz09AwVygCaF8sb7ItaGVk41YIfJSkxcvnL1DYb

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: bulk_add_note_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_add_note_tag(note_ids uuid[], tag_to_add text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_append(array_remove(tags, tag_to_add), tag_to_add)
  where id = any(note_ids);
$$;


--
-- Name: bulk_add_trade_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_add_trade_tag(trade_ids uuid[], tag_to_add text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_append(array_remove(tags, tag_to_add), tag_to_add)
  where id = any(trade_ids);
$$;


--
-- Name: bulk_remove_note_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_remove_note_tag(note_ids uuid[], tag_to_remove text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_remove(tags, tag_to_remove)
  where id = any(note_ids);
$$;


--
-- Name: bulk_remove_trade_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_remove_trade_tag(trade_ids uuid[], tag_to_remove text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_remove(tags, tag_to_remove)
  where id = any(trade_ids);
$$;


--
-- Name: bulk_rename_note_tag(uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_rename_note_tag(note_ids uuid[], tag_from text, tag_to text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_append(array_remove(array_remove(tags, tag_from), tag_to), tag_to)
  where id = any(note_ids);
$$;


--
-- Name: bulk_rename_trade_tag(uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_rename_trade_tag(trade_ids uuid[], tag_from text, tag_to text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_append(array_remove(array_remove(tags, tag_from), tag_to), tag_to)
  where id = any(trade_ids);
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    broker text,
    currency text DEFAULT 'USD'::text NOT NULL,
    is_demo boolean DEFAULT false NOT NULL,
    starting_balance numeric DEFAULT 0 NOT NULL,
    journal_start_date date DEFAULT CURRENT_DATE NOT NULL,
    target_risk_pct numeric,
    target_monthly_pnl numeric,
    target_monthly_winrate numeric,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_archived boolean DEFAULT false NOT NULL
);


--
-- Name: chart_symbol_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_symbol_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    symbol text NOT NULL,
    twelve_data_symbol text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dropdown_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dropdown_settings (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    category text NOT NULL,
    value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dropdown_settings_category_check CHECK ((category = ANY (ARRAY['asset_class'::text, 'strategy'::text, 'session'::text, 'emotion'::text])))
);


--
-- Name: exness_contract_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exness_contract_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    symbol text NOT NULL,
    contract_size numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    title text DEFAULT 'Untitled'::text NOT NULL,
    content jsonb DEFAULT '{"type": "doc", "content": [{"type": "paragraph"}]}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    linked_trade_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    linked_strategy text
);


--
-- Name: trades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trades (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    entry_date date NOT NULL,
    instrument text NOT NULL,
    asset_class text,
    strategy text,
    session text,
    emotion text,
    direction text,
    entry_price numeric,
    exit_price numeric,
    size numeric,
    pnl numeric DEFAULT 0 NOT NULL,
    r_multiple numeric,
    rules_followed boolean,
    notes text,
    screenshot_url text,
    tags text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    stop_loss_price numeric,
    entry_time time without time zone,
    broker_ticket text,
    exit_date date,
    exit_time time without time zone,
    take_profit_price numeric,
    exit_reason text,
    sl_movement text,
    tp_movement text,
    screenshot_file_id text,
    CONSTRAINT trades_direction_check CHECK ((direction = ANY (ARRAY['long'::text, 'short'::text]))),
    CONSTRAINT trades_exit_reason_check CHECK ((exit_reason = ANY (ARRAY['stop_loss'::text, 'take_profit'::text, 'manual'::text, 'other'::text]))),
    CONSTRAINT trades_sl_movement_check CHECK ((sl_movement = ANY (ARRAY['held'::text, 'tightened'::text, 'widened'::text]))),
    CONSTRAINT trades_tp_movement_check CHECK ((tp_movement = ANY (ARRAY['held'::text, 'tightened'::text, 'widened'::text])))
);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, name, broker, currency, is_demo, starting_balance, journal_start_date, target_risk_pct, target_monthly_pnl, target_monthly_winrate, created_at, is_archived) FROM stdin;
adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	Test	\N	USD	f	0	2026-08-11	\N	\N	\N	2026-08-11 10:58:02.945735+00	f
40f6a8ae-bc42-4397-8988-577d9373e75c	DoubleBirr	\N	USD	f	30	2026-08-14	\N	\N	\N	2026-08-14 10:17:24.141667+00	f
00000000-0000-0000-0000-000000000001	Demo account	Paper broker	USD	t	25000	2026-04-22	1	2150	55	2026-07-21 09:46:15.442403+00	f
\.


--
-- Data for Name: chart_symbol_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_symbol_overrides (id, account_id, symbol, twelve_data_symbol, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dropdown_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dropdown_settings (id, account_id, category, value, sort_order, created_at) FROM stdin;
d180500c-3928-4e6d-8ed4-d45c0544790d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	asset_class	Forex	1	2026-08-11 10:58:03.257114+00
a67773e4-872f-4200-9a3b-cbc56108c94e	00000000-0000-0000-0000-000000000001	session	London	1	2026-07-21 09:46:15.442403+00
1450b3b8-3461-42ee-98ce-ae4ca6e1f8c0	00000000-0000-0000-0000-000000000001	session	New York	2	2026-07-21 09:46:15.442403+00
adef61dc-69db-4a84-a9ab-9b7df0f3c9e1	00000000-0000-0000-0000-000000000001	session	Asia	3	2026-07-21 09:46:15.442403+00
43dbb37a-a1fc-4bd6-83ab-4681a0b8c4dd	00000000-0000-0000-0000-000000000001	emotion	Calm	1	2026-07-21 09:46:15.442403+00
c03b3710-016b-49e4-b320-8df9f8e57847	00000000-0000-0000-0000-000000000001	emotion	Confident	2	2026-07-21 09:46:15.442403+00
baad954f-741a-4914-8729-9b5a5be4ec75	00000000-0000-0000-0000-000000000001	emotion	Anxious	3	2026-07-21 09:46:15.442403+00
ff51bf6e-c038-4eb5-a435-2a8e178f9951	00000000-0000-0000-0000-000000000001	emotion	Impatient	4	2026-07-21 09:46:15.442403+00
681f7159-f15b-41ff-a431-f30dc07d7e1a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	asset_class	Indices	2	2026-08-11 10:58:03.257114+00
3a64ade5-4801-4a51-a38a-54cb23cd7f46	00000000-0000-0000-0000-000000000001	strategy	Test strat	5	2026-07-21 15:24:05.545073+00
3236341d-e3de-4170-b729-04d356208c22	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	asset_class	Crypto	3	2026-08-11 10:58:03.257114+00
0490637d-aed4-4d5a-a497-d4c22fbafc5d	00000000-0000-0000-0000-000000000001	strategy	Trend following	4	2026-07-21 09:46:15.442403+00
29fc6acf-dc48-4790-8add-ac0fbbd75343	00000000-0000-0000-0000-000000000001	strategy	Breakout	2	2026-07-23 18:46:21.131929+00
89e9eb0f-0d0e-4b51-8042-33530c9ffaac	00000000-0000-0000-0000-000000000001	strategy	Mean reversion	3	2026-07-21 09:46:15.442403+00
c4820b79-d1f4-4eea-991b-512d5031c292	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	strategy	Breakout	1	2026-08-11 10:58:03.257114+00
dab239cd-c503-4f66-ac05-564e2eeff8a0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	strategy	Mean reversion	2	2026-08-11 10:58:03.257114+00
0bf410e9-5c5d-4d21-b0dd-e724e68ae789	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	strategy	Trend following	3	2026-08-11 10:58:03.257114+00
1eba9c18-6246-4188-92ca-3b2d1b4ef86b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	session	London	1	2026-08-11 10:58:03.257114+00
3f411feb-53dd-4932-abff-d2addee7de72	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	session	New York	2	2026-08-11 10:58:03.257114+00
ef5f4868-ed64-4696-a9fb-ce4415124704	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	session	Asia	3	2026-08-11 10:58:03.257114+00
510cb5a3-5e46-46de-b8e5-6886a746660c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Calm	1	2026-08-11 10:58:03.257114+00
5f4dadc1-e0ad-4e86-affb-ba35e8eca962	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Confident	2	2026-08-11 10:58:03.257114+00
475ee832-949f-409f-8178-2e2259c59140	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Anxious	3	2026-08-11 10:58:03.257114+00
d1d57019-0102-429e-a5e7-d349c6c932d6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Impatient	4	2026-08-11 10:58:03.257114+00
6e0d97ff-30ed-4265-945b-de02d7f8df99	00000000-0000-0000-0000-000000000001	asset_class	Crypto	3	2026-07-21 09:46:15.442403+00
28495160-5766-4885-a033-69ff8a83379c	00000000-0000-0000-0000-000000000001	asset_class	Indices	2	2026-07-21 09:46:15.442403+00
618b758b-577f-4d94-80f5-0589982e7e46	00000000-0000-0000-0000-000000000001	asset_class	Forex	1	2026-07-21 09:46:15.442403+00
9b1303c3-349e-41a2-922e-fb9577b9c748	40f6a8ae-bc42-4397-8988-577d9373e75c	asset_class	Forex	1	2026-08-14 10:17:24.465091+00
e6c3e775-837e-4ae2-8e6a-fc52e5db2d91	40f6a8ae-bc42-4397-8988-577d9373e75c	asset_class	Indices	2	2026-08-14 10:17:24.465091+00
97b676ff-e39e-4c4c-af4e-9cd4dd076f98	40f6a8ae-bc42-4397-8988-577d9373e75c	asset_class	Crypto	3	2026-08-14 10:17:24.465091+00
40c2e680-6d42-47ce-bb6f-3dd49c2c35ee	40f6a8ae-bc42-4397-8988-577d9373e75c	strategy	Breakout	1	2026-08-14 10:17:24.465091+00
f86124f2-c469-4c6b-adba-0544c93bbed1	40f6a8ae-bc42-4397-8988-577d9373e75c	strategy	Mean reversion	2	2026-08-14 10:17:24.465091+00
a41587fd-8a59-4438-a248-06d71a9c706c	40f6a8ae-bc42-4397-8988-577d9373e75c	strategy	Trend following	3	2026-08-14 10:17:24.465091+00
d7ec426d-de2d-43bb-872e-dc98abcbe7b2	40f6a8ae-bc42-4397-8988-577d9373e75c	session	London	1	2026-08-14 10:17:24.465091+00
51eb8327-586c-4fc6-bb8d-b29e8d49a74f	40f6a8ae-bc42-4397-8988-577d9373e75c	session	New York	2	2026-08-14 10:17:24.465091+00
aac1b5b6-b6cd-476c-819b-ed505022ecca	40f6a8ae-bc42-4397-8988-577d9373e75c	session	Asia	3	2026-08-14 10:17:24.465091+00
43a73411-797b-4e71-af10-e69f15beaa4f	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Calm	1	2026-08-14 10:17:24.465091+00
793e4089-eac2-4301-b087-ebb9f43920b2	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Confident	2	2026-08-14 10:17:24.465091+00
e5883048-1b05-4cc2-8cc0-45dd15707875	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Anxious	3	2026-08-14 10:17:24.465091+00
f99de760-369c-4593-bc2a-f8ed6ef55e07	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Impatient	4	2026-08-14 10:17:24.465091+00
\.


--
-- Data for Name: exness_contract_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exness_contract_overrides (id, account_id, symbol, contract_size, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, account_id, title, content, created_at, updated_at, tags, linked_trade_ids, linked_strategy) FROM stdin;
6db23ba6-a28a-4a7d-8ee7-f959399dff94	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	Aug 12, 2026 — 10:50 AM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Extended Standard Paragraph", "type": "text"}]}, {"type": "paragraph"}, {"type": "paragraph", "content": [{"text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", "type": "text"}]}]}	2026-08-12 07:50:55.072619+00	2026-08-12 07:54:41.002+00	{}	{}	\N
14fe8a76-e475-426d-99c5-ece1d2bef65d	00000000-0000-0000-0000-000000000001	Aug 12, 2026 — 10:50 AM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Extended Standard Paragraph", "type": "text"}]}, {"type": "paragraph"}, {"type": "paragraph", "content": [{"text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", "type": "text"}]}]}	2026-08-12 07:50:55.072619+00	2026-08-12 07:54:41.002+00	{}	{}	\N
3e5d4f6b-f2bd-4ef2-8084-e97f3b1880df	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	Aug 12, 2026 — 10:50 AM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Test it.", "type": "text"}]}, {"type": "paragraph"}, {"type": "paragraph", "content": [{"text": "hint: Updates were rejected because the remote contains work that you do not", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: have locally. This is usually caused by another repository pushing to", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: the same ref. If you want to integrate the remote changes, use", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: 'git pull' before pushing again.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: See the 'Note about fast-forwards' in 'git push --help' for details.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "~/.../dev/trade-journal $ git pull", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Enumerating objects: 4, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Counting objects: 100% (4/4), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Compressing objects: 100% (3/3), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Total 4 (delta 1), reused 4 (delta 1), pack-reused 0 (from 0)", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Unpacking objects: 100% (4/4), 8.46 KiB | 50.00 KiB/s, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "From https://github.com/Ibex361/trade-journal", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "   755e281..52c30f9  main       -> origin/main", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Merge made by the 'ort' strategy.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "y backups/backup-2026-08-11.sql.gz | Bin 8340 -> 8336 bytes", "type": "text"}]}, {"type": "paragraph", "content": [{"text": " 1 file changed, 0 insertions(+), 0 deletions(-)", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "~/.../dev/trade-journal $ git push", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Enumerating objects: 35, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Counting objects: 100% (27/27), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Delta compression using up to 8 threads", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Compressing objects: 100% (16/16), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Writing objects: 100% (17/17), 11.32 KiB | 282.00 KiB/s, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Total 17 (delta 9), reused 0 (delta 0), pack-reused 0 (from 0)", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Resolving deltas: 100% (9/9), completed with 8 local objects.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "To https://github.com/Ibex361/trade-journal.git", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "   52c30f9..fcaa855  main -> main", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "~/.../dev/trade-journal $ cd ~/storage/downloads                               ~/storage/downloads $ nano test-all-trades-2026-08-                            test-all-trades-2026-08-02-1.csv  test-all-trades-2026-08-10.csv", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "test-all-trades-2026-08-02.csv    test-all-trades-2026-08-12.csv", "type": "text"}]}]}	2026-08-12 07:50:55.072619+00	2026-08-12 07:53:05.326+00	{}	{}	\N
\.


--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trades (id, account_id, entry_date, instrument, asset_class, strategy, session, emotion, direction, entry_price, exit_price, size, pnl, r_multiple, rules_followed, notes, screenshot_url, tags, created_at, stop_loss_price, entry_time, broker_ticket, exit_date, exit_time, take_profit_price, exit_reason, sl_movement, tp_movement, screenshot_file_id) FROM stdin;
42dd0f82-bfa9-4d70-8c18-c157a092b4d0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4115.983	4111.545	1	-4.44	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4111.545	04:27:06	3016500000	2026-07-29	04:27:11	4123.235	stop_loss	\N	\N	\N
1b93524f-d85f-4bd2-9fd2-1f8a5145b492	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4091.594	4089.298	1	2.3	0.4512578616352977	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.682	03:38:59	3016488516	2026-07-29	03:46:55	4089.298	take_profit	\N	\N	\N
9ed025af-0e5a-456b-ad41-447a20cdc30b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4049.329	4053.745	1	4.42	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	02:46:05	3016479490	2026-07-29	02:52:49	\N	take_profit	\N	\N	\N
856f4cd8-1f02-4d2e-9fe6-122fff69430c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	XAUUSD	Metals	\N	\N	\N	short	4118.891	4117.909	1	0.98	0.18058109599116448	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4124.329	05:37:04	3016477130	2026-07-28	05:37:21	4114.417	manual	\N	\N	\N
b1265925-6b47-4ae1-a72b-8f7545714659	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	XAUUSD	Metals	\N	\N	\N	long	4123.996	4120.704	1	-3.29	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4120.704	04:52:50	3016464703	2026-07-28	04:54:27	4126.626	stop_loss	\N	\N	\N
99593009-36b2-4c3d-9d24-bd8c97e63db0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	XAUUSD	Metals	\N	\N	\N	short	4108.117	4100.966	2	14.3	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	04:51:50	3016462040	2026-07-28	04:55:49	4106.68	manual	\N	\N	\N
484a41bb-176f-404a-a425-e5ad5f610386	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4120.759	4117.892	5	14.34	2.458833619210787	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4121.925	11:03:34	3016459162	2026-07-27	11:45:48	4117.892	take_profit	\N	\N	\N
47a2e7eb-f051-4e18-a737-aecd329f9600	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4117.705	4120.409	1	2.7	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	11:02:09	3016456272	2026-07-27	11:02:39	\N	stop_loss	\N	\N	\N
60c16fb7-c7e8-4de0-a281-2e552696074e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4046.059	4040.82	1	-5.24	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4040.82	10:40:34	3016449939	2026-07-27	11:40:10	\N	stop_loss	\N	\N	\N
3f02ad1d-5f6b-45eb-9493-bb6b9ec6f31b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4111.975	4114.305	1	2.33	0.45085139318879025	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4106.807	10:40:00	3016442717	2026-07-27	11:39:31	4114.305	take_profit	\N	\N	\N
42434403-5b28-40b2-a3fc-6e076bf5922f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	BTCUSD	Crypto	\N	\N	\N	short	65070.26	65074.26	0.05	-0.2	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	10:32:10	3016436615	2026-07-27	10:47:03	\N	manual	\N	\N	\N
c1a92487-61ec-4938-a420-3cd5b283f5ec	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4066.018	4072.144	1	6.13	1.6862097440132309	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4062.385	10:30:26	3016433169	2026-07-27	10:30:56	4072.144	take_profit	\N	\N	\N
43d79660-67ab-4d44-bd47-8898e7faa7be	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4093.105	4088.089	1	5.02	5.579532814238827	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4094.004	09:40:34	3016425699	2026-07-27	09:50:19	4088.089	take_profit	\N	\N	\N
29ae21c7-57cf-4693-9c8f-89ce3ac8e46f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4114.305	4111.048	2	6.51	0.7949719306811602	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4118.402	09:38:19	3016422318	2026-07-27	09:44:00	4113.433	manual	\N	\N	\N
6615baf0-640c-4cb4-9341-f8900a9541a3	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4078.628	4085.263	1	6.63	8.517329910140942	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4077.849	09:37:31	3016418778	2026-07-27	09:43:59	4085.263	take_profit	\N	\N	\N
a62832c0-5d8e-4bb8-b61c-4e9e051d95b7	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4055.599	4050.245	1	5.35	4.457951706911051	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4056.8	09:09:45	3016416458	2026-07-27	09:10:43	\N	take_profit	\N	\N	\N
cdb2e2a0-4681-487f-82c0-3434a8b19896	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4114.938	4109.966	2	9.94	1.0925071412877005	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4119.489	08:40:20	3016415120	2026-07-27	09:06:25	\N	take_profit	\N	\N	\N
88b016a7-cc43-45a5-9e07-d04d2e98a2cc	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4028.916	4033.382	2	8.93	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:17:08	3016411232	2026-07-27	08:26:06	4033.382	take_profit	\N	\N	\N
82745480-e65b-4e54-ab98-5814592123b5	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4014.994	4005.139	5	49.28	3.398275862069398	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4017.894	08:11:23	3016402822	2026-07-27	08:11:34	4005.139	take_profit	\N	\N	\N
fd77e9ed-458e-4ab1-8298-103dcf5405e0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4009.097	4003.091	1	-6.01	-1.4409788867562716	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4004.929	07:49:00	3016395869	2026-07-27	08:02:38	4012.898	manual	\N	\N	\N
c90345a2-ebc8-409a-a271-13b2f27a365c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4039.123	4043.695	1	4.57	1.56040955631412	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4036.193	07:30:55	3016391179	2026-07-27	07:31:15	\N	manual	\N	\N	\N
355e4f35-d048-4ea4-950f-5ee3ef00506e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4123.76	4131.021	1	-7.26	-1.536069388618516	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4128.487	06:31:44	3016387499	2026-07-27	06:31:54	4118.77	manual	\N	\N	\N
8bbc7e59-291c-4e42-ad14-595b2db83eac	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4111.857	4113.773	2	3.83	0.34547421565093256	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4106.311	06:27:25	3016379554	2026-07-27	06:34:09	4113.773	take_profit	\N	\N	\N
6c579c0f-35b9-4984-9762-4d08992342ba	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4071.223	4068.222	2	6	0.9481832543443234	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4074.388	05:30:52	3016371106	2026-07-27	05:41:32	4068.222	take_profit	\N	\N	\N
6b9c71f0-81a3-486b-928b-48e8d1607cb0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAGUSD	Metals	\N	\N	\N	long	56.463	51.382	0.01	-254.05	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	51.382	05:25:00	3016366347	2026-07-27	05:26:09	\N	stop_loss	\N	\N	\N
04ba7d01-28be-4024-8cba-c5999a0015fd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4050.698	4044.333	1	6.36	2.0072532324185515	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4053.869	05:23:40	3016363727	2026-07-27	05:35:51	\N	take_profit	\N	\N	\N
c2d93d8c-1047-4b49-aec6-56cce2627fc3	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAGUSD	Metals	\N	\N	\N	long	57.184	57.294	0.05	27.5	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	04:29:14	3016360881	2026-07-27	04:29:50	\N	take_profit	\N	\N	\N
08529a27-5475-4630-b791-2e00cc440eff	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	BTCUSD	Crypto	\N	\N	\N	short	63663.81	63793.22	0.01	-1.29	-193.14925372975438	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	63664.48	04:22:40	3016357388	2026-07-27	04:22:43	\N	manual	\N	\N	\N
de498289-81c8-41b3-8aa1-30520298d9ab	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4028.335	4035.755	1	7.42	5.296216987866467	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4026.934	04:21:20	3016354171	2026-07-27	04:22:55	4031.997	manual	\N	\N	\N
4db88acc-f2ce-49d0-ab21-4b940747f278	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4100.423	4109.039	1	8.62	3.6247370635262115	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4098.046	04:20:31	3016346680	2026-07-27	04:21:31	4109.039	take_profit	\N	\N	\N
3831cea3-f2d1-4f99-8f0c-1b97b0c8a52d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	long	4095.393	4098.452	1	3.06	1.345798504179503	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4093.12	04:42:04	3016339721	2026-07-26	04:55:34	4098.452	take_profit	\N	\N	\N
d9eb3892-d46d-49af-8841-38f77599adf9	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	short	4110.624	4109.731	1	0.89	0.4422981674095721	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4112.643	04:20:26	3016331486	2026-07-26	04:27:03	4109.731	take_profit	\N	\N	\N
0070903c-efaf-485f-9cb7-610badbd1605	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	short	4063.807	4058.123	1	5.68	1.8317757009344575	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4066.91	04:15:19	3016325134	2026-07-26	04:15:47	4058.123	take_profit	\N	\N	\N
b03d11e8-6f97-4882-987d-a1d323892ba6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	long	4041.021	4036.34	1	-4.68	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4036.34	04:08:41	3016321644	2026-07-26	04:09:07	4047.311	stop_loss	\N	\N	\N
fca45144-b7ed-4ef3-a913-448d70f18cbd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	long	4126.658	4130.703	1	4.05	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	04:04:23	3016316385	2026-07-26	04:06:07	\N	take_profit	\N	\N	\N
bf88a619-5f66-4484-9e38-e39f927f7a93	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4008.495	4009.463	1	-0.97	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4009.463	20:51:39	3016310648	2026-07-25	21:04:29	4005.412	stop_loss	\N	\N	\N
380b53b3-8f8e-45dc-9e8f-5f33f38882b8	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAGUSD	Metals	\N	\N	\N	short	57.98	57.908	0.02	7.2	0.043347381095722795	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	59.641	20:46:48	3016308068	2026-07-25	20:49:43	\N	manual	\N	\N	\N
7c148a34-4afd-41d0-829e-f9b30062243e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAGUSD	Metals	\N	\N	\N	long	4099.254	4096.227	1	-3.027	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.227	04:21:00	3016491881	2026-07-29	04:22:00	\N	stop_loss	\N	\N	\N
b77f3819-2cd5-458a-93aa-73a84af81eb0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4061.089	4065.922	1	-4.83	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4065.922	20:46:18	3016302803	2026-07-25	20:54:13	4054.538	stop_loss	\N	\N	\N
fe781cf1-af66-4d2b-b043-f35de1bd58ec	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4009.283	4011.997	2	-5.43	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4011.997	20:38:03	3016296935	2026-07-25	21:31:54	\N	stop_loss	\N	\N	\N
e4e8e029-aa20-4a0b-8cea-da414f15bc39	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAGUSD	Metals	\N	\N	\N	short	56.052	56	0.01	2.6	0.011161193389139217	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	60.711	20:03:10	3016295296	2026-07-25	20:19:34	\N	take_profit	\N	\N	\N
31647a24-c1fc-45aa-8f22-161343d3f686	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4061.101	4063.824	5	-13.61	-0.4778031233549611	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4066.8	12:56:42	3016289154	2026-07-25	13:05:10	\N	manual	\N	\N	\N
cad9dc30-17c0-4558-b1b8-7c0a76308c06	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4107.241	4106.946	2	0.59	0.10064824292054401	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4110.172	12:55:05	3016284588	2026-07-25	12:55:08	4105.966	manual	\N	\N	\N
d0dbbd92-276d-4211-a519-d0bec1a1078b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	BTCUSD	Crypto	\N	\N	\N	long	64121.5	64223.92	0.01	1.02	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	12:54:39	3016280298	2026-07-25	12:54:42	64128.26	manual	\N	\N	\N
05b18439-3a55-490a-90f4-586e6be4e657	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4071.664	4077.48	1	-5.82	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	12:48:41	3016272680	2026-07-25	13:01:54	4063.003	stop_loss	\N	\N	\N
be148cae-3c82-46f8-8f2d-44533c6e8044	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4058.051	4063.945	2	-11.79	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4063.945	12:39:02	3016266638	2026-07-25	12:47:42	4055.054	stop_loss	\N	\N	\N
9a52f702-f65d-450b-a621-025d1928c5cb	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4086.28	4078.834	1	7.45	1.4463869463871066	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4091.428	12:31:04	3016264544	2026-07-25	12:31:33	\N	take_profit	\N	\N	\N
0379c174-80e1-4764-b85f-8774547b77e6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	long	4101.598	4107.226	1	5.63	2.172972972972736	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4099.008	12:29:49	3016259423	2026-07-25	12:31:45	4105.311	manual	\N	\N	\N
2b514341-dfd6-4936-a44d-81027aed1b9f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4097.08	4093.976	10	31.04	0.636195941791325	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4101.959	11:47:53	3016250115	2026-07-25	11:48:48	\N	take_profit	\N	\N	\N
aa1528c4-970f-49bb-b9f1-392b85f5c668	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	long	4010.266	4011.597	1	1.33	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	11:39:32	3016242593	2026-07-25	11:41:39	4015.294	stop_loss	\N	\N	\N
49f72349-8c17-4158-8d31-fb323144813c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4038.89	4042.536	10	-36.46	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4042.536	11:37:40	3016239546	2026-07-25	11:37:56	\N	stop_loss	\N	\N	\N
d0f980de-0321-44cb-ae72-6122841bdc6f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	long	4096.872	4092.376	5	-22.48	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	11:31:38	3016234397	2026-07-25	11:38:33	\N	manual	\N	\N	\N
4a1ed65b-c2bc-449a-aa5b-2611efac1d14	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4004.337	4005.689	2	-2.7	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:29:23	3016225012	2026-07-25	07:30:26	3995.474	stop_loss	\N	\N	\N
1e1e965f-89db-43f0-bc6b-d5c4d380c24f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	BTCUSD	Crypto	\N	\N	\N	short	64177.43	64180.12	0.01	-0.03	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64180.12	21:38:02	3016222649	2026-07-24	21:42:19	64168.85	stop_loss	\N	\N	\N
51b3f513-e895-4591-b77d-956845fed107	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	short	4106.914	4105.001	1	1.91	0.4962386511022883	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4110.769	21:30:18	3016221252	2026-07-24	21:31:15	\N	manual	\N	\N	\N
a6c9945f-0ea8-4a81-b24d-caee3474faad	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4039.567	4034.98	5	-22.93	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4034.98	20:37:27	3016214136	2026-07-24	20:42:06	4049.07	stop_loss	\N	\N	\N
c1a79575-68ad-4e0c-9e7c-6351df58707b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	short	4048.169	4043.706	1	4.46	1.8046906591184055	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4050.642	20:04:08	3016207751	2026-07-24	20:04:25	4043.706	take_profit	\N	\N	\N
c79a7305-ff14-468c-a9ed-8a61243cc49b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4043.356	4041.575	1	-1.78	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4041.575	19:52:53	3016204389	2026-07-24	19:59:23	4051.28	stop_loss	\N	\N	\N
692a1b27-c510-45df-8401-095320f4953d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4112.638	4109.823	1	-2.81	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4109.823	14:06:49	3016196852	2026-07-24	14:07:22	\N	stop_loss	\N	\N	\N
cadc66da-1d34-455f-80de-5e2be0164e44	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4005.637	3998.135	5	-37.51	-2.6369068541298	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4002.792	13:57:42	3016188757	2026-07-24	14:00:25	4007.43	manual	\N	\N	\N
52c4963b-76d7-4a39-9821-96a0d5cd2920	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	short	4076.097	4076.838	1	-0.74	-0.16995412844037638	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4080.457	13:47:12	3016181571	2026-07-24	13:49:05	\N	take_profit	\N	\N	\N
a758eec4-b162-4386-91df-d88d3dd6f841	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	short	4094.85	4099.925	1	-5.08	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4099.925	20:50:46	3016177541	2026-07-23	20:53:05	\N	stop_loss	\N	\N	\N
3c5346eb-d51c-4d70-b786-064218674220	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	BTCUSD	Crypto	\N	\N	\N	short	64321.62	64366.13	0.01	-0.45	-10.829683698294028	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64325.73	20:50:24	3016168624	2026-07-23	20:52:42	\N	manual	\N	\N	\N
9688115e-1737-45aa-8abb-1b5096f7aa37	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	long	4109.87	4115.141	2	10.54	1.2075601374570435	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4105.505	20:50:01	3016166229	2026-07-23	21:46:35	\N	take_profit	\N	\N	\N
9ba1adb5-920c-4c39-bfa5-c433ff446950	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	short	4096.326	4097.068	1	-0.74	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:43:44	3016164756	2026-07-23	13:44:37	\N	manual	\N	\N	\N
88f411a4-ebbb-4c05-b2ee-861c82f0ad08	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	long	4086.052	4081.822	1	-4.23	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4081.822	13:42:22	3016162450	2026-07-23	13:42:40	\N	stop_loss	\N	\N	\N
0f7b2059-e23b-4e33-b485-69eee8d3c019	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	long	4122.892	4115.016	1	-7.88	-3.0397529911238546	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4120.301	13:36:07	3016161025	2026-07-23	13:37:12	\N	manual	\N	\N	\N
37c94a8e-bad3-4b9d-a486-f904f820a3c3	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4010.122	4004.308	1	-5.81	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4004.308	22:38:43	3016155530	2026-07-22	22:41:40	4012.503	stop_loss	\N	\N	\N
6e19ec40-db6c-48f3-93dc-5eccbce105d5	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4051.45	4053.016	1	-1.57	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4053.016	22:27:43	3016150796	2026-07-22	22:34:29	4043.509	stop_loss	\N	\N	\N
d9dfd9dc-e175-4133-9c08-a5311910a11c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4085.216	4084.398	2	-1.64	-0.20480721081617936	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4081.222	22:25:49	3016148944	2026-07-22	22:36:44	4091.762	manual	\N	\N	\N
c0a0178c-ec64-4bf7-8632-8449f092eb13	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4076.885	4084.283	2	-14.8	-1.8284725654967893	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4080.931	22:24:19	3016146754	2026-07-22	22:26:58	\N	take_profit	\N	\N	\N
1b19a24a-1a08-4b9a-b576-99cc1be99c9e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	BTCUSD	Crypto	\N	\N	\N	long	65119.63	65014.89	0.01	-1.05	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	21:53:05	3016139034	2026-07-22	21:54:23	\N	take_profit	\N	\N	\N
dae1f4a4-cafa-43aa-b6b9-b10eab417b95	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4079.275	4083.335	1	-4.06	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4083.335	21:52:12	3016129534	2026-07-22	21:54:17	4077.869	stop_loss	\N	\N	\N
61ecbc4f-740c-4ed7-b149-9123a6ec3824	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4075.756	4074.027	1	-1.73	-0.7848388561052357	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4073.553	21:27:49	3016123641	2026-07-22	21:36:06	4080.021	manual	\N	\N	\N
d7836a24-1b5b-4068-b5c0-1090869c8a6a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4040.153	4045.952	1	-5.8	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	21:25:55	3016114232	2026-07-22	21:26:04	4038.423	manual	\N	\N	\N
becb3b3f-1add-454f-bfa0-e201f2b73e4c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4023.51	4020.688	1	2.82	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:40:15	3016106226	2026-07-22	08:41:27	4020.089	manual	\N	\N	\N
f525e699-d16b-453c-b58b-fd145bd6ea61	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4025.222	4020.772	5	22.25	3.1991373112879105	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4026.613	08:35:16	3016098087	2026-07-22	08:45:47	4022.585	manual	\N	\N	\N
d6ab750d-cc1b-4789-ba17-0a53040df310	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4067.068	4076.575	1	9.51	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:35:25	3016090297	2026-07-21	14:37:07	4076.575	take_profit	\N	\N	\N
9fcd77c4-072f-4421-a688-0b013966e672	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4010.609	4013.008	1	2.4	1.154475457170316	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4008.531	14:34:18	3016087747	2026-07-21	14:42:44	\N	manual	\N	\N	\N
b858436c-fbff-48d8-a741-e12ec215be11	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4028.035	4032.454	1	4.42	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:30:56	3016084046	2026-07-21	14:33:46	\N	take_profit	\N	\N	\N
6eb07521-8d59-4149-8a44-38db05b8cbe7	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4074.756	4070.581	1	-4.17	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4070.581	14:21:39	3016078300	2026-07-21	14:22:04	\N	stop_loss	\N	\N	\N
5692d342-0dc2-48e7-b49a-f737252f6e21	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	BTCUSD	Crypto	\N	\N	\N	long	64440.27	64397.4	0.01	-0.43	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:19:30	3016075731	2026-07-21	14:28:52	\N	stop_loss	\N	\N	\N
7d0bd28c-63f6-4259-a720-9097c1edc35b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4089.009	4086.895	2	-4.23	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4086.895	14:12:50	3016069454	2026-07-21	14:26:36	4090.212	stop_loss	\N	\N	\N
5a6ad7df-f054-498e-a807-d20777f9b407	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4097.928	4100.617	1	-2.69	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:06:27	3016066960	2026-07-21	14:15:32	4088.945	manual	\N	\N	\N
57de3834-0a5f-49f4-9e8a-0a4e2ad57a13	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4094.521	4097.382	2	-5.72	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:48:42	3016062431	2026-07-21	13:51:02	4090.901	manual	\N	\N	\N
bb8c7f07-8e52-4570-b37c-90ded914fb99	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4056.542	4056.333	1	0.21	0.31147540983568783	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4057.213	13:44:52	3016058686	2026-07-21	13:45:36	\N	take_profit	\N	\N	\N
0eb1f702-e236-49be-95dc-6c5dadcb6a1d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4123.431	4125.479	1	-2.05	-0.6002344665886655	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4126.843	13:43:16	3016052133	2026-07-21	14:28:58	4118.969	manual	\N	\N	\N
86897632-27b0-4127-8520-e5719054b820	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4033.838	4041.816	1	7.98	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:40:20	3016044532	2026-07-21	13:53:46	\N	take_profit	\N	\N	\N
090622b4-ada2-4f91-9030-0a42af1eeb6f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4110.677	4102.915	2	15.52	2.412806963008512	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4113.894	13:29:21	3016042249	2026-07-21	13:29:46	\N	take_profit	\N	\N	\N
97c7732a-6b97-4192-a7c1-c34966960f52	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAGUSD	Metals	\N	\N	\N	long	57.999	64.709	0.01	335.5	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:27:58	3016035968	2026-07-21	13:39:56	64.709	take_profit	\N	\N	\N
3e8f3736-37ac-4c10-b58a-df87a121b726	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4016.774	4011.409	2	-10.73	-2.2326258843113793	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4014.371	08:17:37	3016027601	2026-07-21	08:17:56	4026.23	manual	\N	\N	\N
9ee88e75-a2aa-4990-ab56-619f11e7a4b6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4079.876	4081.166	1	1.29	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:55:31	3016022492	2026-07-21	07:58:09	4088.974	manual	\N	\N	\N
7acfb630-249f-423c-b92f-28d24fae7045	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4099.705	4097.434	1	2.27	0.4597165991901815	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4104.645	07:54:09	3016020344	2026-07-21	07:54:46	\N	take_profit	\N	\N	\N
dadc0da8-e5e3-44ad-9527-c2dd1ca21dc4	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4078.866	4081.932	1	-3.07	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4081.932	07:53:01	3016015139	2026-07-21	07:53:14	\N	stop_loss	\N	\N	\N
8dc0f4f3-ceba-4b42-adaf-9f9a0aa3a122	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4112.49	4117.825	1	-5.34	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4117.825	07:49:37	3016012527	2026-07-21	07:49:45	4107.114	stop_loss	\N	\N	\N
13eadf68-c67b-4e1f-b205-01554771b28e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4077.677	4071.397	1	-6.28	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:40:00	3016004209	2026-07-21	07:40:29	\N	stop_loss	\N	\N	\N
2f6c3216-55f1-4361-a7ab-931cb8d848cb	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4009.559	4007.587	1	1.97	1.9108527131790547	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4010.591	07:38:59	3016001109	2026-07-21	07:51:22	\N	take_profit	\N	\N	\N
52373e84-0465-42ed-bb1d-d6486f341fd0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4017.815	4021.545	1	3.73	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:38:06	3015992481	2026-07-21	07:38:19	4021.545	take_profit	\N	\N	\N
fd4c7932-e4f8-4019-9f14-603397e1a9f2	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4038.973	4031.843	1	7.13	1.5883270216083887	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4043.462	07:32:00	3015990380	2026-07-21	07:41:17	4031.843	take_profit	\N	\N	\N
735cbc18-db7f-4c6a-a974-9d5428d930a0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4081.773	4074.602	1	7.17	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	06:42:15	3015984113	2026-07-21	06:42:37	\N	take_profit	\N	\N	\N
4905ce37-f787-49fe-9be9-56d73fd2e24d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4095.659	4090.63	2	10.06	0.8727872266573841	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4101.421	06:34:13	3015980036	2026-07-21	06:35:18	4090.63	take_profit	\N	\N	\N
429f239b-6b5a-412d-bc85-d8fff358613a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4032.047	4035.186	1	-3.14	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4035.186	05:43:05	3015976880	2026-07-21	05:49:55	4026.091	stop_loss	\N	\N	\N
df0b1586-a043-47c7-8aaf-1abd13894af2	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4124.099	4118.891	2	10.42	2.7267015706811177	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4126.009	05:18:27	3015975473	2026-07-21	05:19:34	4118.891	take_profit	\N	\N	\N
7d41b86a-e361-40d7-a130-d15ed3e6eb61	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4087.078	4085.691	1	-1.39	-0.29267778012242274	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4082.339	05:17:09	3015972025	2026-07-21	05:17:28	\N	manual	\N	\N	\N
d87062c1-c8dd-4de9-8c3c-34ab9a1f1a94	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4083.967	4080.148	1	3.82	0.685883620689678	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4089.535	05:13:28	3015970640	2026-07-21	05:13:55	\N	take_profit	\N	\N	\N
d3dab64f-cf46-460c-95fa-d6e8c1c948cb	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4001.205	3995.766	2	10.88	4.393376413569147	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4002.443	05:06:00	3015966756	2026-07-21	05:06:57	3995.766	take_profit	\N	\N	\N
55a86922-68c4-438d-83cc-e082e3de0213	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4043.825	4049.523	1	5.7	1.7090581883625093	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4040.491	04:38:26	3015957423	2026-07-21	04:38:38	4045.423	manual	\N	\N	\N
58c8e340-9c1b-4562-917d-b09ef3c79946	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-20	XAUUSD	Metals	\N	\N	\N	short	4097.988	4095.529	1	2.46	2.138260869566144	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4099.138	16:21:31	3015950543	2026-07-20	16:21:44	\N	take_profit	\N	\N	\N
004bb123-cc27-43d5-b05c-e99e0165cadd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-20	XAUUSD	Metals	\N	\N	\N	short	4028.71	4027.018	1	1.69	0.5475728155339572	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4031.8	15:28:30	3015945096	2026-07-20	15:34:06	4022.965	manual	\N	\N	\N
e2ecce40-e6f9-4ab8-8f34-63dc9e548a6f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	short	4047.032	4052.232	1	-5.2	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4052.232	17:16:56	3015941161	2026-07-19	18:09:19	\N	stop_loss	\N	\N	\N
81be8a89-1faa-4c04-9336-32b12f20c967	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAGUSD	Metals	\N	\N	\N	short	56.907	59.585	0.02	-267.8	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	59.585	17:12:26	3015933869	2026-07-19	17:12:45	48.596	stop_loss	\N	\N	\N
1c14e13c-6f40-4806-abe1-2dc9db41d1d6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4008.972	4003.139	5	-29.17	-1.0055162902947243	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4003.171	17:10:12	3015930590	2026-07-19	17:10:30	4013.217	manual	\N	\N	\N
030c4b0f-4489-4f68-9fb6-3521239789fc	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4045.21	4052.87	1	7.66	1.3022781366881628	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4039.328	16:39:34	3015924987	2026-07-19	16:39:42	4050.27	manual	\N	\N	\N
f5e091dc-7762-42f1-b1be-2a8b927f2491	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4094.253	4101.233	5	34.9	8.02298850574396	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4093.383	16:32:06	3015921853	2026-07-19	16:32:44	\N	manual	\N	\N	\N
e57b6de9-b00c-4ab0-9d7f-584582fe510a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4100.888	4104.638	2	7.5	0.8930697785187769	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.689	16:30:17	3015920173	2026-07-19	16:38:13	4104.638	take_profit	\N	\N	\N
ba03d575-7e1d-4beb-9f1d-36cbeafde024	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4055.536	4060.109	1	4.57	3.461771385314283	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4054.215	16:20:24	3015913485	2026-07-19	16:29:16	4059.799	manual	\N	\N	\N
55a96bb2-a739-4102-93f6-d8ee7fafade8	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	short	4073.11	4076.084	5	-14.87	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4076.084	04:53:26	3015905251	2026-07-19	04:56:18	\N	stop_loss	\N	\N	\N
c0a71789-4141-4907-9164-924287c04428	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4024.461	4018.962	2	-11	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4018.962	04:49:11	3015899595	2026-07-19	04:49:38	\N	stop_loss	\N	\N	\N
614c00e9-313c-4e6e-b9de-9ae652e185b4	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-18	XAUUSD	Metals	\N	\N	\N	long	4031.113	4032.82	1	1.71	0.5276661514684722	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4027.878	10:52:58	3015897349	2026-07-18	10:54:40	4032.82	take_profit	\N	\N	\N
99efd8b2-7d24-4f48-9be4-c62052c35f19	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-18	XAUUSD	Metals	\N	\N	\N	long	4002.109	3997.248	1	-4.86	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	10:46:31	3015891841	2026-07-18	10:49:30	4005.17	stop_loss	\N	\N	\N
aedea703-3cec-4572-beaf-24e44b270c39	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	short	4095.26	4088.59	1	6.67	8.104495747271992	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.083	16:29:07	3015889379	2026-07-17	16:30:20	4094.149	manual	\N	\N	\N
ade4fe85-de53-420f-a279-bd562e79d0ef	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAGUSD	Metals	\N	\N	\N	long	56.302	57.247	0.01	47.25	0.22903538536112478	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	52.176	16:27:18	3015880051	2026-07-17	16:27:27	57.247	take_profit	\N	\N	\N
c1dfb002-0fd9-43f2-871f-22a0eff7ab3a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	short	4105.71	4105.32	1	0.39	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	16:21:10	3015871394	2026-07-17	16:43:28	4102.588	manual	\N	\N	\N
3b42982c-0bd0-463a-8b8f-9bfa74cfa766	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	long	4029.361	4028.552	10	-8.09	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4028.552	02:16:14	3015864294	2026-07-17	02:30:23	4030.248	stop_loss	\N	\N	\N
cd9bb2cc-fac0-466d-80fc-72b0b14b563d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAGUSD	Metals	\N	\N	\N	long	57.838	57.702	0.02	-13.6	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	01:27:13	3015862186	2026-07-17	01:28:37	66.912	stop_loss	\N	\N	\N
73ba39c0-371d-48ca-b547-55865131991a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	short	4038.906	4031.764	5	35.71	1.4731848184818255	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4043.754	00:23:01	3015852801	2026-07-17	00:35:41	4031.764	take_profit	\N	\N	\N
5e9368de-4cb5-484b-8def-ccb54b34abe0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAGUSD	Metals	\N	\N	\N	short	57.228	57.143	0.01	4.25	0.023997741389045965	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	60.77	00:16:07	3015848867	2026-07-17	00:18:18	\N	take_profit	\N	\N	\N
3206e0f9-a58c-441a-97c1-c8d370ebeb0a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	long	4020.049	4015.362	1	-4.69	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4015.362	00:08:38	3015841643	2026-07-17	00:09:47	4021.79	stop_loss	\N	\N	\N
83e075c3-fafe-4112-9325-9a0809cc7933	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	long	4012.098	4021.226	1	9.13	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	23:59:59	3015837866	2026-07-17	00:01:52	4021.226	take_profit	\N	\N	\N
f8e00d31-3798-4871-99e2-64e40ba1ff73	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	short	4008.225	4012.163	1	-3.94	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4012.163	23:58:36	3015832487	2026-07-17	00:00:16	\N	stop_loss	\N	\N	\N
d6e1144b-96bd-419c-915e-f4132056e8b2	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	BTCUSD	Crypto	\N	\N	\N	short	64259.78	64162.72	0.02	1.94	45.14418604647999	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64261.93	23:49:48	3015829602	2026-07-16	23:51:42	64253.43	manual	\N	\N	\N
271ee799-3620-439d-935d-f2990963b8ff	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	short	4101.657	4094.744	5	34.57	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:49:50	3015826513	2026-07-16	08:51:56	4099.202	manual	\N	\N	\N
ec403b91-732a-475c-8010-a9ee0d078b21	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	long	4103.435	4099.478	2	-7.91	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:40:58	3015821571	2026-07-16	08:43:35	4107.703	stop_loss	\N	\N	\N
638bce64-894d-4f6a-b661-697f301fa451	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAGUSD	Metals	\N	\N	\N	short	57.581	57.698	0.01	-5.85	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:31:48	3015820329	2026-07-16	09:30:21	55.251	manual	\N	\N	\N
b19361d4-96d4-400a-b9f4-2af112391942	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4028.86	4024.622	1	-4.24	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4024.622	19:57:25	3015818408	2026-07-15	20:09:56	4036.012	stop_loss	\N	\N	\N
f1b1c2d9-a97b-489a-b9b1-a3fa2d022161	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	BTCUSD	Crypto	\N	\N	\N	long	64960.3	64966.63	0.02	0.13	1.4161073825487296	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64955.83	19:48:11	3015817007	2026-07-15	19:57:02	\N	manual	\N	\N	\N
df67ec07-f199-4d1c-ae67-ba31309cef27	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4021.366	4016.478	1	-4.89	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4016.478	19:47:53	3015811801	2026-07-15	19:49:25	4027.96	stop_loss	\N	\N	\N
8f112e76-9a06-465b-bbbb-dc7a0ae854c1	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAGUSD	Metals	\N	\N	\N	short	56.778	56.685	0.01	4.65	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	19:15:53	3015809848	2026-07-15	19:22:23	\N	stop_loss	\N	\N	\N
5009a01f-b8c2-464a-92ec-f116f7dd0cfd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4083.084	4088.06	1	-4.98	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4088.06	19:08:39	3015800919	2026-07-15	19:10:48	4075.789	stop_loss	\N	\N	\N
4b1ed3ae-935b-4f64-b1fe-24aa6e5a1521	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4090.147	4088.286	1	-1.86	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	19:06:13	3015793756	2026-07-15	19:06:32	4097.327	manual	\N	\N	\N
ac26d19c-0f45-4e17-9b5e-53032321e100	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4112.518	4105.097	1	7.42	1.7395686826068764	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4116.784	19:05:41	3015786282	2026-07-15	19:11:00	4107.894	manual	\N	\N	\N
b46d6a54-0e22-4d77-ae7e-8bde60ff5b37	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4029.23	4024.975	1	4.26	3.7721631205669497	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4030.358	19:04:29	3015782624	2026-07-15	19:15:17	\N	manual	\N	\N	\N
80a4eec2-f604-4ee3-9558-9355f20f1b36	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4013.314	4007.347	10	-59.67	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4007.347	18:22:29	3015778492	2026-07-15	18:24:02	4021.25	stop_loss	\N	\N	\N
596a6d49-a852-498d-afa3-16fd33a55c61	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4105.759	4107.309	2	3.1	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	17:28:58	3015776713	2026-07-15	17:29:43	4109.251	manual	\N	\N	\N
e51db471-0aaf-45c1-81e5-ed835d8dcdb0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4129.023	4125.641	5	16.91	0.8016117563404778	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4133.242	17:26:59	3015768643	2026-07-15	17:27:29	4123.72	manual	\N	\N	\N
5d33bbb6-7a0e-45b5-80c5-e0ed6773463f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4097.474	4089.514	1	-7.96	-1.76106194690267	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4092.954	17:26:15	3015763765	2026-07-15	17:28:19	4102.492	manual	\N	\N	\N
50eff410-6489-4667-87a1-19eccb5fe7d7	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	BTCUSD	Crypto	\N	\N	\N	long	64145.73	64141.04	0.01	-0.05	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64141.04	17:24:11	3015757293	2026-07-15	17:24:23	64146.95	stop_loss	\N	\N	\N
66d758ce-ff3d-4e88-be40-1c57097f7561	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4124.544	4126.421	1	-1.88	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4126.421	12:22:47	3015752026	2026-07-15	12:22:56	4120.323	stop_loss	\N	\N	\N
79bcbf1b-f327-43e2-942c-689a49899c40	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4011.856	4013.355	1	1.5	2.7555147058803384	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4011.312	12:20:54	3015744007	2026-07-15	12:21:00	4015.817	manual	\N	\N	\N
79cbc77f-9106-4e88-b04d-dcbf02fd1cd0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	USTEC	Metals	\N	\N	\N	long	57.584	57.574	0.01	-0.5	-0.00175963	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	51.901	04:58:00	3016472179	2026-07-28	04:59:00	64.643	manual	\N	\N	\N
d4c90196-88c2-4318-8e09-d781296e2a02	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-13	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-13 18:35:08.033321+00	\N	21:30:00	\N	2026-08-13	21:34:00	\N	\N	\N	\N	\N
87bf0743-3c27-4175-bea3-9ff2f09ecd77	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-13	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-13 19:25:02.261412+00	\N	03:30:00	\N	2026-08-13	11:00:00	\N	\N	\N	\N	\N
c8335101-3135-4921-8dd2-48497ec7ec32	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-12	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-14 08:39:34.442777+00	\N	10:50:00	\N	2026-08-12	11:39:00	\N	\N	\N	\N	\N
aa79b2d2-f0e7-45c4-9253-d74f1ba719da	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4014.6	4019.51	1	-4.91	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4019.51	04:12:46	3016221392	2026-07-29	04:29:00	4004.456	stop_loss	\N	\N	\N
e390281f-a8f1-4ef7-a43b-ec908253cbe4	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-14	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	12	\N	\N	\N	\N	{}	2026-08-14 05:55:39.050552+00	\N	03:01:00	\N	2026-08-14	03:30:00	\N	\N	\N	\N	\N
c1bfc702-0c6f-484b-aee8-8c9d88fd4fa8	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAGUSD	Metals	\N	\N	\N	short	56.928	57.028000000000006	0.01	-5	-1.010101010101058	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	57.027	04:14:09	3016225586	2026-07-29	04:15:21	56.865	stop_loss	\N	\N	\N
a3b0a14b-4c0b-4ce8-8016-f487beb9232b	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4014.354	4015.859	1	-1.51	-0.3810126582278494	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4018.304	04:07:08	3016205204	2026-07-29	04:12:09	4012.469	manual	\N	\N	\N
984c7f3b-002a-43ed-a895-38807cff88e5	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4017.054	4012.8179999999998	1	4.23	3.670710571924042	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4018.208	04:01:53	3016183906	2026-07-29	04:04:38	4008.708	manual	\N	\N	\N
1b9e0109-856f-40aa-bec6-6111cd88d7df	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAGUSD	Metals	\N	\N	\N	short	57.124	57.168	0.01	-2.2	-1.0232558139534347	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	57.167	03:58:23	3016169199	2026-07-29	03:59:51	57.071	stop_loss	\N	\N	\N
481575c1-afa2-4c50-9e53-7b4207fc328b	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4021.453	4022.066	1	0.62	0.4915797914995236	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4020.206	03:58:19	3016172263	2026-07-29	03:58:54	4022.066	take_profit	\N	\N	\N
d980af04-d866-444f-ae4e-55058af3adb2	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4020.497	4021.3979999999997	1	-0.9	-1.1206467661688335	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4021.301	03:57:45	3016170411	2026-07-29	03:57:46	4019.652	stop_loss	\N	\N	\N
4573605d-22e9-4d69-99ef-705ff583277d	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4023.107	4021.883	1	-1.23	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4021.883	03:55:17	3016167161	2026-07-29	03:55:37	4023.725	stop_loss	\N	\N	\N
e0c2eb09-8097-4b68-a895-00a8a42f6cf0	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4023.137	4024.1059999999998	1	-0.97	-1.0319488817888713	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.076	03:54:16	3016165665	2026-07-29	03:55:00	\N	stop_loss	\N	\N	\N
725fedb4-ba6f-48ea-80e5-259c229c4aa2	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4022.797	4023.2439999999997	1	-0.44	-1.0849514563103662	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4023.209	03:53:52	3016165060	2026-07-29	03:54:09	\N	stop_loss	\N	\N	\N
018330a8-709c-4d38-9961-745d7c4d266d	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4025.14	4025.73	1	0.59	0.3042805569882367	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4023.201	03:39:54	3016144257	2026-07-29	03:43:21	4025.73	take_profit	\N	\N	\N
9d134275-eeef-4899-ab64-31ebc70d1fc1	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4026.142	4025.562	1	-0.58	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4025.562	03:38:47	3016142383	2026-07-29	03:39:21	4027.461	stop_loss	\N	\N	\N
0a5d3e44-ecbc-44c7-886e-c41bbb1b721f	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4022.489	4025.897	1	3.41	0.9281045751633655	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4026.161	03:32:31	3016131486	2026-07-29	03:38:22	4030.819	stop_loss	\N	\N	\N
aa161daa-af71-485b-91f4-226f51b0b165	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4024.311	4026.368	1	2.06	3.540447504304536	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.892	03:36:47	3016137372	2026-07-29	03:37:59	\N	manual	\N	\N	\N
fb5a9d57-f206-4a95-a0f1-9a02bbdab048	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4022.976	4022.018	1	-0.96	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4022.018	03:29:20	3016125507	2026-07-29	03:30:41	4023.95	stop_loss	\N	\N	\N
1cbbf01b-75b1-423e-a809-a614bb6245bd	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4022.336	4022.741	1	-0.4	-0.21797631862226158	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.194	03:28:38	3016124339	2026-07-29	03:30:39	\N	manual	\N	\N	\N
19411617-2f64-4489-9eda-7608181a6a6a	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4026.621	4022.269	1	-4.35	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4022.269	03:22:29	3016110561	2026-07-29	03:29:02	\N	stop_loss	\N	\N	\N
77785262-3936-4584-a1d9-214579a67925	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4023.749	4023.5429999999997	1	0.21	0.17024793388440063	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.959	03:28:12	3016123556	2026-07-29	03:28:28	\N	manual	\N	\N	\N
c1416d2f-d9fb-4973-92ef-f51020606972	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4023.879	4023.421	1	0.46	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	03:27:41	3016122567	2026-07-29	03:27:58	\N	manual	\N	\N	\N
c67fd7e9-a5d9-40e5-8f7f-cecbc144bcdd	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	BTCUSD	Crypto	\N	\N	\N	long	64001.46	63949.840000000004	0.01	-0.51	-1.0080062487794614	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	63950.25	03:17:21	3016097478	2026-07-29	03:20:53	\N	stop_loss	\N	\N	\N
0b7234cb-03d4-4c6d-b670-65718c82584c	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-28	XAUUSD	Metals	\N	\N	\N	long	4049.529	4049.3140000000003	1	-0.22	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	09:33:11	3011745614	2026-07-28	09:33:22	\N	manual	\N	\N	\N
688efc45-cd8c-45bc-9a36-8fec3566be2c	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-28	XAUUSD	Metals	\N	\N	\N	short	4049.021	4049.6569999999997	1	-0.64	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	09:32:57	3011744895	2026-07-28	09:33:09	\N	manual	\N	\N	\N
b1a28813-ea6e-4974-8bb5-3b7af5cf6369	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-28	XAUUSD	Metals	\N	\N	\N	long	4049.568	4049.525	1	-0.04	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	09:32:43	3011744014	2026-07-28	09:32:47	\N	manual	\N	\N	\N
ebb98f5c-77df-458e-b0ee-625432c14434	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4120.155	4119.847	10	-3.08	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	14:12:59	2991037348	2026-07-22	14:13:04	\N	manual	\N	\N	\N
d8bae59b-3482-4262-887f-98876c189486	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-19	BTCUSD	Crypto	\N	\N	\N	long	64543.95	64534.07	0.01	-0.1	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	19:47:11	2978668763	2026-07-19	19:47:19	\N	manual	\N	\N	\N
6e951fd2-2aaf-41c1-bf5e-a8ba87e7bbbf	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-31	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-14 10:45:00.282238+00	\N	13:44:00	\N	2026-07-31	17:44:00	\N	\N	\N	\N	\N
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: chart_symbol_overrides chart_symbol_overrides_account_id_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_symbol_overrides
    ADD CONSTRAINT chart_symbol_overrides_account_id_symbol_key UNIQUE (account_id, symbol);


--
-- Name: chart_symbol_overrides chart_symbol_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_symbol_overrides
    ADD CONSTRAINT chart_symbol_overrides_pkey PRIMARY KEY (id);


--
-- Name: dropdown_settings dropdown_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dropdown_settings
    ADD CONSTRAINT dropdown_settings_pkey PRIMARY KEY (id);


--
-- Name: exness_contract_overrides exness_contract_overrides_account_id_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_account_id_symbol_key UNIQUE (account_id, symbol);


--
-- Name: exness_contract_overrides exness_contract_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (id);


--
-- Name: accounts_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_name_unique ON public.accounts USING btree (lower(name));


--
-- Name: chart_symbol_overrides_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chart_symbol_overrides_account_idx ON public.chart_symbol_overrides USING btree (account_id);


--
-- Name: exness_contract_overrides_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exness_contract_overrides_account_idx ON public.exness_contract_overrides USING btree (account_id);


--
-- Name: notes_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_account_idx ON public.notes USING btree (account_id);


--
-- Name: notes_linked_trade_ids_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_linked_trade_ids_idx ON public.notes USING gin (linked_trade_ids);


--
-- Name: notes_tags_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_tags_idx ON public.notes USING gin (tags);


--
-- Name: notes_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_updated_idx ON public.notes USING btree (account_id, updated_at DESC);


--
-- Name: trades_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_account_idx ON public.trades USING btree (account_id);


--
-- Name: trades_broker_ticket_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_broker_ticket_idx ON public.trades USING btree (account_id, broker_ticket);


--
-- Name: trades_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_date_idx ON public.trades USING btree (entry_date);


--
-- Name: chart_symbol_overrides chart_symbol_overrides_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_symbol_overrides
    ADD CONSTRAINT chart_symbol_overrides_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: dropdown_settings dropdown_settings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dropdown_settings
    ADD CONSTRAINT dropdown_settings_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: exness_contract_overrides exness_contract_overrides_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: notes notes_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: trades trades_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts authenticated read/write accounts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write accounts" ON public.accounts USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: chart_symbol_overrides authenticated read/write chart_symbol_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write chart_symbol_overrides" ON public.chart_symbol_overrides USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: dropdown_settings authenticated read/write dropdown_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write dropdown_settings" ON public.dropdown_settings USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: exness_contract_overrides authenticated read/write exness_contract_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write exness_contract_overrides" ON public.exness_contract_overrides USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: notes authenticated read/write notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write notes" ON public.notes USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: trades authenticated read/write trades; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write trades" ON public.trades USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: chart_symbol_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chart_symbol_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: dropdown_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dropdown_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: exness_contract_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.exness_contract_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: trades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 0XNGeJhDs6zaxblH7cTiXbvBnz09AwVygCaF8sb7ItaGVk41YIfJSkxcvnL1DYb

