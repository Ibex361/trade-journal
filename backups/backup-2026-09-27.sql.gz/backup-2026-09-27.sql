--
-- PostgreSQL database dump
--

\restrict KlvLDgMmYvUnUCSEaGrQ4edhsPtiskah2wshbFAzPCUBC4tRBB9l7CiiN9Nzdzi

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: bulk_add_note_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_add_note_tag(note_ids uuid[], tag_to_add text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_append(array_remove(tags, tag_to_add), tag_to_add)
  where id = any(note_ids);
$$;


--
-- Name: bulk_add_trade_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_add_trade_tag(trade_ids uuid[], tag_to_add text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_append(array_remove(tags, tag_to_add), tag_to_add)
  where id = any(trade_ids);
$$;


--
-- Name: bulk_remove_note_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_remove_note_tag(note_ids uuid[], tag_to_remove text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_remove(tags, tag_to_remove)
  where id = any(note_ids);
$$;


--
-- Name: bulk_remove_trade_tag(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_remove_trade_tag(trade_ids uuid[], tag_to_remove text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_remove(tags, tag_to_remove)
  where id = any(trade_ids);
$$;


--
-- Name: bulk_rename_note_tag(uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_rename_note_tag(note_ids uuid[], tag_from text, tag_to text) RETURNS void
    LANGUAGE sql
    AS $$
  update notes
  set tags = array_append(array_remove(array_remove(tags, tag_from), tag_to), tag_to)
  where id = any(note_ids);
$$;


--
-- Name: bulk_rename_trade_tag(uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_rename_trade_tag(trade_ids uuid[], tag_from text, tag_to text) RETURNS void
    LANGUAGE sql
    AS $$
  update trades
  set tags = array_append(array_remove(array_remove(tags, tag_from), tag_to), tag_to)
  where id = any(trade_ids);
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    broker text,
    currency text DEFAULT 'USD'::text NOT NULL,
    is_demo boolean DEFAULT false NOT NULL,
    starting_balance numeric DEFAULT 0 NOT NULL,
    journal_start_date date DEFAULT CURRENT_DATE NOT NULL,
    target_risk_pct numeric,
    target_monthly_pnl numeric,
    target_monthly_winrate numeric,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_archived boolean DEFAULT false NOT NULL
);


--
-- Name: backtest_run_feeds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backtest_run_feeds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    instrument text NOT NULL,
    timeframe text NOT NULL
);


--
-- Name: backtest_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backtest_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    script_filename text NOT NULL,
    script_source text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error_message text,
    backtrader_analysis jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT backtest_runs_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'completed'::text, 'failed'::text])))
);


--
-- Name: backtest_trades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backtest_trades (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    instrument text NOT NULL,
    direction text,
    entry_date date NOT NULL,
    entry_time time without time zone,
    exit_date date,
    exit_time time without time zone,
    entry_price double precision,
    exit_price double precision,
    size double precision,
    pnl double precision NOT NULL,
    CONSTRAINT backtest_trades_direction_check CHECK ((direction = ANY (ARRAY['long'::text, 'short'::text])))
);


--
-- Name: chart_symbol_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_symbol_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    symbol text NOT NULL,
    twelve_data_symbol text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dropdown_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dropdown_settings (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    category text NOT NULL,
    value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dropdown_settings_category_check CHECK ((category = ANY (ARRAY['asset_class'::text, 'strategy'::text, 'session'::text, 'emotion'::text])))
);


--
-- Name: exness_contract_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exness_contract_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    symbol text NOT NULL,
    contract_size numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    title text DEFAULT 'Untitled'::text NOT NULL,
    content jsonb DEFAULT '{"type": "doc", "content": [{"type": "paragraph"}]}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    linked_trade_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    linked_strategy text
);


--
-- Name: trades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trades (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    entry_date date NOT NULL,
    instrument text NOT NULL,
    asset_class text,
    strategy text,
    session text,
    emotion text,
    direction text,
    entry_price numeric,
    exit_price numeric,
    size numeric,
    pnl numeric DEFAULT 0 NOT NULL,
    r_multiple numeric,
    rules_followed boolean,
    notes text,
    screenshot_url text,
    tags text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    stop_loss_price numeric,
    entry_time time without time zone,
    broker_ticket text,
    exit_date date,
    exit_time time without time zone,
    take_profit_price numeric,
    exit_reason text,
    sl_movement text,
    tp_movement text,
    screenshot_file_id text,
    CONSTRAINT trades_direction_check CHECK ((direction = ANY (ARRAY['long'::text, 'short'::text]))),
    CONSTRAINT trades_exit_reason_check CHECK ((exit_reason = ANY (ARRAY['stop_loss'::text, 'take_profit'::text, 'manual'::text, 'other'::text]))),
    CONSTRAINT trades_sl_movement_check CHECK ((sl_movement = ANY (ARRAY['held'::text, 'tightened'::text, 'widened'::text]))),
    CONSTRAINT trades_tp_movement_check CHECK ((tp_movement = ANY (ARRAY['held'::text, 'tightened'::text, 'widened'::text])))
);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, name, broker, currency, is_demo, starting_balance, journal_start_date, target_risk_pct, target_monthly_pnl, target_monthly_winrate, created_at, is_archived) FROM stdin;
adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	Test	\N	USD	f	0	2026-08-11	\N	\N	\N	2026-08-11 10:58:02.945735+00	f
40f6a8ae-bc42-4397-8988-577d9373e75c	DoubleBirr	\N	USD	f	30	2026-08-14	\N	\N	\N	2026-08-14 10:17:24.141667+00	f
c7b56cc2-3d4a-43a8-b940-142c1b68c07c	Demo1	Exness	USD	f	30	2026-09-10	\N	\N	\N	2026-09-10 09:15:08.479238+00	f
00000000-0000-0000-0000-000000000001	Demo account	Paper broker	USD	t	25000	2026-04-22	1	2150	55	2026-07-21 09:46:15.442403+00	f
\.


--
-- Data for Name: backtest_run_feeds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backtest_run_feeds (id, run_id, instrument, timeframe) FROM stdin;
794151de-40ac-41f8-ab4d-4c2a79818148	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	5min
0b722c52-27d8-4fdd-8b43-e8fb2a61078b	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	5min
97faedbf-2bb1-42a7-bc85-eae77c33b37f	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	5min
abe5d15e-370b-4387-ab2d-eb43db12b0d7	fcb7d560-a7de-4376-9ca4-9917aef450d7	EURUSD	5min
0190c4b4-3b70-4591-bc1f-ecc6c2ecfc71	77e3c523-dce8-43c3-973e-9b6c483be579	EURUSD	5min
2741beb8-343c-49f9-b561-d863bb5aa53b	8627d769-b363-4c1d-aefe-614bc4584090	EURUSD	5min
66b91558-e31d-441c-b34e-862916829a5d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	15min
f55cc30a-d521-4201-9003-ad56a26facb1	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	5min
5c306eda-57cf-4d54-bc93-f7bb6fe2b23d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	5min
\.


--
-- Data for Name: backtest_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backtest_runs (id, name, script_filename, script_source, start_date, end_date, status, error_message, backtrader_analysis, created_at, completed_at) FROM stdin;
311c4e64-6e70-481b-876e-8adc9455370d	macd_crossover-1	macd_crossover-1.py	"""\nMACD Crossover — Backtrader.\n\nThe standard, textbook MACD crossover strategy (Gerald Appel's MACD,\nas commonly taught) with no added filters or variants: this is the\nplain, widely-known version, not a customized derivative.\n\nMACD\n    MACD line = EMA(fast) - EMA(slow)\n    Signal line = EMA(MACD line, signal_period)\n    Standard parameters: fast=12, slow=26, signal=9 (the canonical\n    defaults used almost universally).\n\nEntry / Exit (the crossover rule)\n    Long when the MACD line crosses ABOVE the signal line.\n    Short when the MACD line crosses BELOW the signal line.\n    Always in the market once warmed up: a bullish crossover both\n    closes any open short and opens a long in the same action, and a\n    bearish crossover both closes any open long and opens a short —\n    this is the standard always-in-the-market version of the rule\n    (long or short, never flat), matching how the strategy is\n    conventionally described and traded.\n\nStop-loss / take-profit (added on top, NOT part of the textbook rule)\n    The plain MACD crossover strategy has no SL/TP — the opposite\n    crossover IS the exit. This version adds an ATR-based SL/TP as a\n    safety net on top of that, deliberately: whichever comes first —\n    the stop, the target, or the next opposite crossover — closes the\n    trade. This is a variant, not the pure textbook strategy; see the\n    module name/params below for the ATR settings.\n\n    Mechanics: the instant an entry (or reversal) fills, a Stop order\n    and a Limit order are placed at stop_atr_mult*ATR and\n    tp_atr_mult*ATR away from the fill price, sized to the position.\n    If either fills, the other is cancelled (nothing left dangling\n    against a flat position). If an OPPOSITE crossover fires while a\n    bracket is still live, the bracket orders are cancelled first,\n    THEN order_target_percent is used to flip the position — this\n    ordering matters: submitting the reversal before the old\n    stop/limit are confirmed cancelled would leave a stale bracket\n    sized for the OLD position free to fire against the NEW one.\n\nPosition sizing\n    Uses Backtrader's order_target_percent: each crossover targets a\n    position sized to risk_pct of account equity (long on a bullish\n    cross, short on a bearish one). This is a single atomic order —\n    Backtrader computes and submits whatever buy/sell delta is needed\n    to move from the current position (long, short, or flat) to the\n    target, so there's no manual close-then-open pair to sequence or\n    track, which avoids a real bug an earlier draft of this file had\n    (using self.close() and self.buy() as two separate orders let the\n    strategy's own order-tracking reference get silently overwritten\n    by the second one).\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass MACDCrossover(bt.Strategy):\n    params = dict(\n        fast_period=12,     # MACD fast EMA\n        slow_period=26,     # MACD slow EMA\n        signal_period=9,    # signal line EMA\n        risk_pct=0.95,      # fraction of equity committed per position (always-in-market sizing)\n        atr_period=14,      # ATR lookback for SL/TP distance\n        stop_atr_mult=2.0,  # SL = fill_price -/+ stop_atr_mult * ATR\n        tp_atr_mult=3.0,    # TP = fill_price +/- tp_atr_mult * ATR\n    )\n\n    def __init__(self):\n        self.macd = bt.indicators.MACD(\n            self.data.close,\n            period_me1=self.p.fast_period,\n            period_me2=self.p.slow_period,\n            period_signal=self.p.signal_period,\n        )\n        self.crossover = bt.indicators.CrossOver(self.macd.macd, self.macd.signal)\n        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)\n\n        self.order = None        # the entry/reversal order (order_target_percent)\n        self.stop_order = None   # SL leg of the current position's bracket\n        self.limit_order = None  # TP leg of the current position's bracket\n        self.pending_cross = None  # crossover direction queued behind a bracket-cancel, if any\n\n    def _warm(self) -> bool:\n        needed = max(self.p.slow_period + self.p.signal_period, self.p.atr_period) + 1\n        return len(self.data) >= needed\n\n    def _cancel_bracket(self):\n        """Cancel any live SL/TP orders. Safe to call with none pending."""\n        if self.stop_order is not None and self.stop_order.status not in (\n            self.stop_order.Completed, self.stop_order.Canceled, self.stop_order.Margin, self.stop_order.Rejected\n        ):\n            self.cancel(self.stop_order)\n        if self.limit_order is not None and self.limit_order.status not in (\n            self.limit_order.Completed, self.limit_order.Canceled, self.limit_order.Margin, self.limit_order.Rejected\n        ):\n            self.cancel(self.limit_order)\n\n    def _place_bracket(self, fill_price: float, size: int):\n        """Place SL/TP for a freshly-opened position. size is signed (negative = short)."""\n        atr = self.atr[0]\n        if atr <= 0 or size == 0:\n            self.stop_order = None\n            self.limit_order = None\n            return\n        stop_dist = self.p.stop_atr_mult * atr\n        tp_dist = self.p.tp_atr_mult * atr\n        abs_size = abs(size)\n\n        if size > 0:  # long\n            stop_price = fill_price - stop_dist\n            tp_price = fill_price + tp_dist\n            self.stop_order = self.sell(exectype=bt.Order.Stop, price=stop_price, size=abs_size)\n            self.limit_order = self.sell(exectype=bt.Order.Limit, price=tp_price, size=abs_size)\n        else:  # short\n            stop_price = fill_price + stop_dist\n            tp_price = fill_price - tp_dist\n            self.stop_order = self.buy(exectype=bt.Order.Stop, price=stop_price, size=abs_size)\n            self.limit_order = self.buy(exectype=bt.Order.Limit, price=tp_price, size=abs_size)\n\n    def next(self):\n        if not self._warm():\n            return\n\n        cross = self.crossover[0]\n\n        # A bracket-cancel is pending from a signal on a prior bar — the\n        # cancels submitted last bar should be confirmed by now (typical\n        # broker/backtest fill timing is same-bar-next or next-bar), but\n        # guard again defensively: only proceed once no live bracket\n        # order remains, so the reversal never races a stale SL/TP.\n        if self.pending_cross is not None:\n            if self.stop_order is not None or self.limit_order is not None:\n                return  # still waiting on cancel confirmation\n            self.order = self.order_target_percent(target=self.p.risk_pct if self.pending_cross > 0 else -self.p.risk_pct)\n            self.pending_cross = None\n            return\n\n        if self.order is not None:\n            return  # an order is already working, wait for it to resolve\n\n        if cross == 0:\n            return  # no crossover this bar\n\n        if self.position:\n            # Opposite-direction crossover while a bracket is live:\n            # cancel the old SL/TP first, defer the reversal to a later\n            # bar once those cancels are confirmed (see pending_cross\n            # handling above). Same-direction "crossover" can't happen\n            # here since CrossOver only fires on an actual sign change.\n            self._cancel_bracket()\n            self.pending_cross = cross\n            return\n\n        # Flat: no bracket to cancel, just open new position.\n        self.order = self.order_target_percent(target=self.p.risk_pct if cross > 0 else -self.p.risk_pct)\n\n    def notify_order(self, order):\n        is_entry = self.order is not None and order.ref == self.order.ref\n        is_stop = self.stop_order is not None and order.ref == self.stop_order.ref\n        is_limit = self.limit_order is not None and order.ref == self.limit_order.ref\n\n        if is_entry:\n            if order.status == order.Completed:\n                self.order = None\n                self._place_bracket(order.executed.price, self.position.size)\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.order = None\n            return\n\n        if is_stop or is_limit:\n            if order.status == order.Completed:\n                other = self.limit_order if is_stop else self.stop_order\n                if other is not None and other.status not in (\n                    other.Completed, other.Canceled, other.Margin, other.Rejected\n                ):\n                    self.cancel(other)\n                self.stop_order = None\n                self.limit_order = None\n            elif order.status == order.Canceled:\n                if is_stop:\n                    self.stop_order = None\n                else:\n                    self.limit_order = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -2.076499640294246, "trades": 201}, "VWR": {"vwr": -0.0003252271942754052}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.000004548859573147314, "rtot": -0.012927858906884665, "rnorm": -0.000004548849227101294, "rnorm100": -0.00045488492271012935}, "DrawDown": {"len": 2578, "max": {"len": 2578, "drawdown": 1.6070127340208749, "moneydown": 160.85908269622814}, "drawdown": 1.3813092575677492, "moneydown": 138.26657087912645}, "SharpeRatio": {"sharperatio": -10.058879719983459}, "AnnualReturn": {"2026": -0.012844653082594082}, "TimeDrawDown": {"maxdrawdown": 1.6070127340208749, "maxdrawdownperiod": 2578}, "TradeAnalyzer": {"len": {"max": 52, "min": 1, "won": {"max": 47, "min": 1, "total": 870, "average": 13.384615384615385}, "long": {"max": 52, "min": 1, "won": {"max": 47, "min": 1, "total": 452, "average": 13.696969696969697}, "lost": {"max": 52, "min": 1, "total": 682, "average": 10.333333333333334}, "total": 1134, "average": 11.454545454545455}, "lost": {"max": 52, "min": 1, "total": 1264, "average": 9.294117647058824}, "short": {"max": 36, "min": 1, "won": {"max": 30, "min": 3, "total": 418, "average": 13.0625}, "lost": {"max": 36, "min": 1, "total": 582, "average": 8.314285714285715}, "total": 1000, "average": 9.803921568627452}, "total": 2134, "average": 10.616915422885572}, "pnl": {"net": {"total": -132.01273082594858, "average": -0.6567797553529781}, "gross": {"total": -132.01273082594858, "average": -0.6567797553529781}}, "won": {"pnl": {"max": 15.700619736449983, "total": 246.3558178361205, "average": 3.7900895051710846}, "total": 65}, "long": {"pnl": {"won": {"max": 9.445174529737283, "total": 116.78023565816814, "average": 3.538795019944489}, "lost": {"max": -7.380316588383627, "total": -161.95466042877106, "average": -2.453858491345016}, "total": -45.17442477060297, "average": -0.4563073209151815}, "won": 33, "lost": 66, "total": 99}, "lost": {"pnl": {"max": -36.04510000000074, "total": -378.36854866206914, "average": -2.7821216813387437}, "total": 136}, "short": {"pnl": {"won": {"max": 15.700619736449983, "total": 129.57558217795244, "average": 4.049236943061014}, "lost": {"max": -36.04510000000074, "total": -216.41388823329805, "average": -3.0916269747614007}, "total": -86.83830605534558, "average": -0.8513559417190744}, "won": 32, "lost": 70, "total": 102}, "total": {"open": 1, "total": 202, "closed": 201}, "streak": {"won": {"current": 1, "longest": 4}, "lost": {"current": 0, "longest": 12}}}}	2026-09-22 09:58:47.367917+00	2026-09-22 09:59:38.227294+00
6a26127b-2645-4eec-b47e-642b876d3873	pullback_reversal-3	pullback_reversal-3.py	"""\nPullback Reversal strategy — Backtrader.\n\nModel (fully specified across several rounds of clarification):\n\nLeg direction\n    Tracked against a 20-period EMA. A leg only flips direction once\n    price closes on the OTHER side of the EMA for >= min_leg_bars (5)\n    consecutive bars — a shorter poke to the other side does not flip\n    anything and does not interrupt the current leg's swing tracking.\n\nSwing high/low (per leg)\n    up-leg: the highest high seen so far this leg.\n    down-leg: the lowest low seen so far this leg.\n    Any bar that makes a NEW swing extreme updates it and discards\n    whatever pullback bar was being tracked (fresh start — we're now\n    watching for a pullback under/over the new extreme).\n\nPullback bar\n    Any bar that closes below the up-leg's swing high (or above the\n    down-leg's swing low). We always track only the MOST RECENT\n    pullback bar since the last new swing extreme.\n\nEntry trigger\n    A Stop order at the tracked pullback bar's high + break_buffer\n    (up-leg) or low - break_buffer (down-leg) — fires intrabar the\n    instant price trades through it, not at bar close ("enter right\n    when the break happens").\n    Placed only if, at the moment the pullback bar formed:\n      - its low (up-leg) / high (down-leg) was within pullback_points\n        of the EMA at that time (no touch required), AND\n      - the EMA's 2-bar slope was in the leg's direction at that time.\n    And valid only if, at the moment of the eventual fill:\n      - the fill price is within max_ema_distance of the CURRENT EMA.\n\nStop-loss & target\n    Stop  = the tracked pullback bar's own low (up-leg) / high (down-leg).\n    Target = the leg's swing high/low at arm time.\n    Both are frozen the moment the entry order is placed (never creep\n    while the order is working), and both are placed as REAL Stop/Limit\n    orders the instant the entry fills — so, just like the entry itself,\n    they fire intrabar at the exact price level, not one bar late via a\n    market order reacting to data.high[0]/data.low[0] after the fact.\n\nImplementation note (Backtrader-specific, verified against 1.9.78):\nself.cancel() on a working Stop order does not synchronously remove it\nfrom the broker — it can still fill several bars later despite being\n"cancelled". The strategy therefore never discards a working order's\nidentity/snapshot until notify_order actually reports its outcome\n(Completed/Canceled/Margin/Rejected), and always freezes trade_stop/\ntrade_target from that order's own frozen setup_stop/setup_target\nsnapshot (taken at arm time) rather than from live, possibly-since-\noverwritten pullback tracking fields. The stop/target exit orders are\nplaced as an OCO pair (Backtrader's built-in oco= link) so a fill on\none automatically cancels the other, rather than the strategy polling\ndata.high/data.low each bar and firing a lagging market close() (the\noriginal version of this file did that, and it visibly exited a full\nbar late — confirmed against real backtest output).\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass PullbackReversal(bt.Strategy):\n    params = dict(\n        ema_period=25,\n        pullback_points=0.0001,   # max distance from EMA to count as "near" (10 pips default)\n        min_leg_bars=10,          # consecutive closes on the new side of the EMA to flip leg direction\n        break_buffer=0.0001,      # entry buffer beyond the pullback bar's extreme (1 pip default)\n        max_ema_distance=0.0005,  # entry must be within this of the EMA at fill time (10 pips default)\n    )\n\n    def __init__(self):\n        self.ema = bt.indicators.EMA(self.data.close, period=self.p.ema_period)\n\n        # --- leg-direction state (flip only after min_leg_bars consecutive closes) ---\n        self.leg_dir = None          # "up" | "down" | None (undetermined at start)\n        self.candidate_dir = None    # side price is currently closing on, being counted\n        self.candidate_bars = 0      # consecutive closes counted toward a flip\n\n        # --- swing tracking (per leg) ---\n        self.swing_extreme = None    # up-leg: running highest high; down-leg: running lowest low\n\n        # --- tracked pullback bar (most recent since last new swing extreme) ---\n        self.pullback_high = None    # up-leg: that bar's high (break level, pre-buffer)\n        self.pullback_low = None     # up-leg: that bar's low (stop level); down-leg: break level\n        self.pullback_near_ema = False\n        self.pullback_slope_ok = False\n\n        # --- pending / open-trade state, kept separate on purpose (see reusable-pattern\n        #     note from the prior session: a leg-flip or new-swing-extreme must be free\n        #     to reset setup_* without ever touching an already-filled trade's risk mgmt) ---\n        self.entry_order = None\n        self.entry_order_pending_cancel = False  # True from cancel() request until notify_order confirms it's gone\n        self.setup_dir = None        # direction the currently-working entry_order was for\n        self.setup_stop = None       # frozen pullback-bar extreme at arm time, for THIS setup only\n        self.setup_target = None     # frozen swing extreme at arm time, for THIS setup only\n\n        self.trade_stop = None\n        self.trade_target = None\n        self.stop_order = None    # live Stop order guarding the open trade\n        self.target_order = None  # live Limit order guarding the open trade (OCO with stop_order)\n        self.setup_dir_for_bracket = None  # direction snapshot, read by _place_bracket right after entry fill\n\n    # ------------------------------------------------------------------\n    # helpers\n    # ------------------------------------------------------------------\n\n    def _ema_slope_up(self) -> bool:\n        if len(self.ema) < 2:\n            return False\n        return self.ema[0] > self.ema[-1]\n\n    def _ema_slope_down(self) -> bool:\n        if len(self.ema) < 2:\n            return False\n        return self.ema[0] < self.ema[-1]\n\n    def _reset_pullback_tracking(self):\n        self.pullback_high = None\n        self.pullback_low = None\n        self.pullback_near_ema = False\n        self.pullback_slope_ok = False\n\n    def _cancel_pending_setup(self):\n        """Request cancellation of a WORKING (not-yet-filled) entry order.\n        Never touches trade_stop/trade_target — those belong to an already\n        filled, currently open position, which is a separate concern.\n\n        IMPORTANT: self.cancel() only *submits* a cancel request — the\n        order is NOT synchronously removed from the broker's queue, and\n        empirically it can still go on to fill several bars later despite\n        the cancel request (verified against 1.9.78). We therefore:\n          (1) do NOT null out self.entry_order/setup_dir/setup_target\n              here — notify_order still needs them, by .ref, to freeze\n              trade_stop/trade_target correctly IF this order fills\n              anyway despite being "cancelled".\n          (2) set entry_order_pending_cancel so _maybe_arm_setup refuses\n              to place a genuinely NEW order until notify_order confirms\n              this one is actually gone (Canceled/Completed) — otherwise\n              two live Stop orders could both end up fillable and double\n              the position size.\n        The setup fields get cleared only once notify_order resolves\n        this order's outcome (see notify_order)."""\n        if self.entry_order is not None:\n            self.cancel(self.entry_order)\n            self.entry_order_pending_cancel = True\n\n    def _update_leg_and_swing(self):\n        """Runs once per bar, before anything else. Handles:\n        (1) leg-direction flip (only after min_leg_bars consecutive closes\n            on the other side of the EMA — a short poke below/above the\n            EMA during a pullback does NOT flip anything), and\n        (2) swing-extreme tracking within the current leg."""\n        close = self.data.close[0]\n\n        side = "up" if close > self.ema[0] else ("down" if close < self.ema[0] else self.candidate_dir)\n        if side is None:\n            return\n\n        if side == self.candidate_dir:\n            self.candidate_bars += 1\n        else:\n            self.candidate_dir = side\n            self.candidate_bars = 1\n\n        if self.leg_dir is None:\n            # Bootstrap: first time we have enough consecutive bars on one\n            # side, that becomes the initial leg.\n            if self.candidate_bars >= self.p.min_leg_bars:\n                self.leg_dir = side\n                self.swing_extreme = self.data.high[0] if side == "up" else self.data.low[0]\n                self._reset_pullback_tracking()\n            return\n\n        if side != self.leg_dir and self.candidate_bars >= self.p.min_leg_bars:\n            # Confirmed flip.\n            self.leg_dir = side\n            self.swing_extreme = self.data.high[0] if side == "up" else self.data.low[0]\n            self._reset_pullback_tracking()\n            # A leg flip invalidates any pending (unfilled) setup from the\n            # old leg. An OPEN trade's stop/target are untouched — they\n            # live in trade_stop/trade_target, a separate concern.\n            self._cancel_pending_setup()\n            return\n\n        # No flip (either same side, or not yet enough bars) — continue\n        # tracking the current leg's swing extreme.\n        if self.leg_dir == "up":\n            if self.data.high[0] > self.swing_extreme:\n                self.swing_extreme = self.data.high[0]\n                self._reset_pullback_tracking()\n                self._cancel_pending_setup()\n        else:\n            if self.data.low[0] < self.swing_extreme:\n                self.swing_extreme = self.data.low[0]\n                self._reset_pullback_tracking()\n                self._cancel_pending_setup()\n\n    def _update_pullback_tracking(self):\n        """Runs once per bar, after leg/swing update. If this bar is a\n        pullback bar (closes below the up-leg swing high / above the\n        down-leg swing low), it becomes the new tracked pullback bar —\n        replacing whatever was tracked before (per spec: we always watch\n        the MOST RECENT pullback bar, not the first one)."""\n        if self.leg_dir is None or self.swing_extreme is None:\n            return\n\n        close = self.data.close[0]\n        is_pullback_bar = (close < self.swing_extreme) if self.leg_dir == "up" else (close > self.swing_extreme)\n        if not is_pullback_bar:\n            return\n\n        if self.leg_dir == "up":\n            self.pullback_high = self.data.high[0]\n            self.pullback_low = self.data.low[0]\n            self.pullback_near_ema = abs(self.data.low[0] - self.ema[0]) <= self.p.pullback_points\n            self.pullback_slope_ok = self._ema_slope_up()\n        else:\n            self.pullback_high = self.data.high[0]\n            self.pullback_low = self.data.low[0]\n            self.pullback_near_ema = abs(self.data.high[0] - self.ema[0]) <= self.p.pullback_points\n            self.pullback_slope_ok = self._ema_slope_down()\n\n        # A new pullback bar supersedes any previously-working (unfilled)\n        # entry order — the break level we should be watching just moved.\n        self._cancel_pending_setup()\n\n    def _maybe_arm_setup(self):\n        """If we have a qualifying tracked pullback bar and no order is\n        currently working, place the Stop order."""\n        if self.entry_order is not None or self.entry_order_pending_cancel:\n            return\n        if self.leg_dir is None or self.pullback_high is None:\n            return\n        if not (self.pullback_near_ema and self.pullback_slope_ok):\n            return\n\n        if self.leg_dir == "up":\n            trigger_price = self.pullback_high + self.p.break_buffer\n            self.entry_order = self.buy(exectype=bt.Order.Stop, price=trigger_price)\n            self.setup_stop = self.pullback_low\n        else:\n            trigger_price = self.pullback_low - self.p.break_buffer\n            self.entry_order = self.sell(exectype=bt.Order.Stop, price=trigger_price)\n            self.setup_stop = self.pullback_high\n\n        self.setup_dir = self.leg_dir\n        self.setup_target = self.swing_extreme\n\n    def _place_bracket(self):\n        """Called once, right when the entry order fills (from\n        notify_order — never from next(), for the same one-bar-late\n        reason documented there). Places the stop and target as real\n        Stop/Limit orders, linked OCO so a fill on either cancels the\n        other, so both exit intrabar at the exact price rather than one\n        bar late via a market close() reacting after the fact."""\n        if self.setup_dir_for_bracket == "up":\n            self.stop_order = self.sell(exectype=bt.Order.Stop, price=self.trade_stop)\n            self.target_order = self.sell(exectype=bt.Order.Limit, price=self.trade_target,\n                                           oco=self.stop_order)\n        else:\n            self.stop_order = self.buy(exectype=bt.Order.Stop, price=self.trade_stop)\n            self.target_order = self.buy(exectype=bt.Order.Limit, price=self.trade_target,\n                                          oco=self.stop_order)\n\n    # ------------------------------------------------------------------\n    # main loop\n    # ------------------------------------------------------------------\n\n    def next(self):\n        if len(self.ema) < 2:\n            return  # not enough bars for a slope yet\n\n        # If a position is open, its exit is fully handled by the\n        # stop/target bracket (real Stop/Limit orders placed once in\n        # notify_order right when the entry filled) — nothing to poll\n        # here. Just skip the flat-only setup logic below.\n        if self.position:\n            return\n\n        # Flat: look for / maintain a pending setup.\n        self._update_leg_and_swing()\n        self._update_pullback_tracking()\n        self._maybe_arm_setup()\n\n        if self.entry_order is not None and not self.entry_order_pending_cancel:\n            trigger = (self.pullback_high + self.p.break_buffer) if self.setup_dir == "up" \\\n                else (self.pullback_low - self.p.break_buffer)\n            if abs(trigger - self.ema[0]) > self.p.max_ema_distance:\n                self._cancel_pending_setup()\n                self._reset_pullback_tracking()\n\n    def notify_order(self, order):\n        # IMPORTANT: Backtrader delivers notify_order a DIFFERENT Order\n        # object instance than the one self.buy()/self.sell() returned\n        # (a notification-queue copy), so `order is self.entry_order`\n        # never matches even for the exact same order. Compare by .ref.\n        is_entry_order = self.entry_order is not None and order.ref == self.entry_order.ref\n        is_stop_order = self.stop_order is not None and order.ref == self.stop_order.ref\n        is_target_order = self.target_order is not None and order.ref == self.target_order.ref\n\n        if is_entry_order:\n            if order.status == order.Completed:\n                # Freeze the trade's own stop/target from the FROZEN\n                # setup_* snapshot taken at arm time — never from the\n                # live pullback_* fields, which may already have been\n                # overwritten by a newer pullback bar by the time a\n                # "cancelled" order fills anyway (self.cancel() doesn't\n                # guarantee synchronous removal from the broker —\n                # verified empirically against 1.9.78: a cancelled Stop\n                # order can still fill several bars later).\n                self.trade_stop = self.setup_stop\n                self.trade_target = self.setup_target\n                self.entry_order = None\n                self.entry_order_pending_cancel = False\n                self.setup_dir_for_bracket = self.setup_dir  # _place_bracket needs this before we clear setup_dir\n                self.setup_dir = None\n                self.setup_stop = None\n                self.setup_target = None\n                self._reset_pullback_tracking()\n                self._place_bracket()\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.entry_order = None\n                self.entry_order_pending_cancel = False\n                self.setup_dir = None\n                self.setup_stop = None\n                self.setup_target = None\n            return\n\n        if is_stop_order or is_target_order:\n            if order.status == order.Completed:\n                # OCO means the sibling order is auto-cancelled by the\n                # broker; still clear our own refs so we don't hold a\n                # stale reference to it.\n                self.stop_order = None\n                self.target_order = None\n                self.trade_stop = None\n                self.trade_target = None\n            elif order.status == order.Canceled:\n                # Expected for the sibling of whichever order just filled\n                # (OCO cancellation) — nothing to do beyond clearing it.\n                if is_stop_order:\n                    self.stop_order = None\n                if is_target_order:\n                    self.target_order = None\n\n    def notify_trade(self, trade):\n        if trade.isclosed:\n            self.trade_stop = None\n            self.trade_target = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -2.082319544459546, "trades": 77}, "VWR": {"vwr": -0.00000001717214829259407}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.0000000001783955415030157, "rtot": -0.0000005070001289515706, "rnorm": -0.00000000017839554148710322, "rnorm100": -0.000000017839554148710322}, "DrawDown": {"len": 2782, "max": {"len": 2782, "drawdown": 0.00006100000002334127, "moneydown": 0.006100000002334127}, "drawdown": 0.000050700000047072534, "moneydown": 0.0050700000047072535}, "SharpeRatio": {"sharperatio": -9.185835252784248}, "AnnualReturn": {"2026": -0.000000507000000427027}, "TimeDrawDown": {"maxdrawdown": 0.00006100000002334127, "maxdrawdownperiod": 2782}, "TradeAnalyzer": {"len": {"max": 53, "min": 1, "won": {"max": 24, "min": 1, "total": 139, "average": 4.34375}, "long": {"max": 24, "min": 1, "won": {"max": 24, "min": 1, "total": 88, "average": 5.5}, "lost": {"max": 19, "min": 1, "total": 84, "average": 3.8181818181818183}, "total": 172, "average": 4.526315789473684}, "lost": {"max": 53, "min": 1, "total": 235, "average": 5.222222222222222}, "short": {"max": 53, "min": 1, "won": {"max": 14, "min": 1, "total": 51, "average": 3.1875}, "lost": {"max": 53, "min": 1, "total": 151, "average": 6.565217391304348}, "total": 202, "average": 5.17948717948718}, "total": 374, "average": 4.857142857142857}, "pnl": {"net": {"total": -0.005049999999999111, "average": -0.00006558441558440404}, "gross": {"total": -0.005049999999999111, "average": -0.00006558441558440404}}, "won": {"pnl": {"max": 0.0009000000000001229, "total": 0.006070000000000686, "average": 0.00018968750000002144}, "total": 32}, "long": {"pnl": {"won": {"max": 0.0009000000000001229, "total": 0.003770000000000495, "average": 0.00023562500000003095}, "lost": {"max": -0.0006699999999999484, "total": -0.00537999999999994, "average": -0.0002445454545454518}, "total": -0.0016099999999994452, "average": -0.00004236842105261698}, "won": 16, "lost": 22, "total": 38}, "lost": {"pnl": {"max": -0.0006699999999999484, "total": -0.011119999999999797, "average": -0.0002471111111111066}, "total": 45}, "short": {"pnl": {"won": {"max": 0.00026999999999999247, "total": 0.0023000000000001908, "average": 0.00014375000000001192}, "lost": {"max": -0.0005100000000000104, "total": -0.005739999999999856, "average": -0.0002495652173912981}, "total": -0.0034399999999996655, "average": -0.00008820512820511963}, "won": 16, "lost": 23, "total": 39}, "total": {"open": 1, "total": 78, "closed": 77}, "streak": {"won": {"current": 0, "longest": 3}, "lost": {"current": 1, "longest": 6}}}}	2026-09-22 08:50:18.512574+00	2026-09-22 08:51:09.043542+00
9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	turtle_trading	turtle_trading.py	"""\nTurtle Trading — Backtrader.\n\nA faithful implementation of the classic "Turtle" system (Richard\nDennis / William Eckhardt, as popularized by Curtis Faith's "Way of\nthe Turtle"). This is System 1 of the original two-system approach:\n\nEntry\n    Donchian channel breakout: go long when price closes above the\n    highest high of the last `entry_period` bars (default 20), go\n    short when price closes below the lowest low of the last\n    `entry_period` bars. The classic "skip a losing breakout" filter\n    (System 1's 55-day fallback) is OMITTED here for simplicity —\n    this is the vanilla breakout-only variant, sometimes called\n    "System 1 without the filter."\n\nExit\n    Donchian channel reversal, shorter lookback: exit a long when\n    price closes below the lowest low of the last `exit_period` bars\n    (default 10); exit a short when price closes above the highest\n    high of the last `exit_period` bars.\n\nStop-loss\n    2N stop (N = ATR(atr_period), the Turtles' volatility unit):\n    stop = entry_price - 2*N for a long, entry_price + 2*N for a\n    short. This is the original system's risk control — it is NOT\n    the same as the exit rule above; whichever is hit first closes\n    the trade.\n\nPosition sizing / pyramiding\n    The original Turtles risked 1% of equity per N of movement and\n    added up to 4 units (pyramiding) as the trade moved 0.5N in their\n    favor, trailing each unit's stop up together. This implementation\n    keeps the core breakout/exit/stop logic faithful but uses a\n    single unit per signal (no pyramiding) for simplicity and\n    determinism in a backtest context — pyramiding multiplies the\n    position-sizing complexity considerably and is easy to add later\n    as a parameter if wanted. Position size is still risk-based: unit\n    size = (equity * risk_pct) / (N * point_value), the standard\n    Turtle sizing formula, clamped to at least 1 unit.\n\nOnly ever in one position at a time (no simultaneous long+short —\nDonchian breakout systems are naturally one-directional per regime).\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass TurtleTrading(bt.Strategy):\n    params = dict(\n        entry_period=20,   # Donchian breakout lookback for entries\n        exit_period=10,    # Donchian breakout lookback for exits\n        atr_period=20,     # N (volatility unit) lookback\n        stop_atr_mult=2.0, # stop = entry +/- stop_atr_mult * N\n        risk_pct=0.01,     # fraction of equity risked per N of adverse move\n        point_value=1.0,   # value of 1 price unit per contract/share (1.0 for FX/CFD-style instruments)\n    )\n\n    def __init__(self):\n        self.entry_high = bt.indicators.Highest(self.data.high, period=self.p.entry_period)\n        self.entry_low = bt.indicators.Lowest(self.data.low, period=self.p.entry_period)\n        self.exit_high = bt.indicators.Highest(self.data.high, period=self.p.exit_period)\n        self.exit_low = bt.indicators.Lowest(self.data.low, period=self.p.exit_period)\n        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)\n\n        self.entry_order = None\n        self.stop_order = None\n        self.trade_dir = None  # "long" | "short" | None\n\n    def _warm(self) -> bool:\n        # Longest lookback among the indicators in use, plus 1 so the\n        # prior-bar reference (`[-1]`) used for breakout comparisons is\n        # itself valid.\n        needed = max(self.p.entry_period, self.p.exit_period, self.p.atr_period) + 1\n        return len(self.data) >= needed\n\n    def _unit_size(self) -> int:\n        n = self.atr[0]\n        if n <= 0:\n            return 0\n        equity = self.broker.getvalue()\n        risk_amount = equity * self.p.risk_pct\n        size = risk_amount / (n * self.p.point_value)\n        return max(1, int(size))\n\n    def next(self):\n        if not self._warm():\n            return\n\n        if self.position:\n            self._manage_exit()\n        else:\n            self._check_entry()\n\n    def _check_entry(self):\n        if self.entry_order is not None:\n            return\n\n        close = self.data.close[0]\n        # Compare against the PRIOR bar's channel (a breakout is defined\n        # relative to the channel that existed before this bar formed —\n        # using this bar's own high/low in the lookback would let a bar\n        # "break out of itself").\n        prior_high = self.entry_high[-1]\n        prior_low = self.entry_low[-1]\n\n        size = self._unit_size()\n        if size <= 0:\n            return\n\n        if close > prior_high:\n            self.entry_order = self.buy(size=size)\n            self.trade_dir = "long"\n        elif close < prior_low:\n            self.entry_order = self.sell(size=size)\n            self.trade_dir = "short"\n\n    def _manage_exit(self):\n        close = self.data.close[0]\n\n        if self.trade_dir == "long":\n            prior_exit_low = self.exit_low[-1]\n            if close < prior_exit_low:\n                self.close()\n        else:\n            prior_exit_high = self.exit_high[-1]\n            if close > prior_exit_high:\n                self.close()\n\n    def notify_order(self, order):\n        is_entry_order = self.entry_order is not None and order.ref == self.entry_order.ref\n        is_stop_order = self.stop_order is not None and order.ref == self.stop_order.ref\n\n        if is_entry_order:\n            if order.status == order.Completed:\n                self.entry_order = None\n                n = self.atr[0]\n                if self.trade_dir == "long":\n                    stop_price = order.executed.price - self.p.stop_atr_mult * n\n                    self.stop_order = self.sell(exectype=bt.Order.Stop, price=stop_price, size=order.executed.size)\n                else:\n                    stop_price = order.executed.price + self.p.stop_atr_mult * n\n                    self.stop_order = self.buy(exectype=bt.Order.Stop, price=stop_price, size=abs(order.executed.size))\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.entry_order = None\n                self.trade_dir = None\n            return\n\n        if is_stop_order:\n            if order.status == order.Completed:\n                self.stop_order = None\n                self.trade_dir = None\n            elif order.status == order.Canceled:\n                self.stop_order = None\n\n    def notify_trade(self, trade):\n        if trade.isclosed:\n            # A Donchian-exit close() leaves the 2N stop order still\n            # working (it was placed independently of the exit rule) —\n            # cancel it so it doesn't fire against a position that's\n            # already flat.\n            if self.stop_order is not None:\n                self.cancel(self.stop_order)\n                self.stop_order = None\n            self.trade_dir = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -1.9757172695045913, "trades": 42}, "VWR": {"vwr": -0.0041792301696198025}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.00008765026665654571, "rtot": -0.23981112957230907, "rnorm": -0.00008764642548415065, "rnorm100": -0.008764642548415065}, "DrawDown": {"len": 2672, "max": {"len": 2672, "drawdown": 24.447122805717726, "moneydown": 2450.693513637423}, "drawdown": 21.514378338128083, "moneydown": 2156.701541617018}, "SharpeRatio": {"sharperatio": -8.273658075014245}, "AnnualReturn": {"2026": -0.21322355416170036}, "TimeDrawDown": {"maxdrawdown": 24.447122805717726, "maxdrawdownperiod": 2672}, "TradeAnalyzer": {"len": {"max": 86, "min": 1, "won": {"max": 86, "min": 15, "total": 459, "average": 35.30769230769231}, "long": {"max": 0, "min": 9223372036854775807, "won": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "lost": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "total": 0, "average": 0.0}, "lost": {"max": 66, "min": 1, "total": 394, "average": 13.586206896551724}, "short": {"max": 86, "min": 1, "won": {"max": 86, "min": 15, "total": 459, "average": 35.30769230769231}, "lost": {"max": 66, "min": 1, "total": 394, "average": 13.586206896551724}, "total": 853, "average": 20.30952380952381}, "total": 853, "average": 20.30952380952381}, "pnl": {"net": {"total": -2098.175541617045, "average": -49.956560514691546}, "gross": {"total": -2098.175541617045, "average": -49.956560514691546}}, "won": {"pnl": {"max": 583.2000000000016, "total": 1937.2449999999671, "average": 149.01884615384364}, "total": 13}, "long": {"pnl": {"won": {"max": 0.0, "total": 0.0, "average": 0.0}, "lost": {"max": 0.0, "total": 0.0, "average": 0.0}, "total": 0.0, "average": 0.0}, "won": 0, "lost": 0, "total": 0}, "lost": {"pnl": {"max": -197.82248229322158, "total": -4035.420541617012, "average": -139.15243246955214}, "total": 29}, "short": {"pnl": {"won": {"max": 583.2000000000016, "total": 1937.2449999999671, "average": 149.01884615384364}, "lost": {"max": -197.82248229322158, "total": -4035.420541617012, "average": -139.15243246955214}, "total": -2098.175541617045, "average": -49.956560514691546}, "won": 13, "lost": 29, "total": 42}, "total": {"open": 1, "total": 43, "closed": 42}, "streak": {"won": {"current": 0, "longest": 3}, "lost": {"current": 2, "longest": 8}}}}	2026-09-22 09:27:28.867557+00	2026-09-22 09:28:49.090835+00
fcb7d560-a7de-4376-9ca4-9917aef450d7	mean_reversion	mean_reversion.py	"""\nBollinger + RSI Mean Reversion — Backtrader.\n\nBuilt for intraday, range-bound FX (this is tuned with 5-minute\nEURUSD specifically in mind) rather than trending futures markets.\nWhere Turtle Trading fades badly on 5m EURUSD because that pair\nrarely trends cleanly at that timeframe, this strategy is designed\nto profit FROM the chop: it fades price back toward the mean after\na statistically stretched move, and gets out of the way when a real\ntrend actually develops.\n\nEntry\n    Long  when close touches/crosses below the LOWER Bollinger Band\n          AND RSI is oversold (< rsi_low) — price is stretched and\n          momentum confirms exhaustion, not just noise.\n    Short when close touches/crosses above the UPPER Bollinger Band\n          AND RSI is overbought (> rsi_high).\n\nTrend filter (the important part)\n    Mean reversion gets destroyed trading INTO a strong trend. A\n    long-period EMA is used as a regime filter, but it has to be\n    checked on the EMA's own SLOPE, not on price vs. EMA at the\n    moment of entry: a long is only taken on an oversold dip when\n    the EMA itself is flat-to-rising, and a short only taken on an\n    overbought spike when the EMA is flat-to-falling. (Checking\n    "close above EMA" at the same instant close is testing "oversold,\n    below the lower Bollinger Band" is nearly self-contradictory —\n    price stretched far enough to tag the lower band is almost always\n    also below a 200-period EMA, so that naive filter would silently\n    veto nearly every long. Slope avoids that trap.) This is what\n    should meaningfully lift the win rate vs. an unfiltered Bollinger\n    fade, by refusing to fade a dip inside a real downtrend (or a\n    spike inside a real uptrend) — mean reversion's biggest loss\n    source — while still allowing fades within a flat/ranging regime.\n\nExit\n    Take-profit at entry +/- reward_r * stop_distance, i.e. a fixed\n    R-multiple of the stop (default 1.2R) rather than the Bollinger\n    midline. The midline looks like the obvious target for a\n    reversion trade, but it is usually MUCH farther from entry than\n    a tight ATR stop is — testing showed this makes the target 2-4x\n    wider than the stop, so ordinary noise stops the trade out long\n    before price could ever travel that far, and win rate collapses\n    to near zero regardless of how often price actually does revert.\n    An R-multiple target keeps risk and reward on a comparable scale\n    so the trade has a realistic chance to reach it before the stop.\n    Both stop and target are placed as a bracket (Stop + Limit) the\n    moment entry fills, inside notify_order, so neither is ever a bar\n    late; whichever is touched first closes the trade.\n\nPosition sizing\n    Fixed-fractional risk: unit size = (equity * risk_pct) / stop_distance,\n    i.e. you always risk the same % of equity regardless of how wide\n    today's stop is. Clamped to at least 1 unit.\n\nOnly one position open at a time.\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass MeanReversion(bt.Strategy):\n    params = dict(\n        bb_period=20,       # Bollinger Band lookback\n        bb_dev=2.0,         # Bollinger Band std-dev multiplier\n        rsi_period=14,      # RSI lookback\n        rsi_low=30,         # oversold threshold (long trigger)\n        rsi_high=70,        # overbought threshold (short trigger)\n        trend_ema_period=200,  # regime filter EMA\n        trend_slope_lookback=20,  # bars back to measure the EMA's slope over\n        atr_period=14,      # for stop sizing\n        stop_atr_mult=1.5,  # stop = entry -/+ stop_atr_mult * ATR\n        reward_r=1.2,       # target = entry +/- reward_r * stop_distance\n        risk_pct=0.01,      # fraction of equity risked per trade\n        point_value=1.0,    # value of 1 price unit per unit size (1.0 for FX/CFD-style instruments)\n    )\n\n    def __init__(self):\n        self.bb = bt.indicators.BollingerBands(self.data.close, period=self.p.bb_period, devfactor=self.p.bb_dev)\n        self.rsi = bt.indicators.RSI(self.data.close, period=self.p.rsi_period)\n        self.trend_ema = bt.indicators.EMA(self.data.close, period=self.p.trend_ema_period)\n        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)\n\n        self.entry_order = None\n        self.stop_order = None\n        self.limit_order = None\n        self.trade_dir = None  # "long" | "short" | None\n\n    def _warm(self) -> bool:\n        needed = max(self.p.bb_period, self.p.rsi_period, self.p.atr_period,\n                     self.p.trend_ema_period + self.p.trend_slope_lookback) + 1\n        return len(self.data) >= needed\n\n    def _unit_size(self, stop_distance: float) -> int:\n        if stop_distance <= 0:\n            return 0\n        equity = self.broker.getvalue()\n        risk_amount = equity * self.p.risk_pct\n        size = risk_amount / (stop_distance * self.p.point_value)\n        return max(1, int(size))\n\n    def next(self):\n        if not self._warm():\n            return\n\n        if self.position:\n            return  # exits are handled by the bracket stop/limit orders themselves\n        if self.entry_order is not None:\n            return\n\n        close = self.data.close[0]\n        # Regime check on the EMA's SLOPE (not price vs. EMA — see the\n        # class docstring for why that naive version self-defeats).\n        ema_rising = self.trend_ema[0] >= self.trend_ema[-self.p.trend_slope_lookback]\n        ema_falling = self.trend_ema[0] <= self.trend_ema[-self.p.trend_slope_lookback]\n\n        long_signal = close <= self.bb.lines.bot[0] and self.rsi[0] < self.p.rsi_low and ema_rising\n        short_signal = close >= self.bb.lines.top[0] and self.rsi[0] > self.p.rsi_high and ema_falling\n\n        atr = self.atr[0]\n        if atr <= 0:\n            return\n        stop_distance = self.p.stop_atr_mult * atr\n        size = self._unit_size(stop_distance)\n        if size <= 0:\n            return\n\n        if long_signal:\n            self.entry_order = self.buy(size=size)\n            self.trade_dir = "long"\n        elif short_signal:\n            self.entry_order = self.sell(size=size)\n            self.trade_dir = "short"\n\n    def notify_order(self, order):\n        is_entry = self.entry_order is not None and order.ref == self.entry_order.ref\n        is_stop = self.stop_order is not None and order.ref == self.stop_order.ref\n        is_limit = self.limit_order is not None and order.ref == self.limit_order.ref\n\n        if is_entry:\n            if order.status == order.Completed:\n                self.entry_order = None\n                atr = self.atr[0]\n                entry_price = order.executed.price\n                stop_distance = self.p.stop_atr_mult * atr\n                size = abs(order.executed.size)\n\n                if self.trade_dir == "long":\n                    stop_price = entry_price - stop_distance\n                    target_price = entry_price + self.p.reward_r * stop_distance\n                    self.stop_order = self.sell(exectype=bt.Order.Stop, price=stop_price, size=size)\n                    self.limit_order = self.sell(exectype=bt.Order.Limit, price=target_price, size=size)\n                else:\n                    stop_price = entry_price + stop_distance\n                    target_price = entry_price - self.p.reward_r * stop_distance\n                    self.stop_order = self.buy(exectype=bt.Order.Stop, price=stop_price, size=size)\n                    self.limit_order = self.buy(exectype=bt.Order.Limit, price=target_price, size=size)\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.entry_order = None\n                self.trade_dir = None\n            return\n\n        if is_stop or is_limit:\n            if order.status == order.Completed:\n                # Whichever bracket leg filled, cancel the other so it\n                # doesn't fire later against a position that's already flat.\n                other = self.limit_order if is_stop else self.stop_order\n                if other is not None and other.status not in (other.Completed, other.Canceled, other.Margin, other.Rejected):\n                    self.cancel(other)\n                self.stop_order = None\n                self.limit_order = None\n                self.trade_dir = None\n            elif order.status == order.Canceled:\n                if is_stop:\n                    self.stop_order = None\n                else:\n                    self.limit_order = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -67.74646204562049, "trades": 4}, "VWR": {"vwr": -0.0009251138435833542}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.00001447037166622758, "rtot": -0.04112479627541878, "rnorm": -0.000014470266970904495, "rnorm100": -0.0014470266970904495}, "DrawDown": {"len": 461, "max": {"len": 595, "drawdown": 11.15741600703494, "moneydown": 1205.2639658537228}, "drawdown": 11.15741600703494, "moneydown": 1205.2639658537228}, "SharpeRatio": {"sharperatio": -8.996650278618809}, "AnnualReturn": {"2026": -0.040290645678725534}, "TimeDrawDown": {"maxdrawdown": 11.15741600703494, "maxdrawdownperiod": 595}, "TradeAnalyzer": {"len": {"max": 107, "min": 4, "won": {"max": 0, "total": 0, "average": 0.0}, "long": {"max": 0, "min": 9223372036854775807, "won": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "lost": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "total": 0, "average": 0.0}, "lost": {"max": 107, "min": 4, "total": 123, "average": 30.75}, "short": {"max": 107, "min": 4, "won": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "lost": {"max": 107, "min": 4, "total": 123, "average": 30.75}, "total": 123, "average": 30.75}, "total": 123, "average": 30.75}, "pnl": {"net": {"total": -402.90645678732176, "average": -100.72661419683044}, "gross": {"total": -402.90645678732176, "average": -100.72661419683044}}, "won": {"pnl": {"max": 0.0, "total": 0.0, "average": 0.0}, "total": 0}, "long": {"pnl": {"won": {"max": 0.0, "total": 0.0, "average": 0.0}, "lost": {"max": 0.0, "total": 0.0, "average": 0.0}, "total": 0.0, "average": 0.0}, "won": 0, "lost": 0, "total": 0}, "lost": {"pnl": {"max": -105.64925855316068, "total": -402.90645678732176, "average": -100.72661419683044}, "total": 4}, "short": {"pnl": {"won": {"max": 0.0, "total": 0.0, "average": 0.0}, "lost": {"max": -105.64925855316068, "total": -402.90645678732176, "average": -100.72661419683044}, "total": -402.90645678732176, "average": -100.72661419683044}, "won": 0, "lost": 4, "total": 4}, "total": {"open": 0, "total": 4, "closed": 4}, "streak": {"won": {"current": 0, "longest": 0}, "lost": {"current": 4, "longest": 4}}}}	2026-09-22 09:32:00.382212+00	2026-09-22 09:32:52.695731+00
7ae667fa-4eda-4190-a572-5f02ba6dada5	turtle_trading	turtle_trading.py	"""\nTurtle Trading — Backtrader.\n\nA faithful implementation of the classic "Turtle" system (Richard\nDennis / William Eckhardt, as popularized by Curtis Faith's "Way of\nthe Turtle"). This is System 1 of the original two-system approach:\n\nEntry\n    Donchian channel breakout: go long when price closes above the\n    highest high of the last `entry_period` bars (default 20), go\n    short when price closes below the lowest low of the last\n    `entry_period` bars. The classic "skip a losing breakout" filter\n    (System 1's 55-day fallback) is OMITTED here for simplicity —\n    this is the vanilla breakout-only variant, sometimes called\n    "System 1 without the filter."\n\nExit\n    Donchian channel reversal, shorter lookback: exit a long when\n    price closes below the lowest low of the last `exit_period` bars\n    (default 10); exit a short when price closes above the highest\n    high of the last `exit_period` bars.\n\nStop-loss\n    2N stop (N = ATR(atr_period), the Turtles' volatility unit):\n    stop = entry_price - 2*N for a long, entry_price + 2*N for a\n    short. This is the original system's risk control — it is NOT\n    the same as the exit rule above; whichever is hit first closes\n    the trade.\n\nPosition sizing / pyramiding\n    The original Turtles risked 1% of equity per N of movement and\n    added up to 4 units (pyramiding) as the trade moved 0.5N in their\n    favor, trailing each unit's stop up together. This implementation\n    keeps the core breakout/exit/stop logic faithful but uses a\n    single unit per signal (no pyramiding) for simplicity and\n    determinism in a backtest context — pyramiding multiplies the\n    position-sizing complexity considerably and is easy to add later\n    as a parameter if wanted. Position size is still risk-based: unit\n    size = (equity * risk_pct) / (N * point_value), the standard\n    Turtle sizing formula, clamped to at least 1 unit.\n\nOnly ever in one position at a time (no simultaneous long+short —\nDonchian breakout systems are naturally one-directional per regime).\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass TurtleTrading(bt.Strategy):\n    params = dict(\n        entry_period=20,   # Donchian breakout lookback for entries\n        exit_period=10,    # Donchian breakout lookback for exits\n        atr_period=20,     # N (volatility unit) lookback\n        stop_atr_mult=2.0, # stop = entry +/- stop_atr_mult * N\n        risk_pct=0.01,     # fraction of equity risked per N of adverse move\n        point_value=1.0,   # value of 1 price unit per contract/share (1.0 for FX/CFD-style instruments)\n    )\n\n    def __init__(self):\n        self.entry_high = bt.indicators.Highest(self.data.high, period=self.p.entry_period)\n        self.entry_low = bt.indicators.Lowest(self.data.low, period=self.p.entry_period)\n        self.exit_high = bt.indicators.Highest(self.data.high, period=self.p.exit_period)\n        self.exit_low = bt.indicators.Lowest(self.data.low, period=self.p.exit_period)\n        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)\n\n        self.entry_order = None\n        self.stop_order = None\n        self.trade_dir = None  # "long" | "short" | None\n\n    def _warm(self) -> bool:\n        # Longest lookback among the indicators in use, plus 1 so the\n        # prior-bar reference (`[-1]`) used for breakout comparisons is\n        # itself valid.\n        needed = max(self.p.entry_period, self.p.exit_period, self.p.atr_period) + 1\n        return len(self.data) >= needed\n\n    def _unit_size(self) -> int:\n        n = self.atr[0]\n        if n <= 0:\n            return 0\n        equity = self.broker.getvalue()\n        risk_amount = equity * self.p.risk_pct\n        size = risk_amount / (n * self.p.point_value)\n        return max(1, int(size))\n\n    def next(self):\n        if not self._warm():\n            return\n\n        if self.position:\n            self._manage_exit()\n        else:\n            self._check_entry()\n\n    def _check_entry(self):\n        if self.entry_order is not None:\n            return\n\n        close = self.data.close[0]\n        # Compare against the PRIOR bar's channel (a breakout is defined\n        # relative to the channel that existed before this bar formed —\n        # using this bar's own high/low in the lookback would let a bar\n        # "break out of itself").\n        prior_high = self.entry_high[-1]\n        prior_low = self.entry_low[-1]\n\n        size = self._unit_size()\n        if size <= 0:\n            return\n\n        if close > prior_high:\n            self.entry_order = self.buy(size=size)\n            self.trade_dir = "long"\n        elif close < prior_low:\n            self.entry_order = self.sell(size=size)\n            self.trade_dir = "short"\n\n    def _manage_exit(self):\n        close = self.data.close[0]\n\n        if self.trade_dir == "long":\n            prior_exit_low = self.exit_low[-1]\n            if close < prior_exit_low:\n                self.close()\n        else:\n            prior_exit_high = self.exit_high[-1]\n            if close > prior_exit_high:\n                self.close()\n\n    def notify_order(self, order):\n        is_entry_order = self.entry_order is not None and order.ref == self.entry_order.ref\n        is_stop_order = self.stop_order is not None and order.ref == self.stop_order.ref\n\n        if is_entry_order:\n            if order.status == order.Completed:\n                self.entry_order = None\n                n = self.atr[0]\n                if self.trade_dir == "long":\n                    stop_price = order.executed.price - self.p.stop_atr_mult * n\n                    self.stop_order = self.sell(exectype=bt.Order.Stop, price=stop_price, size=order.executed.size)\n                else:\n                    stop_price = order.executed.price + self.p.stop_atr_mult * n\n                    self.stop_order = self.buy(exectype=bt.Order.Stop, price=stop_price, size=abs(order.executed.size))\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.entry_order = None\n                self.trade_dir = None\n            return\n\n        if is_stop_order:\n            if order.status == order.Completed:\n                self.stop_order = None\n                self.trade_dir = None\n            elif order.status == order.Canceled:\n                self.stop_order = None\n\n    def notify_trade(self, trade):\n        if trade.isclosed:\n            # A Donchian-exit close() leaves the 2N stop order still\n            # working (it was placed independently of the exit rule) —\n            # cancel it so it doesn't fire against a position that's\n            # already flat.\n            if self.stop_order is not None:\n                self.cancel(self.stop_order)\n                self.stop_order = None\n            self.trade_dir = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -4.425724391867554, "trades": 50}, "VWR": {"vwr": -0.006658010352234181}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.00017674793020577836, "rtot": -0.5023176176448221, "rnorm": -0.00017673231121058427, "rnorm100": -0.017673231121058428}, "DrawDown": {"len": 2754, "max": {"len": 2754, "drawdown": 42.43261573545736, "moneydown": 4304.342097594286}, "drawdown": 40.34604334204102, "moneydown": 4092.681297594274}, "SharpeRatio": {"sharperatio": -14.52216256523357}, "AnnualReturn": {"2026": -0.39487341875943816}, "TimeDrawDown": {"maxdrawdown": 42.43261573545736, "maxdrawdownperiod": 2754}, "TradeAnalyzer": {"len": {"max": 73, "min": 1, "won": {"max": 73, "min": 27, "total": 476, "average": 43.27272727272727}, "long": {"max": 0, "min": 9223372036854775807, "won": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "lost": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "total": 0, "average": 0.0}, "lost": {"max": 21, "min": 1, "total": 333, "average": 8.538461538461538}, "short": {"max": 73, "min": 1, "won": {"max": 73, "min": 27, "total": 476, "average": 43.27272727272727}, "lost": {"max": 21, "min": 1, "total": 333, "average": 8.538461538461538}, "total": 809, "average": 16.18}, "total": 809, "average": 16.18}, "pnl": {"net": {"total": -3948.7341875948678, "average": -78.97468375189736}, "gross": {"total": -3948.7341875948678, "average": -78.97468375189736}}, "won": {"pnl": {"max": 284.4493999999578, "total": 1463.510949999958, "average": 133.04644999999618}, "total": 11}, "long": {"pnl": {"won": {"max": 0.0, "total": 0.0, "average": 0.0}, "lost": {"max": 0.0, "total": 0.0, "average": 0.0}, "total": 0.0, "average": 0.0}, "won": 0, "lost": 0, "total": 0}, "lost": {"pnl": {"max": -200.18308373269355, "total": -5412.245137594828, "average": -138.7755163485853}, "total": 39}, "short": {"pnl": {"won": {"max": 284.4493999999578, "total": 1463.510949999958, "average": 133.04644999999618}, "lost": {"max": -200.18308373269355, "total": -5412.245137594828, "average": -138.7755163485853}, "total": -3948.7341875948678, "average": -78.97468375189736}, "won": 11, "lost": 39, "total": 50}, "total": {"open": 0, "total": 50, "closed": 50}, "streak": {"won": {"current": 1, "longest": 2}, "lost": {"current": 0, "longest": 11}}}}	2026-09-22 09:22:03.956943+00	2026-09-22 09:22:51.725892+00
77e3c523-dce8-43c3-973e-9b6c483be579	mean_reversion-1	mean_reversion-1.py	"""\nBollinger + RSI Mean Reversion — Backtrader.\n\nBuilt for intraday, range-bound FX (this is tuned with 5-minute\nEURUSD specifically in mind) rather than trending futures markets.\nWhere Turtle Trading fades badly on 5m EURUSD because that pair\nrarely trends cleanly at that timeframe, this strategy is designed\nto profit FROM the chop: it fades price back toward the mean after\na statistically stretched move, and gets out of the way when a real\ntrend actually develops.\n\nEntry\n    Long  when close touches/crosses below the LOWER Bollinger Band\n          AND RSI is oversold (< rsi_low) — price is stretched and\n          momentum confirms exhaustion, not just noise.\n    Short when close touches/crosses above the UPPER Bollinger Band\n          AND RSI is overbought (> rsi_high).\n\nTrend filter (the important part)\n    Mean reversion gets destroyed trading INTO a strong trend. A\n    long-period EMA is used as a regime filter, but it has to be\n    checked on the EMA's own SLOPE, not on price vs. EMA at the\n    moment of entry: a long is only taken on an oversold dip when\n    the EMA itself is flat-to-rising, and a short only taken on an\n    overbought spike when the EMA is flat-to-falling. (Checking\n    "close above EMA" at the same instant close is testing "oversold,\n    below the lower Bollinger Band" is nearly self-contradictory —\n    price stretched far enough to tag the lower band is almost always\n    also below a 200-period EMA, so that naive filter would silently\n    veto nearly every long. Slope avoids that trap.) This is what\n    should meaningfully lift the win rate vs. an unfiltered Bollinger\n    fade, by refusing to fade a dip inside a real downtrend (or a\n    spike inside a real uptrend) — mean reversion's biggest loss\n    source — while still allowing fades within a flat/ranging regime.\n\nExit\n    Take-profit at entry +/- reward_r * stop_distance, i.e. a fixed\n    R-multiple of the stop (default 1.2R) rather than the Bollinger\n    midline. The midline looks like the obvious target for a\n    reversion trade, but it is usually MUCH farther from entry than\n    a tight ATR stop is — testing showed this makes the target 2-4x\n    wider than the stop, so ordinary noise stops the trade out long\n    before price could ever travel that far, and win rate collapses\n    to near zero regardless of how often price actually does revert.\n    An R-multiple target keeps risk and reward on a comparable scale\n    so the trade has a realistic chance to reach it before the stop.\n    Both stop and target are placed as a bracket (Stop + Limit) the\n    moment entry fills, inside notify_order, so neither is ever a bar\n    late; whichever is touched first closes the trade.\n\nVolatility floor (the fix for the real-data failure mode)\n    A pure `stop_atr_mult * ATR` stop breaks down when ATR itself is\n    tiny — e.g. during the dead Asian-session hours (~00:00-02:00\n    UTC) where 5m EURUSD can trade in a range under 1 pip. In that\n    regime the stop sits so close to entry that ordinary bid/ask\n    noise trips it almost immediately — and because position size is\n    solved backward from stop distance to hit a fixed risk_pct, a\n    tiny stop produces a HUGE position, so that near-instant stop-out\n    burns the full risk budget anyway. The net effect: every trade\n    taken during a flat/thin market loses, in full, almost\n    immediately — exactly the failure mode this strategy hit in its\n    first live test (4/4 losses, each a ~1-pip stop-out, half of\n    them in the 00:00-02:00 UTC window). `min_stop_distance` sets a\n    floor (in price units, default 0.0008 = 8 pips for EURUSD-style\n    4-decimal pairs) below which no trade is taken at all — if ATR is\n    too small to produce a stop that wide, the market is too quiet\n    for this strategy to have edge right now, so it sits out instead\n    of over-sizing into a hair-trigger stop.\n\nPosition sizing\n    Fixed-fractional risk: unit size = (equity * risk_pct) / stop_distance,\n    i.e. you always risk the same % of equity regardless of how wide\n    today's stop is. Clamped to at least 1 unit. The volatility floor\n    above caps how large this can get by refusing to let\n    stop_distance collapse toward zero in the first place.\n\nOnly one position open at a time.\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass MeanReversion(bt.Strategy):\n    params = dict(\n        bb_period=20,       # Bollinger Band lookback\n        bb_dev=2.0,         # Bollinger Band std-dev multiplier\n        rsi_period=14,      # RSI lookback\n        rsi_low=30,         # oversold threshold (long trigger)\n        rsi_high=70,        # overbought threshold (short trigger)\n        trend_ema_period=200,  # regime filter EMA\n        trend_slope_lookback=20,  # bars back to measure the EMA's slope over\n        atr_period=14,      # for stop sizing\n        stop_atr_mult=1.5,  # stop = entry -/+ stop_atr_mult * ATR\n        min_stop_distance=0.0008,  # floor on stop distance (price units); 8 pips for EURUSD-style 4-decimal pairs. No trade if ATR-based stop would be tighter than this.\n        reward_r=1.2,       # target = entry +/- reward_r * stop_distance\n        risk_pct=0.01,      # fraction of equity risked per trade\n        point_value=1.0,    # value of 1 price unit per unit size (1.0 for FX/CFD-style instruments)\n    )\n\n    def __init__(self):\n        self.bb = bt.indicators.BollingerBands(self.data.close, period=self.p.bb_period, devfactor=self.p.bb_dev)\n        self.rsi = bt.indicators.RSI(self.data.close, period=self.p.rsi_period)\n        self.trend_ema = bt.indicators.EMA(self.data.close, period=self.p.trend_ema_period)\n        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)\n\n        self.entry_order = None\n        self.stop_order = None\n        self.limit_order = None\n        self.trade_dir = None  # "long" | "short" | None\n        self.pending_stop_distance = None  # locked in at signal time, used by notify_order\n\n    def _warm(self) -> bool:\n        needed = max(self.p.bb_period, self.p.rsi_period, self.p.atr_period,\n                     self.p.trend_ema_period + self.p.trend_slope_lookback) + 1\n        return len(self.data) >= needed\n\n    def _unit_size(self, stop_distance: float) -> int:\n        if stop_distance <= 0:\n            return 0\n        equity = self.broker.getvalue()\n        risk_amount = equity * self.p.risk_pct\n        size = risk_amount / (stop_distance * self.p.point_value)\n        return max(1, int(size))\n\n    def next(self):\n        if not self._warm():\n            return\n\n        if self.position:\n            return  # exits are handled by the bracket stop/limit orders themselves\n        if self.entry_order is not None:\n            return\n\n        close = self.data.close[0]\n        # Regime check on the EMA's SLOPE (not price vs. EMA — see the\n        # class docstring for why that naive version self-defeats).\n        ema_rising = self.trend_ema[0] >= self.trend_ema[-self.p.trend_slope_lookback]\n        ema_falling = self.trend_ema[0] <= self.trend_ema[-self.p.trend_slope_lookback]\n\n        long_signal = close <= self.bb.lines.bot[0] and self.rsi[0] < self.p.rsi_low and ema_rising\n        short_signal = close >= self.bb.lines.top[0] and self.rsi[0] > self.p.rsi_high and ema_falling\n\n        atr = self.atr[0]\n        if atr <= 0:\n            return\n        stop_distance = max(self.p.stop_atr_mult * atr, self.p.min_stop_distance)\n        size = self._unit_size(stop_distance)\n        if size <= 0:\n            return\n\n        if long_signal:\n            self.entry_order = self.buy(size=size)\n            self.trade_dir = "long"\n            self.pending_stop_distance = stop_distance\n        elif short_signal:\n            self.entry_order = self.sell(size=size)\n            self.trade_dir = "short"\n            self.pending_stop_distance = stop_distance\n\n    def notify_order(self, order):\n        is_entry = self.entry_order is not None and order.ref == self.entry_order.ref\n        is_stop = self.stop_order is not None and order.ref == self.stop_order.ref\n        is_limit = self.limit_order is not None and order.ref == self.limit_order.ref\n\n        if is_entry:\n            if order.status == order.Completed:\n                self.entry_order = None\n                entry_price = order.executed.price\n                stop_distance = self.pending_stop_distance\n                self.pending_stop_distance = None\n                size = abs(order.executed.size)\n\n                if self.trade_dir == "long":\n                    stop_price = entry_price - stop_distance\n                    target_price = entry_price + self.p.reward_r * stop_distance\n                    self.stop_order = self.sell(exectype=bt.Order.Stop, price=stop_price, size=size)\n                    self.limit_order = self.sell(exectype=bt.Order.Limit, price=target_price, size=size)\n                else:\n                    stop_price = entry_price + stop_distance\n                    target_price = entry_price - self.p.reward_r * stop_distance\n                    self.stop_order = self.buy(exectype=bt.Order.Stop, price=stop_price, size=size)\n                    self.limit_order = self.buy(exectype=bt.Order.Limit, price=target_price, size=size)\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.entry_order = None\n                self.trade_dir = None\n            return\n\n        if is_stop or is_limit:\n            if order.status == order.Completed:\n                # Whichever bracket leg filled, cancel the other so it\n                # doesn't fire later against a position that's already flat.\n                other = self.limit_order if is_stop else self.stop_order\n                if other is not None and other.status not in (other.Completed, other.Canceled, other.Margin, other.Rejected):\n                    self.cancel(other)\n                self.stop_order = None\n                self.limit_order = None\n                self.trade_dir = None\n            elif order.status == order.Canceled:\n                if is_stop:\n                    self.stop_order = None\n                else:\n                    self.limit_order = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -281.42849891224694, "trades": 2}, "VWR": {"vwr": -0.0004867276453885974}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.000007072720516186809, "rtot": -0.02010067170700291, "rnorm": -0.000007072695504558026, "rnorm100": -0.0007072695504558026}, "DrawDown": {"len": 1019, "max": {"len": 1019, "drawdown": 3.7702503681885124, "moneydown": 384.0}, "drawdown": 3.7702503681885124, "moneydown": 384.0}, "SharpeRatio": {"sharperatio": -5.67055766904477}, "AnnualReturn": {"2026": -0.01990000000000003}, "TimeDrawDown": {"maxdrawdown": 3.7702503681885124, "maxdrawdownperiod": 1019}, "TradeAnalyzer": {"len": {"max": 437, "min": 123, "won": {"max": 0, "total": 0, "average": 0.0}, "long": {"max": 0, "min": 9223372036854775807, "won": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "lost": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "total": 0, "average": 0.0}, "lost": {"max": 437, "min": 123, "total": 560, "average": 280.0}, "short": {"max": 437, "min": 123, "won": {"max": 0, "min": 9223372036854775807, "total": 0, "average": 0.0}, "lost": {"max": 437, "min": 123, "total": 560, "average": 280.0}, "total": 560, "average": 280.0}, "total": 560, "average": 280.0}, "pnl": {"net": {"total": -198.9999999999781, "average": -99.49999999998904}, "gross": {"total": -198.9999999999781, "average": -99.49999999998904}}, "won": {"pnl": {"max": 0.0, "total": 0.0, "average": 0.0}, "total": 0}, "long": {"pnl": {"won": {"max": 0.0, "total": 0.0, "average": 0.0}, "lost": {"max": 0.0, "total": 0.0, "average": 0.0}, "total": 0.0, "average": 0.0}, "won": 0, "lost": 0, "total": 0}, "lost": {"pnl": {"max": -99.99999999998899, "total": -198.9999999999781, "average": -99.49999999998904}, "total": 2}, "short": {"pnl": {"won": {"max": 0.0, "total": 0.0, "average": 0.0}, "lost": {"max": -99.99999999998899, "total": -198.9999999999781, "average": -99.49999999998904}, "total": -198.9999999999781, "average": -99.49999999998904}, "won": 0, "lost": 2, "total": 2}, "total": {"open": 0, "total": 2, "closed": 2}, "streak": {"won": {"current": 0, "longest": 0}, "lost": {"current": 2, "longest": 2}}}}	2026-09-22 09:38:12.437407+00	2026-09-22 09:39:14.978327+00
8627d769-b363-4c1d-aefe-614bc4584090	mean_reversion-2	mean_reversion-2.py	"""\nBollinger + RSI Mean Reversion — Backtrader.\n\nBuilt for intraday, range-bound FX (this is tuned with 5-minute\nEURUSD specifically in mind) rather than trending futures markets.\nWhere Turtle Trading fades badly on 5m EURUSD because that pair\nrarely trends cleanly at that timeframe, this strategy is designed\nto profit FROM the chop: it fades price back toward the mean after\na statistically stretched move, and gets out of the way when a real\ntrend actually develops.\n\nEntry\n    Long  when close touches/crosses below the LOWER Bollinger Band\n          AND RSI is oversold (< rsi_low) — price is stretched and\n          momentum confirms exhaustion, not just noise.\n    Short when close touches/crosses above the UPPER Bollinger Band\n          AND RSI is overbought (> rsi_high).\n\nTrend filter (the important part)\n    Mean reversion gets destroyed trading INTO a strong trend. A\n    long-period EMA is used as a regime filter, but it has to be\n    checked on the EMA's own SLOPE, not on price vs. EMA at the\n    moment of entry: a long is only taken on an oversold dip when\n    the EMA itself is flat-to-rising, and a short only taken on an\n    overbought spike when the EMA is flat-to-falling. (Checking\n    "close above EMA" at the same instant close is testing "oversold,\n    below the lower Bollinger Band" is nearly self-contradictory —\n    price stretched far enough to tag the lower band is almost always\n    also below a 200-period EMA, so that naive filter would silently\n    veto nearly every long. Slope avoids that trap.) This is what\n    should meaningfully lift the win rate vs. an unfiltered Bollinger\n    fade, by refusing to fade a dip inside a real downtrend (or a\n    spike inside a real uptrend) — mean reversion's biggest loss\n    source — while still allowing fades within a flat/ranging regime.\n\nExit\n    Take-profit at entry +/- reward_r * stop_distance, i.e. a fixed\n    R-multiple of the stop (default 1.2R) rather than the Bollinger\n    midline. The midline looks like the obvious target for a\n    reversion trade, but it is usually MUCH farther from entry than\n    a tight ATR stop is — testing showed this makes the target 2-4x\n    wider than the stop, so ordinary noise stops the trade out long\n    before price could ever travel that far, and win rate collapses\n    to near zero regardless of how often price actually does revert.\n    An R-multiple target keeps risk and reward on a comparable scale\n    so the trade has a realistic chance to reach it before the stop.\n    Both stop and target are placed as a bracket (Stop + Limit) the\n    moment entry fills, inside notify_order, so neither is ever a bar\n    late; whichever is touched first closes the trade.\n\nVolatility floor (fix #1 for the real-data failure mode)\n    A pure `stop_atr_mult * ATR` stop breaks down when ATR itself is\n    tiny — e.g. during the dead Asian-session hours (~00:00-02:00\n    UTC) where 5m EURUSD can trade in a range under 1 pip. In that\n    regime the stop sits so close to entry that ordinary bid/ask\n    noise trips it almost immediately — and because position size is\n    solved backward from stop distance to hit a fixed risk_pct, a\n    tiny stop produces a HUGE position, so that near-instant stop-out\n    burns the full risk budget anyway. `min_stop_distance` (price\n    units, default 0.0008 = 8 pips for EURUSD-style 4-decimal pairs)\n    is a hard floor: if the ATR-based stop would be tighter than\n    this, NO TRADE IS TAKEN AT ALL — the floor is a veto, not a clamp.\n    (An earlier version clamped the stop distance up to the floor\n    and still traded; that just capped the position-size explosion\n    while leaving the strategy taking full-size, fixed-8-pip-stop\n    trades at 00:05 UTC with no real edge behind them — both\n    remaining live trades after that version still lost, both still\n    inside the dead session. A veto, not a clamp, is required.)\n\nSession filter (fix #2 — the floor alone isn't enough)\n    Even with the volatility floor as a veto, there's no guarantee\n    ATR happens to fall below it on every dead-session bar — it can\n    sit just above the floor while the session is still structurally\n    too thin/directionless for a reversion edge to hold. So entries\n    are additionally blocked outside `session_start_utc`-\n    `session_end_utc` (default 07:00-20:00 UTC, covering\n    London-through-NY — the two most liquid FX sessions and their\n    overlap). This is the primary defense against dead-session\n    trades; the volatility floor above is a secondary catch for thin\n    conditions that can still occur inside the allowed window.\n\nPosition sizing\n    Fixed-fractional risk: unit size = (equity * risk_pct) / stop_distance,\n    i.e. you always risk the same % of equity regardless of how wide\n    today's stop is. Clamped to at least 1 unit. The volatility floor\n    above caps how large this can get by refusing to let\n    stop_distance collapse toward zero in the first place.\n\nOnly one position open at a time.\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass MeanReversion(bt.Strategy):\n    params = dict(\n        bb_period=20,       # Bollinger Band lookback\n        bb_dev=2.0,         # Bollinger Band std-dev multiplier\n        rsi_period=14,      # RSI lookback\n        rsi_low=30,         # oversold threshold (long trigger)\n        rsi_high=70,        # overbought threshold (short trigger)\n        trend_ema_period=200,  # regime filter EMA\n        trend_slope_lookback=20,  # bars back to measure the EMA's slope over\n        atr_period=14,      # for stop sizing\n        stop_atr_mult=1.5,  # stop = entry -/+ stop_atr_mult * ATR\n        min_stop_distance=0.0008,  # VETO floor on stop distance (price units); 8 pips for EURUSD-style 4-decimal pairs. No trade at all if the ATR-based stop would be tighter than this.\n        reward_r=1.2,       # target = entry +/- reward_r * stop_distance\n        risk_pct=0.01,      # fraction of equity risked per trade\n        point_value=1.0,    # value of 1 price unit per unit size (1.0 for FX/CFD-style instruments)\n        session_start_utc=7,   # entries only allowed from this UTC hour...\n        session_end_utc=20,    # ...through (not including) this one. Default = London through NY.\n    )\n\n    def __init__(self):\n        self.bb = bt.indicators.BollingerBands(self.data.close, period=self.p.bb_period, devfactor=self.p.bb_dev)\n        self.rsi = bt.indicators.RSI(self.data.close, period=self.p.rsi_period)\n        self.trend_ema = bt.indicators.EMA(self.data.close, period=self.p.trend_ema_period)\n        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)\n\n        self.entry_order = None\n        self.stop_order = None\n        self.limit_order = None\n        self.trade_dir = None  # "long" | "short" | None\n        self.pending_stop_distance = None  # locked in at signal time, used by notify_order\n\n    def _warm(self) -> bool:\n        needed = max(self.p.bb_period, self.p.rsi_period, self.p.atr_period,\n                     self.p.trend_ema_period + self.p.trend_slope_lookback) + 1\n        return len(self.data) >= needed\n\n    def _unit_size(self, stop_distance: float) -> int:\n        if stop_distance <= 0:\n            return 0\n        equity = self.broker.getvalue()\n        risk_amount = equity * self.p.risk_pct\n        size = risk_amount / (stop_distance * self.p.point_value)\n        return max(1, int(size))\n\n    def _in_session(self) -> bool:\n        hour = self.data.datetime.datetime(0).hour\n        return self.p.session_start_utc <= hour < self.p.session_end_utc\n\n    def next(self):\n        if not self._warm():\n            return\n\n        if self.position:\n            return  # exits are handled by the bracket stop/limit orders themselves\n        if self.entry_order is not None:\n            return\n        if not self._in_session():\n            return\n\n        close = self.data.close[0]\n        # Regime check on the EMA's SLOPE (not price vs. EMA — see the\n        # class docstring for why that naive version self-defeats).\n        ema_rising = self.trend_ema[0] >= self.trend_ema[-self.p.trend_slope_lookback]\n        ema_falling = self.trend_ema[0] <= self.trend_ema[-self.p.trend_slope_lookback]\n\n        long_signal = close <= self.bb.lines.bot[0] and self.rsi[0] < self.p.rsi_low and ema_rising\n        short_signal = close >= self.bb.lines.top[0] and self.rsi[0] > self.p.rsi_high and ema_falling\n\n        atr = self.atr[0]\n        if atr <= 0:\n            return\n        stop_distance = self.p.stop_atr_mult * atr\n        if stop_distance < self.p.min_stop_distance:\n            return  # veto: too quiet right now for a meaningful stop, sit out entirely\n        size = self._unit_size(stop_distance)\n        if size <= 0:\n            return\n\n        if long_signal:\n            self.entry_order = self.buy(size=size)\n            self.trade_dir = "long"\n            self.pending_stop_distance = stop_distance\n        elif short_signal:\n            self.entry_order = self.sell(size=size)\n            self.trade_dir = "short"\n            self.pending_stop_distance = stop_distance\n\n    def notify_order(self, order):\n        is_entry = self.entry_order is not None and order.ref == self.entry_order.ref\n        is_stop = self.stop_order is not None and order.ref == self.stop_order.ref\n        is_limit = self.limit_order is not None and order.ref == self.limit_order.ref\n\n        if is_entry:\n            if order.status == order.Completed:\n                self.entry_order = None\n                entry_price = order.executed.price\n                stop_distance = self.pending_stop_distance\n                self.pending_stop_distance = None\n                size = abs(order.executed.size)\n\n                if self.trade_dir == "long":\n                    stop_price = entry_price - stop_distance\n                    target_price = entry_price + self.p.reward_r * stop_distance\n                    self.stop_order = self.sell(exectype=bt.Order.Stop, price=stop_price, size=size)\n                    self.limit_order = self.sell(exectype=bt.Order.Limit, price=target_price, size=size)\n                else:\n                    stop_price = entry_price + stop_distance\n                    target_price = entry_price - self.p.reward_r * stop_distance\n                    self.stop_order = self.buy(exectype=bt.Order.Stop, price=stop_price, size=size)\n                    self.limit_order = self.buy(exectype=bt.Order.Limit, price=target_price, size=size)\n            elif order.status in (order.Canceled, order.Margin, order.Rejected):\n                self.entry_order = None\n                self.trade_dir = None\n            return\n\n        if is_stop or is_limit:\n            if order.status == order.Completed:\n                # Whichever bracket leg filled, cancel the other so it\n                # doesn't fire later against a position that's already flat.\n                other = self.limit_order if is_stop else self.stop_order\n                if other is not None and other.status not in (other.Completed, other.Canceled, other.Margin, other.Rejected):\n                    self.cancel(other)\n                self.stop_order = None\n                self.limit_order = None\n                self.trade_dir = None\n            elif order.status == order.Canceled:\n                if is_stop:\n                    self.stop_order = None\n                else:\n                    self.limit_order = None\n	2026-08-03	2026-08-06	completed	\N	{"SQN": {"sqn": 0, "trades": 0}, "VWR": {"vwr": 0.0}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": 0.0, "rtot": 0.0, "rnorm": 0.0, "rnorm100": 0.0}, "DrawDown": {"len": 0, "max": {"len": 0.0, "drawdown": 0.0, "moneydown": 0.0}, "drawdown": 0.0, "moneydown": 0.0}, "SharpeRatio": {"sharperatio": null}, "AnnualReturn": {"2026": 0.0}, "TimeDrawDown": {"maxdrawdown": 0.0, "maxdrawdownperiod": 0}, "TradeAnalyzer": {"total": {"total": 0}}}	2026-09-22 09:42:26.665513+00	2026-09-22 09:43:10.360825+00
a8c421fb-d553-4b15-9b35-16768d991c3d	macd_crossover	macd_crossover.py	"""\nMACD Crossover — Backtrader.\n\nThe standard, textbook MACD crossover strategy (Gerald Appel's MACD,\nas commonly taught) with no added filters or variants: this is the\nplain, widely-known version, not a customized derivative.\n\nMACD\n    MACD line = EMA(fast) - EMA(slow)\n    Signal line = EMA(MACD line, signal_period)\n    Standard parameters: fast=12, slow=26, signal=9 (the canonical\n    defaults used almost universally).\n\nEntry / Exit (the crossover rule)\n    Long when the MACD line crosses ABOVE the signal line.\n    Short when the MACD line crosses BELOW the signal line.\n    Always in the market once warmed up: a bullish crossover both\n    closes any open short and opens a long in the same action, and a\n    bearish crossover both closes any open long and opens a short —\n    this is the standard always-in-the-market version of the rule\n    (long or short, never flat), matching how the strategy is\n    conventionally described and traded.\n\nNo stop-loss, no take-profit, no position-sizing filter, no regime\nfilter — those are legitimate refinements traders add on top, but\nthey are additions to the base strategy, not part of it. Since the\nask here was specifically the known, standard strategy (not a\ncustom variant), this file stays deliberately plain.\n\nPosition sizing\n    Uses Backtrader's order_target_percent: each crossover targets a\n    position sized to risk_pct of account equity (long on a bullish\n    cross, short on a bearish one). This is a single atomic order —\n    Backtrader computes and submits whatever buy/sell delta is needed\n    to move from the current position (long, short, or flat) to the\n    target, so there's no manual close-then-open pair to sequence or\n    track, which avoids a real bug an earlier draft of this file had\n    (using self.close() and self.buy() as two separate orders let the\n    strategy's own order-tracking reference get silently overwritten\n    by the second one).\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass MACDCrossover(bt.Strategy):\n    params = dict(\n        fast_period=12,     # MACD fast EMA\n        slow_period=26,     # MACD slow EMA\n        signal_period=9,    # signal line EMA\n        risk_pct=0.95,      # fraction of equity committed per position (always-in-market sizing)\n    )\n\n    def __init__(self):\n        self.macd = bt.indicators.MACD(\n            self.data.close,\n            period_me1=self.p.fast_period,\n            period_me2=self.p.slow_period,\n            period_signal=self.p.signal_period,\n        )\n        self.crossover = bt.indicators.CrossOver(self.macd.macd, self.macd.signal)\n\n        self.order = None\n\n    def _warm(self) -> bool:\n        needed = self.p.slow_period + self.p.signal_period + 1\n        return len(self.data) >= needed\n\n    def next(self):\n        if not self._warm():\n            return\n        if self.order is not None:\n            return  # an order is already working, wait for it to resolve\n\n        cross = self.crossover[0]\n        if cross == 0:\n            return  # no crossover this bar\n\n        if cross > 0:\n            # Bullish crossover: target a fully long position (flattens\n            # any existing short and opens long in one atomic order, so\n            # there's no separate close+open pair to track or race).\n            self.order = self.order_target_percent(target=self.p.risk_pct)\n        else:\n            # Bearish crossover: target a fully short position.\n            self.order = self.order_target_percent(target=-self.p.risk_pct)\n\n    def notify_order(self, order):\n        if order.status in (order.Completed, order.Canceled, order.Margin, order.Rejected):\n            self.order = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -1.3191563235854122, "trades": 73}, "VWR": {"vwr": -0.0005088991326268562}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.0000067704470757914195, "rtot": -0.0064183838278502655, "rnorm": -0.000006770424156366341, "rnorm100": -0.0006770424156366341}, "DrawDown": {"len": 900, "max": {"len": 900, "drawdown": 1.3162481067834775, "moneydown": 131.70291999999972}, "drawdown": 0.6987107682608855, "moneydown": 69.91253999998298}, "SharpeRatio": {"sharperatio": -2.7547435386713404}, "AnnualReturn": {"2026": -0.006397829999998383}, "TimeDrawDown": {"maxdrawdown": 1.3162481067834775, "maxdrawdownperiod": 900}, "TradeAnalyzer": {"len": {"max": 57, "min": 1, "won": {"max": 57, "min": 10, "total": 477, "average": 20.73913043478261}, "long": {"max": 52, "min": 1, "won": {"max": 28, "min": 10, "total": 224, "average": 17.23076923076923}, "lost": {"max": 52, "min": 1, "total": 244, "average": 10.166666666666666}, "total": 468, "average": 12.64864864864865}, "lost": {"max": 52, "min": 1, "total": 406, "average": 8.12}, "short": {"max": 57, "min": 1, "won": {"max": 57, "min": 14, "total": 253, "average": 25.3}, "lost": {"max": 22, "min": 1, "total": 162, "average": 6.230769230769231}, "total": 415, "average": 11.527777777777779}, "total": 883, "average": 12.095890410958905}, "pnl": {"net": {"total": -72.04086000000032, "average": -0.9868610958904154}, "gross": {"total": -72.04086000000032, "average": -0.9868610958904154}}, "won": {"pnl": {"max": 24.051350000000067, "total": 143.252310000002, "average": 6.228361304347914}, "total": 23}, "long": {"pnl": {"won": {"max": 24.051350000000067, "total": 80.02613000000261, "average": 6.155856153846354}, "lost": {"max": -7.756750000000052, "total": -93.58174000000281, "average": -3.8992391666667836}, "total": -13.555610000000204, "average": -0.3663678378378433}, "won": 13, "lost": 24, "total": 37}, "lost": {"pnl": {"max": -11.083499999999692, "total": -215.2931700000023, "average": -4.305863400000046}, "total": 50}, "short": {"pnl": {"won": {"max": 18.28960000000016, "total": 63.226179999999374, "average": 6.322617999999937}, "lost": {"max": -11.083499999999692, "total": -121.71142999999951, "average": -4.681208846153828}, "total": -58.48525000000014, "average": -1.6245902777777816}, "won": 10, "lost": 26, "total": 36}, "total": {"open": 1, "total": 74, "closed": 73}, "streak": {"won": {"current": 1, "longest": 4}, "lost": {"current": 0, "longest": 15}}}}	2026-09-22 09:51:04.237143+00	2026-09-22 09:51:48.770148+00
ed4edd20-bc65-40b5-93c3-41d33851ef84	macd_crossover	macd_crossover.py	"""\nMACD Crossover — Backtrader.\n\nThe standard, textbook MACD crossover strategy (Gerald Appel's MACD,\nas commonly taught) with no added filters or variants: this is the\nplain, widely-known version, not a customized derivative.\n\nMACD\n    MACD line = EMA(fast) - EMA(slow)\n    Signal line = EMA(MACD line, signal_period)\n    Standard parameters: fast=12, slow=26, signal=9 (the canonical\n    defaults used almost universally).\n\nEntry / Exit (the crossover rule)\n    Long when the MACD line crosses ABOVE the signal line.\n    Short when the MACD line crosses BELOW the signal line.\n    Always in the market once warmed up: a bullish crossover both\n    closes any open short and opens a long in the same action, and a\n    bearish crossover both closes any open long and opens a short —\n    this is the standard always-in-the-market version of the rule\n    (long or short, never flat), matching how the strategy is\n    conventionally described and traded.\n\nNo stop-loss, no take-profit, no position-sizing filter, no regime\nfilter — those are legitimate refinements traders add on top, but\nthey are additions to the base strategy, not part of it. Since the\nask here was specifically the known, standard strategy (not a\ncustom variant), this file stays deliberately plain.\n\nPosition sizing\n    Uses Backtrader's order_target_percent: each crossover targets a\n    position sized to risk_pct of account equity (long on a bullish\n    cross, short on a bearish one). This is a single atomic order —\n    Backtrader computes and submits whatever buy/sell delta is needed\n    to move from the current position (long, short, or flat) to the\n    target, so there's no manual close-then-open pair to sequence or\n    track, which avoids a real bug an earlier draft of this file had\n    (using self.close() and self.buy() as two separate orders let the\n    strategy's own order-tracking reference get silently overwritten\n    by the second one).\n"""\n\nfrom __future__ import annotations\n\nimport backtrader as bt\n\n\nclass MACDCrossover(bt.Strategy):\n    params = dict(\n        fast_period=12,     # MACD fast EMA\n        slow_period=26,     # MACD slow EMA\n        signal_period=9,    # signal line EMA\n        risk_pct=0.95,      # fraction of equity committed per position (always-in-market sizing)\n    )\n\n    def __init__(self):\n        self.macd = bt.indicators.MACD(\n            self.data.close,\n            period_me1=self.p.fast_period,\n            period_me2=self.p.slow_period,\n            period_signal=self.p.signal_period,\n        )\n        self.crossover = bt.indicators.CrossOver(self.macd.macd, self.macd.signal)\n\n        self.order = None\n\n    def _warm(self) -> bool:\n        needed = self.p.slow_period + self.p.signal_period + 1\n        return len(self.data) >= needed\n\n    def next(self):\n        if not self._warm():\n            return\n        if self.order is not None:\n            return  # an order is already working, wait for it to resolve\n\n        cross = self.crossover[0]\n        if cross == 0:\n            return  # no crossover this bar\n\n        if cross > 0:\n            # Bullish crossover: target a fully long position (flattens\n            # any existing short and opens long in one atomic order, so\n            # there's no separate close+open pair to track or race).\n            self.order = self.order_target_percent(target=self.p.risk_pct)\n        else:\n            # Bearish crossover: target a fully short position.\n            self.order = self.order_target_percent(target=-self.p.risk_pct)\n\n    def notify_order(self, order):\n        if order.status in (order.Completed, order.Canceled, order.Margin, order.Rejected):\n            self.order = None\n	2026-08-03	2026-08-14	completed	\N	{"SQN": {"sqn": -3.2904240385780894, "trades": 257}, "VWR": {"vwr": -0.0005153106510062541}, "Calmar": {"2026-08-31T00:00:00": null}, "Returns": {"ravg": -0.000007528133539104313, "rtot": -0.021394955518134456, "rnorm": -0.000007528105202778128, "rnorm100": -0.0007528105202778127}, "DrawDown": {"len": 2754, "max": {"len": 2754, "drawdown": 2.520544015431124, "moneydown": 252.2287999999753}, "drawdown": 2.184450061526587, "moneydown": 218.59614999997575}, "SharpeRatio": {"sharperatio": -14.119328123315919}, "AnnualReturn": {"2026": -0.021167706999997593}, "TimeDrawDown": {"maxdrawdown": 2.520544015431124, "maxdrawdownperiod": 2754}, "TradeAnalyzer": {"len": {"max": 46, "min": 1, "won": {"max": 46, "min": 9, "total": 1421, "average": 21.208955223880597}, "long": {"max": 46, "min": 1, "won": {"max": 46, "min": 10, "total": 728, "average": 22.060606060606062}, "lost": {"max": 37, "min": 1, "total": 694, "average": 7.3052631578947365}, "total": 1422, "average": 11.109375}, "lost": {"max": 37, "min": 1, "total": 1312, "average": 6.905263157894737}, "short": {"max": 46, "min": 1, "won": {"max": 46, "min": 9, "total": 693, "average": 20.38235294117647}, "lost": {"max": 24, "min": 1, "total": 618, "average": 6.505263157894737}, "total": 1311, "average": 10.162790697674419}, "total": 2733, "average": 10.634241245136186}, "pnl": {"net": {"total": -215.21334999999405, "average": -0.8374060311283815}, "gross": {"total": -215.21334999999405, "average": -0.8374060311283815}}, "won": {"pnl": {"max": 19.59807999999998, "total": 230.1821000000009, "average": 3.435553731343297}, "total": 67}, "long": {"pnl": {"won": {"max": 12.048000000000457, "total": 112.68100000000734, "average": 3.4145757575759803}, "lost": {"max": -6.933320000000668, "total": -206.81842000000344, "average": -2.177036000000036}, "total": -94.137419999996, "average": -0.7354485937499687}, "won": 33, "lost": 95, "total": 128}, "lost": {"pnl": {"max": -35.903660000000734, "total": -445.39544999999464, "average": -2.3441865789473404}, "total": 190}, "short": {"pnl": {"won": {"max": 19.59807999999998, "total": 117.50109999999354, "average": 3.455914705882163}, "lost": {"max": -35.903660000000734, "total": -238.57702999999154, "average": -2.5113371578946477}, "total": -121.07592999999797, "average": -0.9385731007751781}, "won": 34, "lost": 95, "total": 129}, "total": {"open": 1, "total": 258, "closed": 257}, "streak": {"won": {"current": 1, "longest": 5}, "lost": {"current": 0, "longest": 15}}}}	2026-09-22 09:51:36.603021+00	2026-09-22 09:52:26.031463+00
\.


--
-- Data for Name: backtest_trades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backtest_trades (id, run_id, instrument, direction, entry_date, entry_time, exit_date, exit_time, entry_price, exit_price, size, pnl) FROM stdin;
cdb1229e-3b50-48ba-bdf4-c786888f0eb7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-03	09:15:00	2026-08-03	09:35:00	1.15327	1.1525429242329448	8237	5.9889230932338355
32dfd683-e70e-4471-b44a-626e0fc19c56	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-03	10:35:00	2026-08-03	10:40:00	1.15317	1.1523978987398422	8243	-6.364430687480821
907916c8-8f47-4680-8a02-3c16c118b344	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-03	11:05:00	2026-08-03	11:20:00	1.15239	1.1523	8243	0.7418699999993692
5aec35f7-0397-4e30-b175-1ee9e4bb8e52	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-03	11:20:00	2026-08-03	15:05:00	1.1523	1.1534457028784253	8244	9.445174529737283
29d89031-29f3-4c51-ab80-fd05c98128de	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-03	15:10:00	2026-08-03	15:35:00	1.15343	1.152798478013934	8244	-5.206267253127897
73164520-35fc-4203-8acc-a4680d32bdb7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-03	15:45:00	2026-08-03	16:05:00	1.15244	1.153117209319771	8247	-5.584945260152348
de653f94-42a3-4f9c-bca1-12a535a438b2	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-03	18:55:00	2026-08-03	22:50:00	1.15077	1.15127	8254	4.126999999999546
86649ac8-d79f-4e22-9c72-21c0b4efc7bf	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-03	22:50:00	2026-08-03	23:10:00	1.15127	1.1507117596764025	8254	4.607715630973974
4ef6ac0f-aa2f-43e2-adad-12aa0cfd0ba9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	00:35:00	2026-08-04	01:20:00	1.15077	1.15077	8260	0
e4cff07e-599e-4d6f-a996-3d0b0bd06d85	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	01:20:00	2026-08-04	01:55:00	1.15077	1.15087	8261	-0.826099999999909
50ea0623-767a-479e-a52a-537a8956c7f2	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	01:55:00	2026-08-04	02:50:00	1.15087	1.15073	8260	-1.1564000000002395
648eeaaf-2fee-4cb5-9119-6ce44046b6b7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	02:50:00	2026-08-04	03:00:00	1.15073	1.1509925508892174	8260	-2.1686703449352196
d0dc2ea8-130d-48a5-9b4f-98c592513c75	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	03:10:00	2026-08-04	03:50:00	1.15124	1.150860959601548	8254	-3.12859944882319
29c5a7db-fc00-43c3-ac18-4acd7c5d75b2	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	04:00:00	2026-08-04	04:30:00	1.15049	1.150972692208492	8257	-3.9855895655180538
e6794984-c70b-45c0-912f-542df9e0cfb6	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	04:35:00	2026-08-04	05:30:00	1.15116	1.15093	8249	-1.8972699999996079
3ebfad10-b12f-49eb-91a2-40d4147ad2e9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	05:30:00	2026-08-04	06:35:00	1.15093	1.15121	8249	-2.3097200000004783
fc1ac97c-4804-4bc7-817e-0405bfd9fa3a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	06:35:00	2026-08-04	06:40:00	1.15121	1.150768078644576	8245	-3.643641575471629
67a9135c-e60f-498d-a314-3c8c543abd5d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	06:45:00	2026-08-04	07:45:00	1.15084	1.15089	8245	-0.4122499999990392
ba004893-fe48-43ee-ac6e-7115000b608e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	07:45:00	2026-08-04	08:25:00	1.15089	1.15083	8244	-0.4946399999995794
8382f436-05b5-4abd-a1bb-55bfee671d27	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	08:25:00	2026-08-04	10:15:00	1.15083	1.1511545108588628	8244	-2.6752675204645833
627b8514-3373-44cd-97cb-0c676eb66c76	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	10:20:00	2026-08-04	11:20:00	1.15122	1.15094	8239	-2.306919999998648
90b37f00-716a-4cf1-bc8b-b123338f111d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	11:20:00	2026-08-04	12:40:00	1.15094	1.15079	8239	1.2358500000007786
d10dcec5-3da9-48bd-9b96-8303862ea536	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	12:40:00	2026-08-04	13:00:00	1.15079	1.1508	8241	0.08241000000053988
7bbd35bd-50a8-45ee-afc7-6d90346e2f26	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	13:00:00	2026-08-04	13:40:00	1.1508	1.1513607509051516	8241	-4.621148209353578
0a8c0635-479d-4115-8bdb-85896a231ec3	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	13:45:00	2026-08-04	14:40:00	1.15141	1.1523368805110124	8233	7.631007247164322
34acce70-2a71-4156-b7d6-ae1b8f629e3a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	15:00:00	2026-08-04	15:40:00	1.15158	1.152260978903121	8238	-5.609904203910972
7b52cb32-d290-48e2-90fd-380525cf0640	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	15:45:00	2026-08-04	16:00:00	1.15214	1.15146	8230	-5.596400000000115
ade18698-36e9-47af-bb3d-932c7a2f78e7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	16:00:00	2026-08-04	16:35:00	1.15146	1.1521377758469717	8230	-5.578095220578058
9f3c681c-194c-43de-a3af-d288bc9ef876	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	16:40:00	2026-08-04	17:50:00	1.15247	1.15212	8218	-2.8763000000005956
b9c2bcf5-2758-4331-a6c2-8deeb1739673	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	17:50:00	2026-08-04	19:00:00	1.15212	1.15262	8218	-4.108999999999547
5f1f4758-6ff0-44a1-ba70-31a2981c8c74	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	19:00:00	2026-08-04	19:30:00	1.15262	1.15191	8212	-5.830519999999905
b81d2a43-4934-4701-912d-9f40895127d3	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	19:30:00	2026-08-04	20:15:00	1.15191	1.15221	8212	-2.4635999999997287
d8db1a91-43d5-4e8a-8b18-aec6ff3d0dc7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-04	20:15:00	2026-08-04	21:50:00	1.15221	1.1530561540824908	8208	6.945232709085232
34d73cc6-948d-4170-a1a7-7cae5487efe3	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-04	22:45:00	2026-08-05	01:15:00	1.15308	1.15307	8207	0.08207000000053766
f7099d15-17bc-4a05-bf71-30921cdffade	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	01:15:00	2026-08-05	02:25:00	1.15307	1.15303	8207	-0.3282800000003283
0d9ecc4d-8ea9-485f-af6f-113e5159c04b	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	02:25:00	2026-08-05	03:00:00	1.15303	1.1532924985615958	8207	-2.1543256950164826
430f31ad-4115-4f60-8877-af9d2e2fc1c7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	03:05:00	2026-08-05	03:45:00	1.15332	1.1530387700418805	8203	-2.306929346453529
c0e71910-46fc-4f59-b46f-47d924baf69b	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	03:50:00	2026-08-05	05:20:00	1.15297	1.15304	8204	-0.5742800000001189
b2a1b0b1-0dff-42bc-be28-91ca80fbd3f6	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	05:20:00	2026-08-05	05:35:00	1.15304	1.153665330672023	8203	5.129587502604442
9af5ecae-f4d0-4ace-93c5-db5c3e67ec14	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	06:40:00	2026-08-05	07:20:00	1.15359	1.1539837182682384	8203	-3.2296709543606603
9d5325a5-143f-4930-a62e-30e0a3aec1c2	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	07:25:00	2026-08-05	07:45:00	1.15396	1.1536311053320951	8198	-2.696278487485006
3a433d18-f704-4b67-a920-29e9c07c5554	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	07:50:00	2026-08-05	08:55:00	1.15363	1.15354	8198	0.7378199999993726
d0f7450d-d596-434f-8b7a-d123cb797337	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	08:55:00	2026-08-05	09:30:00	1.15354	1.1535	8200	-0.32800000000032803
c8b2cd9b-29e7-4075-a58f-903a27929cdb	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	09:30:00	2026-08-05	09:35:00	1.1535	1.1539068034584747	8199	-3.3353815560346334
bd7d1f82-a754-40aa-9ff3-1a09c0041912	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	09:40:00	2026-08-05	10:30:00	1.15396	1.1534	8193	-4.58808000000095
8bcd54a3-630c-4b2f-85f9-856e69cd1b7d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	10:30:00	2026-08-05	11:00:00	1.1534	1.1539824953436861	8193	-4.772384350820637
e6a97cfd-4b15-4382-a4ae-8d8c26998933	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	11:20:00	2026-08-05	11:40:00	1.15406	1.1534705339133227	8185	-4.824779919454731
289d71b5-e791-4caa-bb73-d364fc681aee	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	11:45:00	2026-08-05	12:25:00	1.15346	1.15391	8185	-3.683250000000503
b86c6639-df26-4858-b187-3a1885421552	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	12:25:00	2026-08-05	13:20:00	1.15391	1.15401	8179	0.8178999999999099
192bcc6b-ae39-4504-a7ac-fce55cfcb606	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	13:20:00	2026-08-05	14:10:00	1.15401	1.15428	8179	-2.2083299999999384
13b4e1b1-dfa9-47bc-a171-624b06235a45	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	14:10:00	2026-08-05	14:30:00	1.15428	1.155091920721659	8175	6.637451899562585
69e7bbed-8254-4b03-8f38-7967ba05e274	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	15:35:00	2026-08-05	17:20:00	1.15499	1.15551	8176	-4.251520000000621
6a337a11-d2a2-4fd1-a170-e50671e7e2cf	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	17:20:00	2026-08-05	17:50:00	1.15551	1.1546064352854575	8168	-7.380316588383627
bfe15893-9775-45a2-a9dd-4775e6cf909f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	17:55:00	2026-08-05	20:55:00	1.15472	1.1556751352871362	8168	-7.801545025328478
4aeafd96-3f8c-4638-ad85-90e16623ba41	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	21:00:00	2026-08-05	21:50:00	1.1556	1.15544	8155	-1.3047999999994941
48d3f6a1-854e-4a65-bc26-da1864d54050	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-05	21:50:00	2026-08-05	23:40:00	1.15544	1.15533	8155	0.8970500000004444
c57c51ed-5fe8-4fda-988b-b1ca16df6f4a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-05	23:40:00	2026-08-06	00:50:00	1.15533	1.15523	8157	-0.8156999999999102
bd37eb6d-0e6d-407b-983f-5b6e5d6a98a9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	00:50:00	2026-08-06	02:10:00	1.15523	1.1555126937358435	8157	-2.305932803275864
3e8506a2-008c-4a1a-a96c-7bd4df8bd53e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	02:35:00	2026-08-06	02:45:00	1.15544	1.1556422630022833	8154	-1.6492525206181954
53c2e135-fec6-40f2-9b7a-87d5c4188173	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	02:50:00	2026-08-06	03:05:00	1.1557	1.155487481116612	8150	-1.732028899611493
aad46756-e833-41ff-b7bc-383ed52383c8	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	03:10:00	2026-08-06	03:20:00	1.15549	1.1557332916448468	8151	-1.9830701971473463
580598d2-dc23-48ca-b6a5-60614267e87b	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	03:25:00	2026-08-06	04:00:00	1.15576	1.1554874592770668	8147	-2.220389269736337
29ea2b91-2876-457b-80c0-2fd11613c971	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	04:05:00	2026-08-06	05:25:00	1.15552	1.15566	8147	-1.1405799999984272
2a00546a-1e3b-4562-8edc-5a87ac2dce59	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	05:25:00	2026-08-06	05:40:00	1.15566	1.15567	8145	0.0814500000005336
dd1f7a1d-25d7-44e0-b4e8-f7394987fbf9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	05:40:00	2026-08-06	06:40:00	1.15567	1.1548117291541742	8145	6.990616039250867
ca61df33-e38e-4262-bccd-6a68ef48e0cd	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	07:35:00	2026-08-06	08:10:00	1.15487	1.154589120409354	8156	-2.290853941310038
7f54830c-c5e0-4c3b-b32c-fc8a42fd0d78	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	08:15:00	2026-08-06	08:40:00	1.15452	1.1548	8157	-2.283960000000473
34f97666-800d-43ca-85bf-23682176b678	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	08:40:00	2026-08-06	09:25:00	1.1548	1.1545110011218889	8153	-2.3562078532404476
5296294f-0e20-4b7e-90ad-60074878c405	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	09:35:00	2026-08-06	10:40:00	1.15447	1.15432	8153	1.2229500000007705
4e52cdb8-ca2d-486d-a890-ddf8e2af0bc6	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	10:40:00	2026-08-06	11:00:00	1.15432	1.1539001313780193	8156	-3.4244484808748714
dde246be-6ea5-43c1-8f69-eb7fb6780649	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	11:05:00	2026-08-06	11:35:00	1.15423	1.15423	8153	0
a16e3445-dcad-4233-a42c-da1946e8f201	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	11:35:00	2026-08-06	11:50:00	1.15423	1.1541	8153	1.0598900000015126
629ea6b1-1cfc-4059-a0b0-35e55f20e749	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	11:50:00	2026-08-06	16:10:00	1.1541	1.1535882920115974	8155	-4.172978645422378
cf8386b5-65ac-4e72-ba15-6993df1bab88	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	16:15:00	2026-08-06	17:15:00	1.15378	1.15345	8154	-2.6908199999995226
c97dbe06-2fb4-4a00-b50e-1b50f9c51ccc	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	17:15:00	2026-08-06	18:15:00	1.15345	1.152396672679492	8154	8.588830971422247
81314234-ddd8-4b57-9fd4-87f9029819c4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	19:35:00	2026-08-06	22:30:00	1.15189	1.15184	8172	-0.4086000000008623
c59b63df-187f-4700-9e2c-a7d65f7d3d76	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	22:30:00	2026-08-06	22:50:00	1.15184	1.152276474924621	8172	-3.5668730840033547
b3c989cf-7df6-47cd-8dcb-b8723b38fc5a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	23:00:00	2026-08-06	23:25:00	1.15227	1.15193	8166	-2.776440000000057
1d55b25b-7ff8-475e-9f96-b93d72e694e9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-06	23:25:00	2026-08-06	23:50:00	1.15193	1.1522	8166	-2.2048199999999385
6b658a31-8ea0-4d6e-81e7-b55220df4212	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-06	23:50:00	2026-08-07	00:30:00	1.1522	1.15212	8162	-0.6529599999988407
3de7d54a-ade9-45a0-a646-67013f832959	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	00:30:00	2026-08-07	01:15:00	1.15212	1.15215	8163	-0.24488999999979177
f16b8602-2552-4d65-b198-b368e8b1f54f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	01:15:00	2026-08-07	03:15:00	1.15215	1.15211	8162	-0.3264800000003265
c37902c3-892f-42f7-bac8-401f36930602	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	03:15:00	2026-08-07	03:55:00	1.15211	1.1518130219792213	8162	2.423934605595422
1946c4d2-1f81-4d7f-8da0-108e3166344c	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	04:25:00	2026-08-07	05:25:00	1.15213	1.15225	8164	0.979679999999167
65c56dbf-ab95-4958-af9a-bf3afcbb76ff	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	05:25:00	2026-08-07	06:45:00	1.15225	1.1521199951004413	8164	1.0613599999979684
058b2e0d-0c40-4e6a-91b0-054501a56ee4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	06:45:00	2026-08-07	08:30:00	1.15212	1.15216	8166	0.32664000000032667
4f47eaf3-0346-4c22-b3b3-1399c5c972b4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	08:30:00	2026-08-07	08:50:00	1.15216	1.1524230536461724	8166	-2.1480960746429645
8fb55539-729e-4859-9f5c-cbb9c88a78d7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	09:25:00	2026-08-07	09:40:00	1.15244	1.15229	8162	-1.224299999998959
c24d7fcb-8615-442b-896f-bb3668b0ed87	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	09:40:00	2026-08-07	10:05:00	1.15229	1.1517624043847228	8162	4.30623541189304
e8292f0f-264a-40fa-aa4a-4da7c27f595a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	11:00:00	2026-08-07	11:15:00	1.15222	1.15183	8166	-3.1847400000009185
be9d90e5-5e0e-4b78-af2c-ad6bb9915c97	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	11:15:00	2026-08-07	11:35:00	1.15183	1.152245596403393	8166	-3.3937602301086285
28cbd884-bafd-47e9-97e9-ce70b46a085f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	11:40:00	2026-08-07	12:10:00	1.15219	1.1528349970866076	8161	5.263821223804546
95efcc78-5e4a-43c7-9f96-1adc40269fa0	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	13:15:00	2026-08-07	14:40:00	1.15262	1.1530465957837868	8162	-3.481874787267758
aed56dd3-393d-4438-ab2f-3a24e45e4883	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	14:45:00	2026-08-07	15:25:00	1.15316	1.152742730426614	8155	-3.4028333709624037
73bbf0e1-0a81-479f-ad4f-5807dafa34ab	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	15:30:00	2026-08-07	15:35:00	1.15279	1.15721	8155	-36.04510000000074
3af3800b-61b6-4904-a17e-45829fe045ba	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	15:40:00	2026-08-07	16:40:00	1.15733	1.15696	8094	-2.99477999999985
e0fe03a3-dc50-4a07-95d6-da68771d3793	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	16:40:00	2026-08-07	17:40:00	1.15696	1.155020215006616	8094	15.700619736449983
16cad25d-73e9-434f-93c9-cd8f68643b0d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	18:45:00	2026-08-07	20:05:00	1.15612	1.1559	8113	-1.7848600000008843
70acd005-c120-45fc-b2a3-dca901713157	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	20:05:00	2026-08-07	21:00:00	1.1559	1.15611	8113	-1.7037300000003528
7eaff49f-d012-4139-a93b-4c975c847ab7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-07	21:00:00	2026-08-07	22:55:00	1.15611	1.15634	8110	1.8652999999996145
ce82b252-8dae-4eae-991a-3990dd467076	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-07	22:55:00	2026-08-07	23:20:00	1.15634	1.1556427959902738	8110	5.654324518879248
940f61f7-0552-47e6-980a-f37ec9f72214	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	00:10:00	2026-08-10	01:00:00	1.1563	1.1558842996011351	8115	-3.3734087367891497
c5ab2011-305b-4071-8afb-26a72de3d4a4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	01:05:00	2026-08-10	02:10:00	1.15571	1.15568	8116	0.24347999999979297
937973d8-c442-420f-8595-276101088ff7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	02:10:00	2026-08-10	03:40:00	1.15568	1.15547	8116	-1.704360000000353
44442d03-54b2-4a10-bac4-2d3f725293bc	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	03:40:00	2026-08-10	03:50:00	1.15547	1.155813047513724	8116	-2.7841736213843777
06feaa81-df87-4b6f-9da0-141522bc753d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	03:55:00	2026-08-10	04:00:00	1.15577	1.1554089010977946	8112	-2.9292342946899623
b71b0653-05f2-4acc-9146-abd961b4fc8e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	04:10:00	2026-08-10	05:25:00	1.15533	1.15534	8113	-0.0811300000005315
ed987e5d-feb7-445f-b4cf-23169311e0f1	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	05:25:00	2026-08-10	05:50:00	1.15534	1.15523	8113	-0.8924300000004421
00ba9f21-6fcb-456b-8c2d-e94f9eac5c6e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	05:50:00	2026-08-10	07:30:00	1.15523	1.15494	8113	2.3527699999992002
bfad88ad-e015-4869-a258-0957846cc7b4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	07:30:00	2026-08-10	08:50:00	1.15494	1.1553440113236413	8116	3.2789559026720347
511a23f5-d1b2-4d70-a176-7481352f0f91	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	09:55:00	2026-08-10	10:20:00	1.15529	1.1556797048181828	8117	-3.1632340091906075
c61e3d3e-ce01-470c-a7dc-28652bed8b3e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	10:25:00	2026-08-10	10:45:00	1.15567	1.1563654634409906	8112	5.641599433315623
5e054ebf-e52c-4639-8202-70ce8f468487	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	11:45:00	2026-08-10	13:00:00	1.15623	1.155527090701829	8112	5.702000226764643
f008593d-57b3-4d83-ac89-347deef7968f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	15:05:00	2026-08-10	15:25:00	1.15517	1.1547131113040268	8124	-3.7117637660868263
1b6fbd3a-7e4d-4b9c-8c70-62030a7da189	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	15:30:00	2026-08-10	16:15:00	1.15485	1.15519	8124	-2.7621600000000566
fcc6950f-246a-4c05-a2a1-d72590efee6d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	16:15:00	2026-08-10	16:45:00	1.15519	1.1546839665784352	8119	-4.10848534968416
92819af0-c18f-466d-bb12-8b71e64d12d8	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	16:55:00	2026-08-10	17:20:00	1.15445	1.15499	8121	-4.385339999999878
2bba62a3-feb3-4360-87a6-684f89111240	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	17:20:00	2026-08-10	18:15:00	1.15499	1.15509	8113	0.8112999999999106
9685b36d-afa6-4afc-919d-d7abe6195a03	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	18:15:00	2026-08-10	20:20:00	1.15509	1.1541860269933362	8113	7.3339330030632714
fe236b0c-7b28-4e6f-843c-e64f3bbbb2df	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	20:25:00	2026-08-10	22:10:00	1.15429	1.15405	8125	-1.950000000000146
7490acac-f036-4756-ae62-3c36b11e76ca	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-10	22:10:00	2026-08-10	22:25:00	1.15405	1.15419	8125	-1.1375000000002355
43e3091d-fa6a-4d76-8201-6bff1f8ef9a7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-10	22:25:00	2026-08-11	00:30:00	1.15419	1.15425	8123	0.4873799999995856
1670e84b-f4d4-4adc-978f-8564cb280472	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	00:30:00	2026-08-11	01:00:00	1.15425	1.1542945177819564	8123	-0.3616179428320243
ac4c2a81-bd4b-45a5-925d-8e5d00471082	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	01:05:00	2026-08-11	02:25:00	1.15433	1.15432	8122	-0.08122000000053209
aee72cde-872f-4975-b638-1d2c2863b9f6	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	02:25:00	2026-08-11	02:55:00	1.15432	1.15438	8122	-0.48731999999958564
34de43b0-4474-4175-8e4a-ca43ad0f950a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	02:55:00	2026-08-11	03:00:00	1.15438	1.15466779387793	8121	2.337174082669425
323ab39f-a622-4ee5-820f-dd6665c81bf2	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	04:00:00	2026-08-11	04:15:00	1.15456	1.1548498350350584	8122	-2.3540401547444603
2dfa8a19-33aa-4b03-b36b-320844d6235d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	04:35:00	2026-08-11	04:40:00	1.15494	1.154618106925043	8118	-2.6131279825018483
4a291ade-95a5-428f-877f-e99c7fad6d16	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	04:45:00	2026-08-11	05:20:00	1.15462	1.1541089291096855	8118	4.148873487572589
248b2569-fabe-4ebb-8957-a9615fdaf90d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	06:20:00	2026-08-11	07:50:00	1.15424	1.15393	8124	-2.518440000000264
c2264ce7-1986-4c65-8b1b-dc881d00ba78	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	07:50:00	2026-08-11	07:55:00	1.15393	1.1542460831827897	8124	-2.5678597769839318
38c76c67-a212-4dbd-85de-f084539bdbd5	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	08:40:00	2026-08-11	08:50:00	1.1542	1.1538960121196973	8120	-2.468381588057227
472068f8-fee5-4e19-92d4-71f1547aa9cf	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	08:55:00	2026-08-11	09:00:00	1.15391	1.1542409261563502	8120	-2.687120389563784
69c6ca7b-6375-4b83-ace9-de43f646dbfc	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	09:05:00	2026-08-11	09:20:00	1.15417	1.15378	8116	-3.1652399999991108
319a95d6-9f62-4e64-bb61-872941b31396	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	09:20:00	2026-08-11	10:15:00	1.15378	1.15384	8116	-0.48695999999958595
1dc51874-518b-4174-9205-33fff4c34b5f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	10:15:00	2026-08-11	10:35:00	1.15384	1.153392894033902	8115	-3.6282649148851287
2d645a3e-f9b3-4f2d-bd1e-5aa4be7aa9e4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	10:40:00	2026-08-11	11:35:00	1.1534	1.15346	8115	-0.486899999999586
f166a074-69fe-4676-9adb-51c1eceb6482	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	11:35:00	2026-08-11	12:35:00	1.15346	1.1534	8115	-0.486899999999586
7abc070f-af66-4fe0-be5e-843e0f09b237	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	12:35:00	2026-08-11	12:55:00	1.1534	1.15359	8114	-1.5416599999992897
b4bb079d-56d2-465f-bd05-107bd256ea5e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	12:55:00	2026-08-11	14:00:00	1.15359	1.1541311683588207	8112	4.389957726754226
1144dcdd-421f-412f-9286-09bdbf91a457	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	14:45:00	2026-08-11	15:30:00	1.15362	1.1540984636863845	8115	-3.8827328150092297
eabe1a85-9a5d-49b8-9309-6556f8bf4592	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	15:40:00	2026-08-11	16:50:00	1.1539	1.1547270265407255	8110	6.707185245284036
2412c681-14b9-4963-90a3-7266631c0325	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	17:05:00	2026-08-11	19:05:00	1.15415	1.15408	8114	0.5679800000001176
364f35b0-ca97-4837-8258-dcde2e62a742	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	19:05:00	2026-08-11	20:05:00	1.15408	1.15393	8115	-1.2172500000007669
ec593ec6-5ab7-44cd-92f0-27cfa7a2e8de	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	20:05:00	2026-08-11	21:00:00	1.15393	1.15376	8115	1.3795500000000283
52dad8fb-5afc-4575-b4fa-66d953a67744	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-11	21:00:00	2026-08-11	23:00:00	1.15376	1.1542988621950185	8117	4.37394443696631
2efcaf27-0c41-416d-9bf4-c2dff05f8585	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-11	23:20:00	2026-08-12	01:10:00	1.15418	1.1542	8118	-0.1623599999992611
171b2f22-6c93-44a7-a4e8-7d07fc89b7c9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	01:10:00	2026-08-12	02:35:00	1.1542	1.15412	8117	-0.6493599999988471
5ef0cf34-8ca3-49b1-b066-8833f57215f1	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	02:35:00	2026-08-12	02:40:00	1.15412	1.1542980511862733	8118	-1.445419530166093
96ba145d-617e-4ba1-86da-f1c225b02531	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	03:00:00	2026-08-12	03:45:00	1.15434	1.15424	8115	-0.8114999999999106
6c96ea89-d8d1-4066-b24e-204b6bf72675	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	03:45:00	2026-08-12	04:00:00	1.15424	1.1538671864414929	8115	3.0253820272846763
3f5baa87-d024-45ca-bf5b-caaa3c267b41	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	05:35:00	2026-08-12	06:45:00	1.1538	1.1536	8120	-1.6239999999998211
b420db3b-c4a3-4fba-8523-5344b2a36820	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	06:45:00	2026-08-12	07:50:00	1.1536	1.15351	8121	0.7308899999993785
307e5282-7d75-4ebe-9408-201da69cf3e7	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	07:50:00	2026-08-12	08:10:00	1.15351	1.1532952843716209	8122	-1.7439203336955251
747f59c2-dceb-49d1-86bb-b5bab35a7f73	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	08:20:00	2026-08-12	08:45:00	1.15331	1.1534	8122	-0.7309799999993785
7c481f52-e553-4f02-b709-d735bb7f1f70	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	08:45:00	2026-08-12	10:00:00	1.1534	1.153746039263852	8121	2.8101848617431235
599edb6f-ce1d-4337-9ee2-4d3c4c38368c	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	11:05:00	2026-08-12	11:15:00	1.15347	1.1538090679601494	8122	-2.7539099723332248
f6b968e4-5668-47fa-8071-f9be9e27b1bb	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	11:45:00	2026-08-12	12:05:00	1.15397	1.15387	8116	-0.8115999999999106
f31f7332-4a36-4f28-9563-f0a32eb3580c	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	12:05:00	2026-08-12	12:20:00	1.15387	1.1542502479725254	8117	-3.086472792989072
9b9488e5-de1f-45ee-964d-4d9d5b08ddba	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	12:25:00	2026-08-12	12:40:00	1.15468	1.1538597643295776	8108	6.650470815784262
4c2f8216-7219-4986-b015-0afcef0e041e	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	12:50:00	2026-08-12	14:30:00	1.15373	1.15386	8121	-1.0557300000015066
db257619-46ca-4bda-943c-fd3deb9d1216	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	14:30:00	2026-08-12	15:25:00	1.15386	1.1546025614492565	8118	6.028113845063782
6da190e5-0335-4487-8935-183afdb63c24	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	16:25:00	2026-08-12	18:40:00	1.15521	1.1535844761736749	8114	13.189500326802612
4929c73d-051f-4eb5-8c3a-7529aabcceea	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	20:15:00	2026-08-12	20:55:00	1.15277	1.1521880613174151	8142	-4.738144753606558
81e31483-d114-47cf-8e57-f399fc6d48f0	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-12	21:00:00	2026-08-12	21:20:00	1.15212	1.15243	8143	-2.5243300000002646
ee155c35-ceb4-486a-ac3c-06db75595f2f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-12	21:20:00	2026-08-13	00:30:00	1.15243	1.15217	8139	-2.116140000001213
a5f1c178-c2ad-4e6d-9742-38051fcbdcc2	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	00:30:00	2026-08-13	01:05:00	1.15217	1.15242	8139	-2.0347500000006793
4b422e3c-4319-4927-9625-c05a1759a000	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	01:05:00	2026-08-13	02:50:00	1.15242	1.15264	8135	1.7897000000008867
d3003b57-1377-40b9-be14-7c3a3f954498	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	02:50:00	2026-08-13	03:05:00	1.15264	1.15286	8135	-1.7896999999990804
da3a0b8f-6f4c-47b0-85c9-6d6c53885d4a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	03:05:00	2026-08-13	03:55:00	1.15286	1.15276	8132	-0.8131999999999104
0a8f2eac-ea2b-4720-b410-d427d1eee3d8	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	03:55:00	2026-08-13	04:30:00	1.15276	1.1530211892629512	8132	-2.1239910863187994
73efb3bc-8485-46e7-8eed-881f07657861	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	06:15:00	2026-08-13	07:55:00	1.15219	1.1526503085876585	8134	3.7441500520137696
bdbb5145-652e-4fb9-b9c7-ecfc07d98432	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	08:55:00	2026-08-13	09:10:00	1.15244	1.1520348201994486	8136	3.2965428572855817
92772cdd-0163-4a72-9280-e0aabb445162	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	10:20:00	2026-08-13	10:45:00	1.15186	1.152493270460321	8143	5.156721358393183
9ae2721b-abe5-45e8-b49b-df0154a3a849	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	12:05:00	2026-08-13	12:10:00	1.15233	1.1527589175195765	8143	-3.4926753619107114
6108d16a-292a-4830-a74e-1118df1cd731	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	12:15:00	2026-08-13	12:55:00	1.15278	1.1534395948531255	8138	5.367782914736225
aa73618f-c9af-4f8a-8f68-27387086fe03	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	13:55:00	2026-08-13	15:15:00	1.15356	1.1530146435056747	8136	4.4370204378297355
c72475c5-877b-404b-a365-79e39eaa425d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	15:55:00	2026-08-13	16:40:00	1.15358	1.15334	8140	-1.9536000000001463
8289f74c-fe0c-4513-a941-b2e3b1bba7d3	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	16:40:00	2026-08-13	17:10:00	1.15334	1.154039090700178	8140	-5.6905982994492454
d63387c4-8a4e-4acb-aecc-b0357560513d	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	17:15:00	2026-08-13	18:20:00	1.15409	1.15355	8130	-4.3901999999998775
858a53c5-d55a-4d79-8c3a-c5b6dbb2066c	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	18:20:00	2026-08-13	20:00:00	1.15355	1.1529	8130	5.284500000000321
04acaba7-063f-46c9-9fc8-83c17ebc18d5	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-13	20:00:00	2026-08-13	22:55:00	1.1529	1.15289	8139	-0.0813900000005332
3d999a98-d50d-4e0e-ad4b-0a5d4f8abea4	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-13	22:55:00	2026-08-14	00:00:00	1.15289	1.15289	8139	0
06f04cf0-bf20-438f-8a67-869f335d63cf	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	00:00:00	2026-08-14	00:10:00	1.15289	1.1526352675117217	8139	-2.0732677220965217
a8c834f8-6e04-48fa-9331-9d974d3dc5e8	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	00:15:00	2026-08-14	00:50:00	1.15259	1.15278	8140	-1.5465999999992874
6bd887b4-d2e8-4415-8497-08813f4064a1	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	00:50:00	2026-08-14	02:00:00	1.15278	1.1531496713256744	8137	3.008015577012981
47ff2431-f0cc-4350-910f-85bc0678ac4f	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	04:10:00	2026-08-14	05:45:00	1.15349	1.15368	8134	-1.545460000001094
76ad77f4-012b-43e1-88d5-63d3fd954fba	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	05:45:00	2026-08-14	05:55:00	1.15368	1.1533882418570047	8132	-2.372577218837886
24a88633-01a3-4fdc-934a-e2dfcb88bcb3	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	06:00:00	2026-08-14	06:20:00	1.15341	1.1537109812828574	8132	-2.4475797921962315
18e7ed41-2017-4c52-8d43-4ae69890d764	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	06:25:00	2026-08-14	07:55:00	1.15371	1.15392	8128	1.7068800000003534
e4390402-f549-4684-ad1e-1a9c74e4ac89	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	07:55:00	2026-08-14	08:40:00	1.15392	1.154213927079203	8128	-2.389039299760668
bd1c6fdd-3b49-4e9f-8c78-1ad6e3dc0582	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	08:45:00	2026-08-14	09:00:00	1.15405	1.154323010708302	8125	-2.2182120049536733
59056e79-7dfb-4375-ad38-2802b07e009c	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	09:20:00	2026-08-14	09:55:00	1.15405	1.15415	8123	-0.8122999999999105
fcf386b8-2f0c-40c5-9c65-7c816ccde10a	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	09:55:00	2026-08-14	10:20:00	1.15415	1.1547125351202694	8122	4.56891024682791
b33e1340-426f-4ff0-8d7d-53f96339e682	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	11:55:00	2026-08-14	14:15:00	1.1554	1.1559122006452998	8116	-4.157020437252984
b528b0a2-21ec-487f-b062-8e8a009fa9f9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	14:20:00	2026-08-14	14:35:00	1.15615	1.1567962290161269	8108	5.239624862756709
81603d65-f50a-4f0a-883f-87ab4b6437e9	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	15:15:00	2026-08-14	15:20:00	1.15639	1.1569933145719729	8110	-4.892881178699602
4d43c419-3e82-4e11-9578-916a8ea2b2cf	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	15:25:00	2026-08-14	15:50:00	1.15695	1.15672	8102	-1.8634599999996149
692d6fdf-490f-485e-8d2e-78b65975961b	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	15:50:00	2026-08-14	16:35:00	1.15672	1.1574403766708654	8103	-5.837212164022671
4eb46907-50a5-4065-8465-a62fbba50c99	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	long	2026-08-14	16:40:00	2026-08-14	17:55:00	1.15815	1.15786	8088	-2.345520000000999
a6f3363d-d551-4ae3-8371-b1da8295baeb	311c4e64-6e70-481b-876e-8adc9455370d	EURUSD	short	2026-08-14	17:55:00	2026-08-14	20:10:00	1.15786	1.1566319301449224	8088	9.932628987866877
aa61e7a2-36e0-477c-b2e5-711142a9bce4	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-03	08:00:00	2026-08-03	08:05:00	1.1535199999999999	1.15326	1	-0.00025999999999992696
7a92f28e-0290-44b2-8ac3-bf0c398ab804	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	10:15:00	2026-08-03	10:30:00	1.15245	1.15296	1	-0.0005100000000000104
777f0643-b879-425e-af79-3e555314eb4a	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	11:50:00	2026-08-03	12:00:00	1.15225	1.15215	1	9.999999999998899e-05
f4f927d4-1362-4ee3-93e4-29a20a0b53af	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	12:05:00	2026-08-03	12:10:00	1.15204	1.15247	1	-0.0004300000000001525
92130548-3b08-4edb-bd50-f2344a268895	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	13:40:00	2026-08-03	13:50:00	1.15205	1.15234	1	-0.00028999999999990145
343c6d0f-4fe7-456c-b8af-0974d5b8cb7e	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	19:05:00	2026-08-03	19:10:00	1.15069	1.15102	1	-0.00032999999999994145
0f63026f-dd4d-446f-aae4-8e5c2cda262f	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	19:15:00	2026-08-03	21:40:00	1.1506	1.15103	1	-0.00042999999999993044
0eac283b-d840-449d-8eb3-ce20d7b91a0d	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-03	23:55:00	2026-08-04	00:00:00	1.15066	1.15062	1	4.0000000000040004e-05
109d73ff-839e-4495-a29d-246806efe210	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-04	03:55:00	2026-08-04	04:00:00	1.1507100000000001	1.15049	1	0.000220000000000109
82a9d35e-cad9-46bb-9242-27901b04cda2	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-04	06:55:00	2026-08-04	07:45:00	1.15075	1.15099	1	-0.00024000000000001798
ccb01705-d024-4153-95c1-9c2ee1783493	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-04	12:45:00	2026-08-04	12:50:00	1.15063	1.15064	1	-1.0000000000065512e-05
c393fb90-2843-4cf4-b0d0-86f04e2d9324	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-04	15:35:00	2026-08-04	15:55:00	1.1521	1.15143	1	-0.0006699999999999484
76ef4ae1-ec54-4fa8-9f05-699760515265	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-04	18:50:00	2026-08-04	19:15:00	1.15234	1.15199	1	-0.00034999999999985043
dcfc6174-d98e-4697-9b91-e66568e25254	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-04	20:40:00	2026-08-04	21:50:00	1.15234	1.15307	1	0.0007300000000001194
605b11be-0aa4-4e3a-b689-47a53d2aa254	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-05	01:00:00	2026-08-05	03:00:00	1.15306	1.15338	1	0.000320000000000098
80222876-0bf5-483f-be3b-5dc800e8af71	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-05	07:00:00	2026-08-05	07:50:00	1.15383	1.15359	1	-0.00024000000000001798
6ab3a3f9-bdaf-4611-a811-9ff5d141b588	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-05	10:20:00	2026-08-05	10:25:00	1.15409	1.15378	1	-0.00031000000000003247
c6e8ffad-439b-44fd-a22a-b1be6160dfd4	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-05	12:20:00	2026-08-05	13:10:00	1.15401	1.15364	1	-0.00036999999999998145
b4dfd5d8-dce4-4277-bacf-d58862d7567b	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-05	14:05:00	2026-08-05	14:15:00	1.15428	1.15464	1	0.000360000000000138
70d880fe-3bca-426e-943d-b26e5b2e8d76	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-06	02:45:00	2026-08-06	02:50:00	1.15565	1.1557	1	4.999999999988347e-05
5ccbd86b-ac0a-404a-aff6-7f33c0ad1b54	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-06	03:20:00	2026-08-06	03:25:00	1.15572	1.15576	1	3.999999999981796e-05
0ea3ab57-bc74-4d11-9dc1-8937a150a2e7	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-06	05:20:00	2026-08-06	05:25:00	1.15578	1.15554	1	-0.00024000000000001798
33fc331c-aaaf-48d1-8159-42bb48e44c0c	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	09:25:00	2026-08-06	09:35:00	1.15449	1.15443	1	5.999999999994898e-05
1c8ad540-204a-4eb3-af80-0fd251d85591	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	09:50:00	2026-08-06	10:05:00	1.15436	1.15429	1	7.00000000000145e-05
41089857-b645-4533-a3d4-d1e50ce9bff2	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	10:45:00	2026-08-06	10:50:00	1.15417	1.15418	1	-1.0000000000065512e-05
d27ceda0-b4dd-465d-b0f4-f83d019f9a83	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	11:25:00	2026-08-06	12:35:00	1.15407	1.15385	1	0.00021999999999988695
26e91a7c-3c53-449e-aed5-8980e1672cd2	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	13:10:00	2026-08-06	13:25:00	1.15369	1.15401	1	-0.00031999999999987594
9a19b31f-5418-4544-b49d-950749fc160f	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	15:45:00	2026-08-06	16:10:00	1.15389	1.15362	1	0.00026999999999999247
9052cd09-9102-4dde-8553-1e53169a9582	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-06	18:10:00	2026-08-06	18:15:00	1.15309	1.15282	1	0.00026999999999999247
eb990e02-64f2-4aa2-9b75-5d48e6995c47	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-07	00:40:00	2026-08-07	01:00:00	1.15186	1.1521	1	-0.00023999999999979593
992ea0d9-b87d-4b7f-893e-4e779338298a	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	02:45:00	2026-08-07	02:50:00	1.15235	1.15238	1	2.999999999997449e-05
a9a44d9b-948b-41dd-ac9a-d39fb85f90f0	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-07	03:55:00	2026-08-07	04:00:00	1.1519	1.15191	1	-1.0000000000065512e-05
fb1ca5bc-aaba-4caa-96e9-8143de7c150c	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-07	05:15:00	2026-08-07	05:20:00	1.15204	1.15226	1	-0.000220000000000109
f6b103a2-7b5d-4a83-aead-e2544e00ea1f	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	08:10:00	2026-08-07	08:15:00	1.15249	1.15245	1	-4.0000000000040004e-05
c177173d-0f43-4321-8d34-1028015dbc76	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	11:45:00	2026-08-07	11:55:00	1.1525	1.15247	1	-2.999999999997449e-05
d163906d-4ca5-4a9e-90df-75d62ad300e8	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	13:50:00	2026-08-07	14:40:00	1.15285	1.15309	1	0.00024000000000001798
d63b1c10-e0b6-4f67-a221-59e49ff62eb0	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	18:15:00	2026-08-07	18:30:00	1.15618	1.15561	1	-0.0005699999999999594
ec4ae720-063b-4248-8159-35ff5df562e5	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	20:25:00	2026-08-07	21:00:00	1.15626	1.15595	1	-0.00031000000000003247
ded8e015-f776-4f49-8e97-d0ad401f9d39	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-07	21:30:00	2026-08-07	23:05:00	1.15633	1.15603	1	-0.000300000000000189
5b74a51f-b31c-46a4-819b-67e0f9f7e52a	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-10	02:35:00	2026-08-10	02:40:00	1.1554	1.15572	1	-0.000320000000000098
92a5261b-7ea2-42ef-9699-d4e61d78c677	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-10	04:30:00	2026-08-10	04:35:00	1.15531	1.15524	1	7.00000000000145e-05
315019cf-407b-418e-ac56-96140965124c	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-10	06:25:00	2026-08-10	06:40:00	1.15499	1.15491	1	7.999999999985796e-05
72844d9a-0074-43f1-a4db-4dd202951780	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-10	12:10:00	2026-08-10	12:30:00	1.15633	1.15596	1	-0.00036999999999998145
18d99230-e165-40b8-bc37-a82026389cf4	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-10	14:05:00	2026-08-10	14:10:00	1.15537	1.15533	1	4.0000000000040004e-05
d2a7d752-c658-4315-8ee0-e57c467cdf47	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-10	16:50:00	2026-08-10	16:55:00	1.1545400000000001	1.15445	1	9.000000000014552e-05
e90256d9-6957-44d0-b51d-944f3db842b0	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-10	20:45:00	2026-08-10	21:50:00	1.15431	1.15408	1	0.00022999999999995246
d8ca449e-a309-4967-b302-15c01f7d4f8f	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-11	02:45:00	2026-08-11	02:50:00	1.15442	1.15441	1	-1.0000000000065512e-05
c96c5c20-87d5-4481-adae-c52d67d0e15a	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-11	02:55:00	2026-08-11	03:00:00	1.15452	1.15459	1	7.00000000000145e-05
9519870d-1a43-4aa6-ac60-4754b60cd032	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-11	04:15:00	2026-08-11	04:30:00	1.15481	1.15494	1	0.00013000000000018552
8d16307d-edce-47d5-a8ac-7592abc03fc5	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-11	07:40:00	2026-08-11	07:45:00	1.15406	1.15426	1	-0.00019999999999997797
dee33114-c8b6-404d-88c6-e48feb713b88	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-11	08:50:00	2026-08-11	09:00:00	1.1540300000000001	1.15425	1	-0.00021999999999988695
5928ff6e-e823-4ab8-9835-78fb53e359a0	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-11	09:20:00	2026-08-11	09:25:00	1.15367	1.15342	1	0.0002500000000000835
cd6f5079-b8ab-4ed1-9075-042380ce59e0	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-11	10:35:00	2026-08-11	10:40:00	1.15355	1.15328	1	0.00026999999999999247
0a3de2fc-6bbf-4d4f-989b-b1362093be55	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-11	16:35:00	2026-08-11	16:45:00	1.15426	1.15449	1	0.00022999999999995246
f6358dc4-34ea-40e5-893c-536b05bb2bf2	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-11	18:00:00	2026-08-11	18:05:00	1.15437	1.15408	1	-0.00028999999999990145
3d66b25e-52b6-4c95-a465-d4cd9ac85d60	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-11	20:55:00	2026-08-11	21:30:00	1.15368	1.15384	1	-0.00015999999999993797
e18bea89-6462-4a01-873d-6cd8f577849c	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-11	23:55:00	2026-08-12	00:00:00	1.15426	1.15412	1	-0.000140000000000029
700f33d1-1f24-4178-b381-c704873789a9	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-12	00:05:00	2026-08-12	00:10:00	1.15422	1.15405	1	-0.00017000000000000348
591b31ce-3b62-4ae4-beae-2d5fa101cdd4	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-12	07:10:00	2026-08-12	07:15:00	1.15345	1.15343	1	2.0000000000131024e-05
7e34aa53-af1b-4f42-85c3-9abf9b2df873	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-12	08:45:00	2026-08-12	09:00:00	1.15327	1.15347	1	-0.00019999999999997797
15191afe-e5b6-4098-bd01-e23dd7729cb6	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-12	13:30:00	2026-08-12	13:35:00	1.1535900000000001	1.15366	1	-6.999999999979245e-05
61fafd72-d233-44de-bdce-61195fdb5b65	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-12	15:30:00	2026-08-12	15:35:00	1.15488	1.15485	1	-2.999999999997449e-05
42a376d7-efd3-4ab2-9d01-699de76f2a55	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-12	21:30:00	2026-08-13	02:00:00	1.15233	1.15266	1	-0.00032999999999994145
fc757e32-4916-4c55-a3c0-02ff0339843b	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-13	06:10:00	2026-08-13	07:45:00	1.1521	1.1524	1	-0.000300000000000189
73b3d54a-265f-4a89-8812-be1fc6538693	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-13	11:30:00	2026-08-13	11:35:00	1.15262	1.15258	1	-4.0000000000040004e-05
adaadd31-a825-4c26-b5c9-59793a093b82	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-13	12:15:00	2026-08-13	12:20:00	1.15288	1.15288	1	0
81e73cee-2591-4fad-996c-1ab62ac0e6bb	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-13	16:35:00	2026-08-13	16:50:00	1.15316	1.1536	1	-0.00043999999999999595
cbc813a3-719f-4fb7-aa31-9afaf82a5c6f	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-13	17:55:00	2026-08-13	18:00:00	1.15438	1.15433	1	-4.999999999988347e-05
7c9a6999-6841-44ab-b3cb-ecbe2c8f8f31	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-13	21:00:00	2026-08-13	21:10:00	1.15265	1.15291	1	-0.000260000000000149
137dd0b6-09d0-461d-9162-0bf84a723105	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	short	2026-08-14	00:50:00	2026-08-14	01:00:00	1.15264	1.15284	1	-0.00019999999999997797
43c9a65d-27f6-48e6-bcc2-8e589e6ed069	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	06:20:00	2026-08-14	07:05:00	1.15371	1.15389	1	0.000180000000000069
bf0811ed-356c-40dc-beb5-196546871760	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	09:00:00	2026-08-14	09:05:00	1.15425	1.15428	1	2.999999999997449e-05
d1c9b881-de90-4cdd-9a94-4cbf43144f64	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	09:35:00	2026-08-14	09:55:00	1.1542	1.15438	1	0.000180000000000069
e46c4a51-93ef-4517-8b66-fe5ccf858cec	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	10:00:00	2026-08-14	10:05:00	1.15453	1.15444	1	-9.000000000014552e-05
c6c7a96e-0e20-4b87-9703-11b365609e89	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	12:55:00	2026-08-14	14:00:00	1.15544	1.15572	1	0.000280000000000058
4f5afbb2-f26b-4ddc-9e6c-82a2f1c02c90	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	16:35:00	2026-08-14	16:40:00	1.15725	1.15815	1	0.0009000000000001229
53559e50-ca37-4f47-9a81-37b2683ac6df	6a26127b-2645-4eec-b47e-642b876d3873	EURUSD	long	2026-08-14	18:30:00	2026-08-14	19:10:00	1.15819	1.15769	1	-0.0004999999999999449
cf50a61c-52e4-4986-aa13-151fc4238230	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-03	06:15:00	2026-08-03	07:05:00	1.1528	1.15304	307928	-73.90272000000553
c519430c-e298-474a-9200-52aaf1a4ad8b	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-03	09:35:00	2026-08-03	10:35:00	1.15302	1.15317	369237	-55.3855500000349
e17964be-da39-4663-aef5-d19026041ccc	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-03	13:20:00	2026-08-03	14:05:00	1.15191	1.152620412067986	279327	-198.43727171430973
894e296e-c2a1-49af-9e85-cde098412f7a	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-03	17:05:00	2026-08-03	21:20:00	1.15214	1.15091	226639	278.7659699999643
0ccd4f57-9808-4d67-868c-50f585a4820b	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-03	23:15:00	2026-08-04	01:00:00	1.15072	1.15109	477616	-176.71791999999115
26c298fe-1683-4471-a87e-4e4d2c2d2597	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-04	04:00:00	2026-08-04	04:30:00	1.15049	1.1509326655132495	452222	-200.18308373269355
558e925e-e189-4f7d-a70e-9bd4afaa4551	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-04	08:45:00	2026-08-04	09:20:00	1.15053	1.1508830885291585	542867	-191.68011055868536
36579f5b-cac4-4964-9444-17f7fb46d5b1	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-04	12:10:00	2026-08-04	12:35:00	1.15048	1.151091801868138	310135	-189.74117237498757
25a838a0-0f97-4a5a-ab54-7bd480b1faaa	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-04	16:05:00	2026-08-04	16:20:00	1.15113	1.1517840869667215	277202	-181.31421534914276
368cc2f2-48f9-47c4-b41c-2a75ac140ee2	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-04	18:20:00	2026-08-04	18:35:00	1.15141	1.1521775021669194	232472	-178.42276374807344
856fe7d0-9935-486e-8f48-1c2d9b776f92	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-05	00:10:00	2026-08-05	01:00:00	1.15263	1.1530281134673661	440358	-175.312450262387
11cb8c98-0fd5-43b3-a908-d3d62ab2ec6e	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-05	04:05:00	2026-08-05	05:20:00	1.1529199999999997	1.1532916360517103	473183	-175.85186185654527
131a883c-4b65-4d2c-a5cb-eaeaeafc8034	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-05	08:05:00	2026-08-05	08:30:00	1.15322	1.1535955907497017	445682	-167.39403650861428
a9a050c7-a6eb-4811-9d96-5c16e76daf68	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-05	18:50:00	2026-08-05	20:30:00	1.1543	1.15487	194716	-110.9881199999921
cbab08a7-e0ae-4f3d-b1f3-d32831c0a336	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-05	22:20:00	2026-08-05	23:30:00	1.15486	1.1553517479635291	325568	-160.0974009902525
cd3b5d8f-02dd-439f-9346-cf32a2df65c3	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-06	06:00:00	2026-08-06	08:55:00	1.15534	1.15499	461086	161.38010000003342
ec9b5b67-8ae3-4057-a6f2-c064f5bb9d62	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-06	10:10:00	2026-08-06	10:15:00	1.15423	1.154614003922317	446670	-171.52303198126992
7228c7ec-4f71-4688-916c-ba7451956e1d	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-06	12:45:00	2026-08-06	13:30:00	1.15376	1.1541	333152	-113.27168000000232
3fa920cb-2f95-4fae-a13f-705df4e5a507	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-06	17:10:00	2026-08-06	21:00:00	1.15342	1.15226	245215	284.4493999999578
8fca4bff-bdcb-43e9-94d4-c3e4b4b0fd7e	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-07	00:55:00	2026-08-07	01:00:00	1.15181	1.1521418961731453	501399	-166.41240931889513
c3cb6715-c518-4fec-8ee3-3a1d05efc28b	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-07	03:15:00	2026-08-07	04:40:00	1.15211	1.1523240203846201	759730	-162.59770680746695
d60ffefa-0624-4e66-98f9-d41644808ae8	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-07	06:10:00	2026-08-07	06:55:00	1.15198	1.1522783346321066	524408	-156.44906775375816
4399d99b-ace1-407c-b933-5b3e488b4b4e	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-07	10:05:00	2026-08-07	10:10:00	1.15192	1.1522979243031861	431447	-163.0543068367166
0cf9d188-9d7c-4ad3-a10a-c0ed299d8bb8	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-07	23:10:00	2026-08-10	00:10:00	1.15594	1.1563	314227	-113.12172000004335
56b8ad58-22ab-43b4-a8ae-982d25ebb315	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-10	01:30:00	2026-08-10	03:00:00	1.15547	1.155836831433387	399659	-146.6074838359726
6b35df3f-4ad9-413c-8237-743a16c83a51	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-10	06:05:00	2026-08-10	07:50:00	1.15505	1.15517	427709	-51.32508000005133
4aae375f-fb10-4a48-b65c-24e4aa61b809	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-10	12:40:00	2026-08-10	15:10:00	1.15573	1.15547	314109	81.66833999997705
90421093-e628-480e-bdbb-ae16f102deeb	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-10	15:30:00	2026-08-10	16:15:00	1.15485	1.15519	301883	-102.6402200000021
85d7f04e-c7a2-4803-964d-6d3b0d7370de	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-10	16:55:00	2026-08-10	17:15:00	1.15445	1.1550262140500267	251741	-145.05670116777762
c25b0a65-9761-4747-9da0-b961e75d5bd6	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-10	19:50:00	2026-08-11	01:05:00	1.15457	1.15433	248696	59.68704000000447
2c05171a-3629-4c66-af9c-9a6024ee352d	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	05:25:00	2026-08-11	06:30:00	1.15406	1.154414663290308	412673	-146.35996400126385
64c56200-b382-4529-a8bb-5b3bc8d3e4db	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	07:50:00	2026-08-11	07:55:00	1.15393	1.1542419720052202	453456	-141.4655775991593
e86e1d46-2476-4ed4-b9ee-5cbe26167d2f	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	08:55:00	2026-08-11	09:00:00	1.15391	1.1542331593306097	435092	-140.6040394736217
aef23df4-4221-4c24-a21c-cd4189b6b97d	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	09:20:00	2026-08-11	11:40:00	1.15378	1.15363	387485	58.12275000003662
2689bb4e-f9e1-46dd-b99d-33baf036a1c9	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	18:15:00	2026-08-11	18:55:00	1.15372	1.1542834556171726	235756	-132.83804248212599
3ded10a6-867c-41b9-8958-f655b6c87e20	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	20:10:00	2026-08-11	21:35:00	1.15358	1.1540178449015437	296746	-129.92872315346844
a11259b1-c8f5-4357-87d6-e2c962251404	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-11	23:45:00	2026-08-11	23:55:00	1.15396	1.1542178938241	519569	-133.99363629370765
d24bed31-dcbb-43e3-bb5f-f5b7f76d1f49	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-12	00:30:00	2026-08-12	01:00:00	1.15387	1.1541077881831818	529120	-125.81848348519375
396e248d-7314-4872-adae-d908cba81152	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-12	03:55:00	2026-08-12	10:00:00	1.154	1.1537	505901	151.77029999998328
d1d28b88-7c82-49f9-984a-6756611676d5	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-12	13:50:00	2026-08-12	14:30:00	1.15344	1.1539460138580278	253221	-128.13333514364027
9f3499d7-0f4f-42ca-a328-8ab73090213c	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-12	18:45:00	2026-08-12	23:45:00	1.15367	1.15244	158027	194.37321000001018
e6dbdd36-bf27-4aeb-9222-5ae429a38e77	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-13	04:55:00	2026-08-13	07:50:00	1.15239	1.15235	445335	17.813400000017815
3cc30a0b-b597-45af-9104-8b963dee21f5	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-13	09:15:00	2026-08-13	10:25:00	1.15206	1.15207	434000	-4.339999999932065
e455c58a-33bf-4d2d-b2a8-3bcbbddccfc2	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-13	15:20:00	2026-08-13	15:30:00	1.15304	1.153419332283468	337779	-128.13047937753126
57848357-e71b-40ec-800d-0ed49b36b347	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-13	15:35:00	2026-08-13	15:45:00	1.15295	1.1534168650165382	278677	-130.10454221383094
f8521396-e7a9-419e-94b0-b52f14a14163	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-13	18:55:00	2026-08-13	21:15:00	1.15312	1.15309	171988	5.159639999995613
70692de6-10f8-4efc-ac4c-027b902b8bf5	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-13	23:15:00	2026-08-13	23:55:00	1.15268	1.15293	370504	-92.62600000003093
91485a3b-9173-41af-b35c-735633fb2189	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-14	00:15:00	2026-08-14	01:00:00	1.15259	1.1528880197542226	423590	-126.23818769115601
ac01395f-3e2c-47e3-87c3-8a8061bcc36c	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-14	04:25:00	2026-08-14	04:30:00	1.15321	1.1534933672022074	438216	-124.17604188249206
122b393f-eaa3-452c-94f7-9eabc063ffa2	7ae667fa-4eda-4190-a572-5f02ba6dada5	EURUSD	short	2026-08-14	19:15:00	2026-08-14	21:30:00	1.15763	1.1566	165360	170.32079999997757
ca5949ae-2ee1-4c80-aa91-b729982db32f	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-03	08:15:00	2026-08-03	08:50:00	4057.51	4065.118557011278	26	-197.82248229322158
e6ef0b8d-7bcb-490d-ad99-0a6522058062	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-03	10:20:00	2026-08-03	12:15:00	4054.614	4061.312	21	-140.65799999999717
5676eb51-e041-4715-aabd-86be90f06bcb	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-03	12:30:00	2026-08-03	14:45:00	4052.759	4060.5962506501155	25	-195.93126625288733
a9b7dd38-c2d3-44c2-aeec-f5da357cb7f2	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-03	15:45:00	2026-08-03	16:00:00	4044.78	4052.9739839020335	22	-180.26764584473312
c928e38a-6ad6-4e09-a00f-2783df390230	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-03	16:15:00	2026-08-03	21:45:00	4038.9479999999994	4041.33	20	-47.64000000001033
eb5ff50d-f0d7-430b-a211-c351a73a1ebd	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-04	04:00:00	2026-08-04	04:40:00	4049.205	4056.1070112839952	27	-186.3543046678733
fbaa3bb6-3315-4f6e-9561-271b17d71276	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-04	06:45:00	2026-08-04	07:25:00	4053.0279999999993	4059.8302658438583	26	-176.8589119403341
624ed948-f32a-4b0b-833d-05042d557867	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-04	09:35:00	2026-08-04	09:55:00	4056.907	4063.442995459115	26	-169.93588193698815
af9958d6-5399-4fcc-9a82-5e6f67e4604c	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-04	11:50:00	2026-08-04	13:45:00	4056.408	4052.669	24	89.73600000000079
a1208468-5d91-48d3-81db-5ba7bfe08b0d	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-04	21:30:00	2026-08-05	01:30:00	4084.68	4079.909	21	100.19099999999435
0d09a228-f930-4afc-8382-70a6e43eddf0	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-05	02:05:00	2026-08-05	03:20:00	4069.918	4076.128812686614	28	-173.9027552251846
75281f7b-b1da-4e82-9ddd-3d520cc1a1ea	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-05	12:25:00	2026-08-05	14:00:00	4157.541	4161.255	19	-70.5659999999989
8bb5715e-f305-42d7-b897-3aafa9eb9dd1	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-05	19:05:00	2026-08-05	19:30:00	4225.993	4243.067297889984	10	-170.74297889983427
b50fbd43-3ba0-4026-a11d-8649c0298f68	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-05	23:00:00	2026-08-06	02:05:00	4246.828	4252.907	17	-103.3429999999953
0903991b-5b70-4829-9f51-6a18e02b1e51	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-06	06:15:00	2026-08-06	08:55:00	4274.057	4267.055	11	77.02199999999448
3fb4c7b7-2d35-4474-b912-1654da1db41d	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-06	13:45:00	2026-08-06	15:35:00	4265.608	4267.643	19	-38.664999999997235
3c35e44d-9027-4330-a19f-7cd4f1856289	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-06	15:55:00	2026-08-06	16:35:00	4250.964	4262.039839608164	15	-166.137594122456
9d062f18-0b51-4f98-ad8f-3a31b91b2f07	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-06	18:25:00	2026-08-06	20:55:00	4254.591	4246.919	11	84.39200000000528
2a45d052-e1da-4b03-9a2e-d5a5c7edc6c1	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-06	22:25:00	2026-08-06	22:50:00	4240.105	4249.281822039286	18	-165.18279670716402
787af9fb-c893-4d1d-9888-22e932620d9e	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-07	03:40:00	2026-08-07	04:05:00	4235.811	4243.741651007148	21	-166.54367115011428
52e16bb4-4ed9-4bb7-9ac0-16cd6c0547ba	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-07	15:25:00	2026-08-07	15:30:00	4310.823	4322.030681609463	15	-168.11522414193405
6b855970-0af1-4d9f-ba2c-7c6f44250078	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-07	19:25:00	2026-08-07	22:20:00	4338.268	4346.934	10	-86.66000000000167
0dc23b16-32ee-45a6-b7db-e07948109d39	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-10	03:00:00	2026-08-10	03:05:00	4332.573	4341.2316666919305	18	-155.85600045474348
8a5e35c3-b287-419c-a327-c4f61181f842	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-10	04:05:00	2026-08-10	05:25:00	4327.182	4327.056	15	1.890000000003056
10f0d176-6d62-4e9c-b14f-68f7d4f2804d	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-10	11:40:00	2026-08-10	16:15:00	4348.5	4337.077	17	194.19099999999617
34daafc5-ab7d-49c4-b505-1c6a4a5a86ce	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-10	16:55:00	2026-08-10	17:15:00	4323.18	4333.600207470666	15	-156.3031120599817
1798403f-e2ab-46df-9694-3fb0c33e8e90	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-11	07:50:00	2026-08-11	11:30:00	4407.871	4368.991	15	583.2000000000016
869e70fc-6584-4863-b8c0-7e9883510865	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-11	16:55:00	2026-08-12	01:05:00	4387.44	4372.807	12	175.59599999999773
1ee3fce9-0fb4-45fc-8b37-37322b503434	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-12	02:05:00	2026-08-12	02:15:00	4364.636	4371.608738117062	25	-174.31845292653634
dfd539ed-7a79-42a2-9aa8-92a9a5f029ee	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-12	07:15:00	2026-08-12	08:10:00	4397.504	4404.267	21	-142.02299999999832
01994e5f-336d-43b8-9043-603fb3ba9c99	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-12	08:25:00	2026-08-12	09:50:00	4394.127	4401.356162719847	22	-159.041579836623
01023996-3a26-4c30-8e9b-92e2cdaf7130	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-12	19:50:00	2026-08-12	21:35:00	4402.793	4412.15	11	-102.92699999999968
c87d609d-dda6-43ff-993e-9047bf9ce7e1	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-12	23:20:00	2026-08-13	02:10:00	4407.204	4405.404	20	35.99999999998545
1905ec60-c354-470a-9fc6-1109ecdb1c3e	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-13	04:50:00	2026-08-13	08:15:00	4412.903	4404.425	12	101.73600000000079
d25c8fd0-a853-47cb-9313-0ef1b0094da0	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-13	08:45:00	2026-08-13	10:00:00	4387.713	4380.68	15	105.4949999999917
cbe1785d-18a4-4bb7-be00-8036a2774813	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-13	11:05:00	2026-08-13	11:45:00	4366.928	4376.34067743404	16	-150.60283894464374
efba6303-811f-4239-a5db-30868999daf1	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-13	16:35:00	2026-08-13	17:45:00	4378.71	4381.182	13	-32.135999999996784
d33f0cbd-8c81-47c1-8149-931493b2dbc0	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-13	19:15:00	2026-08-13	19:55:00	4355.356	4368.28226555752	11	-142.1889211327234
ded27c0c-e8e4-4b75-976a-053bdcca53df	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-13	22:10:00	2026-08-14	01:05:00	4353.665	4352.976	18	12.4020000000055
7feee71e-4969-4b1c-8d8d-d66d79c852c1	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-14	03:25:00	2026-08-14	06:25:00	4347.123	4325.041	17	375.3939999999902
b42c19d4-5d67-4bed-8bb2-633449a2ee0a	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-14	08:10:00	2026-08-14	08:50:00	4320.131	4327.261869230866	22	-156.87912307904662
e183a7d9-e9b8-4a0a-913c-3d0685535a8d	9a999ad7-fa69-4b07-98c5-fb4823a7d8ce	XAUUSD	short	2026-08-14	20:30:00	2026-08-14	21:40:00	4379.528	4382.571	19	-57.81699999999364
35b4da6f-6d30-40d4-922e-6e551d810f40	fcb7d560-a7de-4376-9ca4-9917aef450d7	EURUSD	short	2026-08-11	03:05:00	2026-08-11	03:25:00	1.15466	1.154819278483087	663299	-105.64925855316068
0e695d14-6934-41d8-aa4c-6a0e4c558d45	fcb7d560-a7de-4376-9ca4-9917aef450d7	EURUSD	short	2026-08-12	14:55:00	2026-08-12	15:30:00	1.15446	1.1548200279535488	273069	-98.31247324759678
ae5783f5-4799-4f4f-a77d-93fcddebc4d0	fcb7d560-a7de-4376-9ca4-9917aef450d7	EURUSD	short	2026-08-13	03:05:00	2026-08-13	03:30:00	1.15286	1.1530011971694296	697127	-98.43235913296186
9eee765f-d15f-4c43-9977-a7df9c30e0c7	fcb7d560-a7de-4376-9ca4-9917aef450d7	EURUSD	short	2026-08-13	03:35:00	2026-08-13	12:30:00	1.15304	1.1532046771837172	610360	-100.51236585360246
014fca5c-1465-45c6-829e-f1bef5d2eff5	77e3c523-dce8-43c3-973e-9b6c483be579	EURUSD	short	2026-08-11	03:05:00	2026-08-12	15:30:00	1.15466	1.15546	125000	-99.99999999998899
5c64bcf7-6824-4022-bccc-7c57dd6d265c	77e3c523-dce8-43c3-973e-9b6c483be579	EURUSD	short	2026-08-13	03:05:00	2026-08-13	13:20:00	1.15286	1.15366	123750	-98.9999999999891
5d5ed11a-5fd2-4bdf-9743-6f052828988d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-03	14:15:00	2026-08-03	17:15:00	1.1525	1.15159	8242	-7.500220000001553
c6b4d1ae-3260-4ae3-b01d-5645eedfe4f8	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-03	17:15:00	2026-08-03	21:30:00	1.15159	1.1509	8243	5.687669999998825
00b5faba-1aaf-4314-954b-c31fdd42cb0a	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-03	21:30:00	2026-08-04	04:15:00	1.1509	1.15049	8252	-3.383320000000177
70a36efb-24bb-4fb8-af30-9ab86e1d4c6b	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-04	04:15:00	2026-08-04	04:30:00	1.15049	1.15079	8253	-2.4758999999997275
418ffed8-8481-4713-bc99-920d84c582b3	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-04	04:30:00	2026-08-04	07:00:00	1.15079	1.15079	8248	0
80dc898b-770f-4421-b108-5f7f638638ee	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-04	07:00:00	2026-08-04	10:30:00	1.15079	1.15123	8248	-3.6291199999999666
315aebda-1810-4162-b8af-fa5dd884217d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-04	10:30:00	2026-08-04	12:15:00	1.15123	1.15066	8242	-4.697939999999665
0d5fd3ac-dee8-4b06-a46c-29d349fc6dc6	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-04	12:15:00	2026-08-04	12:30:00	1.15066	1.15101	8242	-2.8847000000005973
a646c0f8-f3bd-46c2-bb05-1443a1aeba4d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-04	12:30:00	2026-08-04	12:45:00	1.15101	1.15078	8238	-1.8947400000014376
151d8929-f16e-45af-8bdc-376bafe4afd5	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-04	12:45:00	2026-08-04	13:15:00	1.15078	1.15097	8238	-1.565220000001108
931a4be8-1936-4721-a465-4e81d9cb05e1	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-04	13:15:00	2026-08-04	16:15:00	1.15097	1.15127	8235	2.4704999999997277
d2952867-95c9-4ff3-80a1-6481e96d6d98	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-04	16:15:00	2026-08-04	16:45:00	1.15127	1.15229	8235	-8.399700000000172
356a5465-ec40-4715-bd26-2603a3587bea	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-04	16:45:00	2026-08-04	18:30:00	1.15229	1.15173	8221	-4.603760000000953
c71692e6-d814-4863-a437-263b2f5b1d72	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-04	18:30:00	2026-08-04	21:30:00	1.15173	1.15248	8221	-6.165750000000234
347c0c97-61ce-49da-8777-e054dfdb5bd0	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-04	21:30:00	2026-08-05	00:15:00	1.15248	1.15264	8211	1.3137600000013139
7f00c605-f792-41e4-8f85-9ed50e1c3407	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	00:15:00	2026-08-05	05:45:00	1.15264	1.15399	8210	-11.083499999999692
6e881a14-f54a-4ed1-8c4d-4fa2201ccc28	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	05:45:00	2026-08-05	08:15:00	1.15399	1.15337	8191	-5.078420000000532
62a279cc-64b5-41f3-82a0-d4ede081ca55	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	08:15:00	2026-08-05	09:45:00	1.15337	1.15417	8192	-6.553599999999278
2c41f2da-8a37-4db7-b18c-d81396d70bcd	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	09:45:00	2026-08-05	10:30:00	1.15417	1.1534	8181	-6.299369999999488
651c186f-c4f0-4804-bc67-e5410e7ca0c6	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	10:30:00	2026-08-05	11:30:00	1.1534	1.15434	8181	-7.690139999999516
80a239ba-6bd2-42f6-8774-3613f06c6368	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	11:30:00	2026-08-05	11:45:00	1.15434	1.15346	8168	-7.187839999999934
ab752e67-c389-45b1-9c27-401c66b83de0	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	11:45:00	2026-08-05	12:45:00	1.15346	1.15411	8168	-5.309200000000322
d342dd2e-910a-46a2-a0fa-544934275d31	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	12:45:00	2026-08-05	13:15:00	1.15411	1.15361	8159	-4.079499999999551
b06ce233-9179-46f1-a7b3-80fa8d194bc5	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	13:15:00	2026-08-05	14:15:00	1.15361	1.15457	8160	-7.833600000000587
29e2dc18-9461-41bf-ba51-f7b90683bff7	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	14:15:00	2026-08-05	16:45:00	1.15457	1.15453	8146	-0.32584000000032587
7c8b8e71-c56a-44f1-b7be-17129475892b	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	16:45:00	2026-08-05	18:00:00	1.15453	1.15529	8146	-6.190959999998956
249766fa-8fd2-42a3-826c-5860708f851e	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	18:00:00	2026-08-05	18:15:00	1.15529	1.1549	8135	-3.1726499999991087
b5f2e275-330b-4d1a-803e-00336db4aad8	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	18:15:00	2026-08-05	21:00:00	1.1549	1.1556	8136	-5.695199999999373
7a941b73-db36-4f82-9ccf-f35e6fc365e9	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-05	21:00:00	2026-08-05	22:30:00	1.1556	1.15478	8127	-6.664140000000349
025f1e25-e331-4dba-b451-916fa0e8ab7a	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-05	22:30:00	2026-08-06	01:30:00	1.15478	1.15537	8127	-4.794930000000735
011e7425-d4ea-41fe-b926-8c575efb8e89	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-06	01:30:00	2026-08-06	04:15:00	1.15537	1.15553	8118	1.2988799999994964
3c73d210-ce91-4792-9b15-197889dcd3b8	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-06	04:15:00	2026-08-06	14:00:00	1.15553	1.15409	8119	11.691359999999072
49b1f97c-ce34-4987-adb7-e25ac05347bf	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-06	14:00:00	2026-08-06	17:15:00	1.15409	1.15345	8138	-5.208319999999787
6af9a8bd-2ae2-4fa4-ade7-293dcec89182	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-06	17:15:00	2026-08-06	21:15:00	1.15345	1.15232	8139	9.197070000000613
d172245c-6c1f-47ae-819c-1c361e3880ef	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-06	21:15:00	2026-08-07	10:15:00	1.15232	1.15226	8154	-0.489239999999584
4db7718c-1c26-4218-9116-fc08f7a56196	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-07	10:15:00	2026-08-07	12:00:00	1.15226	1.15232	8154	-0.489239999999584
775e3ee7-5865-40c5-a01c-1578e4bf938f	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-07	12:00:00	2026-08-07	18:00:00	1.15232	1.15527	8153	24.051350000000067
035d1bcf-4e1c-439a-b6b8-cf54741584c8	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-07	18:00:00	2026-08-10	08:15:00	1.15527	1.15511	8152	1.3043199999994943
3a65a0d1-f8a6-4bad-9e48-912c83251418	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-10	08:15:00	2026-08-10	13:00:00	1.15511	1.15565	8155	4.403699999999877
be3c777f-b6cc-4161-a986-1d71daf674a2	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-10	13:00:00	2026-08-10	17:45:00	1.15565	1.15534	8154	2.5277400000002648
40302263-88ca-42d3-b8fe-4c4713128298	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-10	17:45:00	2026-08-10	20:00:00	1.15534	1.1547	8159	-5.2217599999997875
609bebac-fb40-4bd3-a868-320742e24599	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-10	20:00:00	2026-08-10	23:30:00	1.1547	1.15414	8159	4.569040000000946
98b7c834-e633-48e9-82ca-731b0773d545	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-10	23:30:00	2026-08-11	05:30:00	1.15414	1.15409	8166	-0.4082999999990484
7faf3ec0-98bd-4932-9431-71d761e419c9	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-11	05:30:00	2026-08-11	13:00:00	1.15409	1.15366	8167	3.5118100000012453
688b07e8-1f21-466d-bdae-a6d8a5f6066d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-11	13:00:00	2026-08-11	18:15:00	1.15366	1.15372	8172	0.49032000000139764
becbe4c6-9847-47a7-9f53-c942f2104ab4	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-11	18:15:00	2026-08-11	22:00:00	1.15372	1.15403	8172	-2.533319999998451
e4b91bbc-f9b3-4f8a-9b3b-16679d7fa251	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-11	22:00:00	2026-08-12	00:30:00	1.15403	1.15387	8168	-1.3068799999994933
395af10b-8322-4514-8b25-516b4ba1158e	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-12	00:30:00	2026-08-12	01:15:00	1.15387	1.15428	8168	-3.3488800000001753
787ed354-684a-40ab-98f6-7a2c44073c5f	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-12	01:15:00	2026-08-12	04:00:00	1.15428	1.15408	8163	-1.6325999999998202
652c5c2e-8442-46b3-962a-7cca0c304d52	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-12	04:00:00	2026-08-12	09:30:00	1.15408	1.15353	8163	4.489650000000411
8eb2b3cc-ed14-47ad-8826-53e1a2801cbd	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-12	09:30:00	2026-08-12	13:45:00	1.15353	1.15368	8170	1.225500000000772
59fff79c-dd59-4dff-85ec-3b3ac37d7f43	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-12	13:45:00	2026-08-12	14:45:00	1.15368	1.15403	8170	-2.859499999998778
99839812-2244-4cc5-8218-d9cc3c92fe30	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-12	14:45:00	2026-08-12	17:45:00	1.15403	1.15446	8165	3.510950000001245
3db4e3da-557f-497f-89cc-1879a110a559	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-12	17:45:00	2026-08-12	23:30:00	1.15446	1.15222	8165	18.28960000000016
8469b48a-aaa5-49a7-90a3-15368e0d9ff8	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-12	23:30:00	2026-08-13	05:30:00	1.15222	1.15215	8196	-0.5737200000001188
544e89a1-e1e1-46ef-bba6-e0d1cffd1c6d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-13	05:30:00	2026-08-13	08:00:00	1.15215	1.15253	8196	-3.114480000000385
1ea489fb-2947-4494-bca5-b91cc6aac07a	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-13	08:00:00	2026-08-13	09:30:00	1.15253	1.15181	8191	-5.8975200000004415
40441e85-2a08-4d4e-a40b-73b3774e565f	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-13	09:30:00	2026-08-13	10:45:00	1.15181	1.15245	8191	-5.242239999999787
dbb0942f-0c82-4b51-8f90-5240d0536d0b	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-13	10:45:00	2026-08-13	15:30:00	1.15245	1.15315	8182	5.727399999999369
047dd57e-ad86-4047-8ae5-45e95de7bfaa	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-13	15:30:00	2026-08-13	16:00:00	1.15315	1.15437	8182	-9.98203999999999
00a14712-df1f-4eeb-88ee-399c02ec175d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-13	16:00:00	2026-08-13	16:45:00	1.15437	1.15342	8165	-7.756750000000052
809aa2af-3724-4583-8954-e25443f7e01b	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-13	16:45:00	2026-08-13	17:45:00	1.15342	1.154	8165	-4.735700000000204
11173f5f-c759-4fd6-bc04-0d94cd03b563	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-13	17:45:00	2026-08-13	18:30:00	1.154	1.15332	8158	-5.547440000000114
d2d6fe18-c7ec-4dea-bf28-d13c7deb11a8	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-13	18:30:00	2026-08-13	22:30:00	1.15332	1.15308	8158	1.9579199999983352
46730885-aef4-456b-88a2-a05bd9fb956b	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-13	22:30:00	2026-08-13	22:45:00	1.15308	1.15281	8161	-2.203470000001751
9307b8bc-73f2-4a3f-a107-a9fe0b408294	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-13	22:45:00	2026-08-14	00:00:00	1.15281	1.15289	8161	-0.6528800000006529
8729b70b-8b94-4e23-ab7b-77d19fb6f34d	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-14	00:00:00	2026-08-14	00:15:00	1.15289	1.15259	8160	-2.4479999999997304
efe2efff-3dc8-46b2-b0a7-1c54c64f56cd	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-14	00:15:00	2026-08-14	01:00:00	1.15259	1.1528	8160	-1.7136000000003548
6c65b279-8762-41bc-8463-76cde62ee134	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-14	01:00:00	2026-08-14	06:15:00	1.1528	1.15353	8158	5.955339999999163
40fd4797-849a-43bd-87ed-b66d1176956c	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-14	06:15:00	2026-08-14	06:30:00	1.15353	1.15379	8157	-2.120820000001215
db0e1b87-4eeb-4f33-9c37-4b5264f94fe1	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-14	06:30:00	2026-08-14	13:30:00	1.15379	1.1553	8153	12.311029999999187
6c53387b-0a64-45f8-ac24-8af8b6d68f50	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	short	2026-08-14	13:30:00	2026-08-14	14:15:00	1.1553	1.15587	8153	-4.647209999999669
52225075-8ddf-4260-80bd-e8d632fb94a0	a8c421fb-d553-4b15-9b35-16768d991c3d	EURUSD	long	2026-08-14	14:15:00	2026-08-14	19:00:00	1.15587	1.15799	8145	17.267400000000993
3543d208-e798-4d27-96c8-4bc888a7e408	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	09:15:00	2026-08-03	10:35:00	1.15327	1.15317	8237	0.8236999999999093
587b9665-1132-498c-b88f-ce0483fc6789	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-03	10:35:00	2026-08-03	11:05:00	1.15317	1.15239	8238	-6.425640000000024
77fbd33c-7d7d-46e6-a033-b235505efd8d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	11:05:00	2026-08-03	11:15:00	1.15239	1.15268	8239	-2.3893099999991882
5bcba26a-62ca-43ba-ab11-b5d4d0bcea65	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-03	11:15:00	2026-08-03	11:20:00	1.15268	1.1523	8234	-3.1289199999985584
98dd2d4f-ba00-43ab-a5e3-3fd473e89405	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	11:20:00	2026-08-03	11:25:00	1.1523	1.15263	8235	-2.717549999999518
605a3402-eca3-49d6-ae76-50290a6ae588	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-03	11:25:00	2026-08-03	12:00:00	1.15263	1.15222	8230	-3.3743000000001766
f28ce4fb-d875-42df-b3a5-020bada90ab8	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	12:00:00	2026-08-03	12:15:00	1.15222	1.15242	8230	-1.6459999999998187
4ddedf87-a96a-47f1-8dfe-f913d5628062	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-03	12:15:00	2026-08-03	13:20:00	1.15242	1.15191	8227	-4.195770000000086
0169d63b-5364-48ef-896b-090a27297c76	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	13:20:00	2026-08-03	14:05:00	1.15191	1.15249	8228	-4.772240000000205
ef098462-90da-466a-bf44-eba4ceba86d7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-03	14:05:00	2026-08-03	15:45:00	1.15249	1.15244	8220	-0.41100000000086734
416843b6-a657-46fc-baec-9ae5992cd36c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	15:45:00	2026-08-03	18:55:00	1.15244	1.15077	8220	13.72739999999867
f7cc9668-532a-473c-a117-1ed6897ba8d9	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-03	18:55:00	2026-08-03	22:45:00	1.15077	1.15124	8243	3.8742099999997563
d8b54068-5553-43b7-a375-ded3a12fd19b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-03	22:45:00	2026-08-04	00:35:00	1.15124	1.15077	8243	3.8742099999997563
11f5c0e1-d8af-46a1-9296-4b301f0554fb	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	00:35:00	2026-08-04	01:15:00	1.15077	1.15072	8247	-0.4123500000008702
93b1c358-8b9c-426a-98c5-dc7d90edfc1f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	01:15:00	2026-08-04	01:50:00	1.15072	1.15081	8249	-0.7424100000012004
11141f40-5339-4283-9fd1-5d2a6dd87f3a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	01:50:00	2026-08-04	02:45:00	1.15081	1.15074	8248	-0.5773600000001196
83411c0b-47dc-4afe-bae0-588a1805e297	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	02:45:00	2026-08-04	03:10:00	1.15074	1.15124	8248	-4.123999999999546
5145bcd7-12c5-4527-ad67-3d21a707e59c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	03:10:00	2026-08-04	04:00:00	1.15124	1.15049	8241	-6.180750000000234
69f65b2e-4500-4c27-a2ab-f82519d7fe47	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	04:00:00	2026-08-04	04:35:00	1.15049	1.15116	8241	-5.521469999999574
be5db939-0037-409e-87be-253e533a493c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	04:35:00	2026-08-04	05:25:00	1.15116	1.1509	8232	-2.1403199999993987
12de90a1-496a-4d8b-b41f-3a00d10b662a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	05:25:00	2026-08-04	06:30:00	1.1509	1.15116	8232	-2.1403199999993987
8ad775a6-814e-4b30-b401-13f81126275a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	06:30:00	2026-08-04	06:45:00	1.15116	1.15084	8228	-2.6329599999989792
12ae5ba6-9abf-424a-a36c-5cd4c9d20104	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	06:45:00	2026-08-04	07:40:00	1.15084	1.1509	8229	-0.4937399999995802
cb93a2ca-8608-4341-8746-59e8f686eabd	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	07:40:00	2026-08-04	08:20:00	1.1509	1.15074	8228	-1.3164799999994896
54904c13-8a71-4a81-a83e-a7cfc8c2e738	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	08:20:00	2026-08-04	08:30:00	1.15074	1.15091	8228	-1.3987600000000286
52320bd6-a4d8-4fad-9f4c-8a8739ca1922	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	08:30:00	2026-08-04	08:35:00	1.15091	1.15079	8226	-0.9871200000009872
420c64a2-6e9c-4aef-be81-3cd6fa7b824c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	08:35:00	2026-08-04	09:20:00	1.15079	1.15064	8225	1.233749999998951
ebfdad36-4ac7-4322-b66c-92cae9737883	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	09:20:00	2026-08-04	09:45:00	1.15064	1.15041	8227	-1.8922100000014357
0570cb9e-2cad-44d0-add8-2f849cc6e873	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	09:45:00	2026-08-04	10:00:00	1.15041	1.15072	8228	-2.550680000000267
c7f4bc04-df09-437b-82dd-dcfdd1556938	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	10:00:00	2026-08-04	11:15:00	1.15072	1.15092	8224	1.6447999999998189
5dac7438-5d9b-450c-b445-75008c370136	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	11:15:00	2026-08-04	12:35:00	1.15092	1.15104	8223	-0.9867600000009868
f9cb3687-a17f-4d2a-ae32-49510c75f4bd	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	12:35:00	2026-08-04	12:55:00	1.15104	1.15065	8221	-3.206190000000925
6854cd4c-9a55-4c64-a116-3f5cc2916704	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	12:55:00	2026-08-04	13:05:00	1.15065	1.15085	8222	-1.644399999999819
1f842c80-1445-4328-a48c-fadcbbba96dc	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	13:05:00	2026-08-04	15:00:00	1.15085	1.15158	8219	5.999870000000982
c100a3b2-8b35-4503-93b0-6afee662cd88	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	15:00:00	2026-08-04	15:45:00	1.15158	1.15214	8219	-4.602639999999128
3853419d-5803-45f7-b2e1-535c2a334f2a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	15:45:00	2026-08-04	15:55:00	1.15214	1.15157	8211	-4.680269999999667
3b21e132-b953-4c8c-bb51-d68b8fc60364	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	15:55:00	2026-08-04	16:40:00	1.15157	1.15247	8211	-7.38990000000101
4b0ce00b-9b82-4b13-aaa7-f4b3367c84d8	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	16:40:00	2026-08-04	17:45:00	1.15247	1.1523	8199	-1.3938300000000285
ff47afba-b909-4168-a3e5-d1bdb36e655c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	17:45:00	2026-08-04	18:55:00	1.1523	1.15245	8199	-1.2298499999989543
ed759d44-97b7-48a8-9785-22a0b4a201da	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	18:55:00	2026-08-04	19:25:00	1.15245	1.15204	8197	-3.360770000000176
34189326-a60e-4a8f-8115-d6ea870824e1	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	19:25:00	2026-08-04	20:10:00	1.15204	1.15206	8197	-0.163940000001074
0d5fec20-6a36-484f-92b9-5a538b3dff81	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-04	20:10:00	2026-08-04	22:45:00	1.15206	1.15308	8196	8.359920000000171
12baf664-49f7-4081-ada3-da2d5532f15d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-04	22:45:00	2026-08-05	01:10:00	1.15308	1.15302	8196	0.49176000000140174
aecd5fa8-89e2-439e-9880-39de213d13c6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	01:10:00	2026-08-05	02:20:00	1.15302	1.15303	8197	0.081970000000537
feea9082-7f1f-4e92-9c84-fe942702213b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	02:20:00	2026-08-05	03:05:00	1.15303	1.15332	8197	-2.377129999999192
9085a3e8-7e4f-495d-bb90-1133a9bfbd04	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	03:05:00	2026-08-05	03:50:00	1.15332	1.15297	8193	-2.867549999998775
b765faad-d40a-4c46-bc8d-bbafef8b13e0	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	03:50:00	2026-08-05	05:15:00	1.15297	1.15294	8193	0.245789999999791
56aafd0a-dcce-4e59-bc89-94128f9976f4	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	05:15:00	2026-08-05	06:40:00	1.15294	1.15359	8194	5.326099999998504
c78bd357-1db5-4c16-abf7-665194b4c07b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	06:40:00	2026-08-05	07:25:00	1.15359	1.15396	8193	-3.0314100000016673
66436568-3375-4e43-85f8-29fbb0c80930	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	07:25:00	2026-08-05	07:30:00	1.15396	1.15389	8188	-0.5731600000001187
c07a30b6-186f-44fb-9600-22a29732876a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	07:30:00	2026-08-05	08:50:00	1.15389	1.15364	8188	2.0470000000006836
accb7050-3219-4595-840c-9ff3a0ab26eb	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	08:50:00	2026-08-05	09:25:00	1.15364	1.15342	8192	-1.802240000000893
0c0bf329-c7e9-49c9-8262-607af16a9957	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	09:25:00	2026-08-05	09:40:00	1.15342	1.15396	8192	-4.423680000001696
0bf9d125-be37-4deb-ad90-837c2c661b8d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	09:40:00	2026-08-05	10:25:00	1.15396	1.15378	8184	-1.4731200000005646
d9b77f06-3b1f-4f4a-85ec-9010d3a5c6ef	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	10:25:00	2026-08-05	11:20:00	1.15378	1.15406	8184	-2.2915200000004745
74c5475a-3371-4f97-897b-03d7ebeea6e2	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	11:20:00	2026-08-05	11:45:00	1.15406	1.15346	8180	-4.908000000001276
e7a11b24-4b1c-4b38-a94f-fc343fdc0a89	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	11:45:00	2026-08-05	12:20:00	1.15346	1.15391	8181	-3.6814500000005026
a42a6607-d876-499b-838a-aeaed376eca7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	12:20:00	2026-08-05	13:15:00	1.15391	1.15361	8174	-2.45219999999973
d6b5f523-0e11-4a64-8908-22a544f4211a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	13:15:00	2026-08-05	14:05:00	1.15361	1.15414	8174	-4.332219999999341
70f0f387-d02b-4187-b695-bd7880900c0c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	14:05:00	2026-08-05	15:35:00	1.15414	1.15499	8167	6.941950000000142
8e828221-f67f-4a22-88bb-c426092682a2	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	15:35:00	2026-08-05	17:15:00	1.15499	1.15527	8167	-2.2867600000004735
f9a73de8-e43e-4cb2-8cff-7997915795d5	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	17:15:00	2026-08-05	17:55:00	1.15527	1.15472	8163	-4.489650000000411
13b109bf-9699-4537-8535-d5f6b05d84c4	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	17:55:00	2026-08-05	18:00:00	1.15472	1.15529	8163	-4.652909999999669
e899c81c-162d-4d6c-a188-37d364df22cb	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	18:00:00	2026-08-05	18:15:00	1.15529	1.1549	8155	-3.1804499999991065
3fab5994-50d9-4896-8088-244826e3cb9e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	18:15:00	2026-08-05	19:30:00	1.1549	1.15476	8155	1.1417000000002364
0058dcd4-586c-4f5e-b000-c42e46fa3638	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	19:30:00	2026-08-05	19:40:00	1.15476	1.15441	8157	-2.854950000000591
79518c58-5285-4364-a675-68b99c0b8cab	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	19:40:00	2026-08-05	20:00:00	1.15441	1.1546	8157	-1.5498300000010972
6ac113d2-7219-4d19-a96d-ce82a63eda36	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	20:00:00	2026-08-05	20:05:00	1.1546	1.15445	8155	-1.2232500000007707
4d05023c-73ae-4015-8268-ee85821757f6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	20:05:00	2026-08-05	20:25:00	1.15445	1.15454	8155	-0.7339499999993759
5e1b82dc-e0da-4fa4-ab20-38f540104c94	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	20:25:00	2026-08-05	21:45:00	1.15454	1.15534	8154	6.523200000001092
b2e71f4a-0b03-4293-8d4d-f2e6ad7606a6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-05	21:45:00	2026-08-05	23:35:00	1.15534	1.15533	8153	0.08153000000053412
48646ebd-af8c-48ae-a782-ba4e8313dd32	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-05	23:35:00	2026-08-06	00:45:00	1.15533	1.15513	8153	-1.6305999999998204
21e15141-c590-493e-a026-9e77b545882f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	00:45:00	2026-08-06	00:50:00	1.15513	1.15523	8154	-0.8153999999999102
e6fb64dd-493c-4b90-a45c-d03055344f7d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	00:50:00	2026-08-06	02:35:00	1.15523	1.15544	8152	1.7119200000003545
08e23f34-5ad0-4cfc-a061-ebe781822999	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	02:35:00	2026-08-06	02:40:00	1.15544	1.15555	8152	-0.8967200000004443
99e86521-3347-43ed-b93e-699a10aebd17	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	02:40:00	2026-08-06	03:10:00	1.15555	1.15549	8151	-0.48906000000139405
fc90bb17-01f4-41ef-886b-5a41d23127f9	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	03:10:00	2026-08-06	03:25:00	1.15549	1.15576	8151	-2.2007699999999386
1d9f23b2-e72a-4d5d-8887-9410ded242f0	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	03:25:00	2026-08-06	03:30:00	1.15576	1.15561	8147	-1.222049999998961
ca2853d2-3d56-4701-af11-ae0370ef3e80	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	03:30:00	2026-08-06	03:35:00	1.15561	1.15573	8147	-0.9776399999991687
b1afd020-a197-4173-aec2-521f91eb77bc	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	03:35:00	2026-08-06	03:45:00	1.15573	1.15562	8146	-0.8960599999986352
208b0bf5-b3eb-4f62-beb8-9d2fec06e542	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	03:45:00	2026-08-06	03:55:00	1.15562	1.15584	8145	-1.7918999999990792
60ce9372-a512-49eb-a09d-715ba3c1db31	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	03:55:00	2026-08-06	04:00:00	1.15584	1.15564	8143	-1.6285999999998206
63c5978a-402d-4a9c-915f-4b1f4faac6d0	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	04:00:00	2026-08-06	05:20:00	1.15564	1.15563	8142	0.0814200000005334
f25ef70e-7ea1-43d4-a879-479b47f9d355	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	05:20:00	2026-08-06	05:35:00	1.15563	1.15553	8143	-0.8142999999999103
2e76d0fb-6ad5-44ad-b4f1-46cd49e9a4e6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	05:35:00	2026-08-06	05:40:00	1.15553	1.15567	8143	-1.140020000000236
25e84c6a-c19f-49fd-bcbe-65ace3b0c33d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	05:40:00	2026-08-06	05:55:00	1.15567	1.15553	8141	-1.139740000000236
33a106c9-1088-40e6-8b18-ce8a75322a66	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	05:55:00	2026-08-06	07:35:00	1.15553	1.15487	8141	5.373059999999047
f4787f66-c035-4565-b861-cc367bc2ecef	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	07:35:00	2026-08-06	08:15:00	1.15487	1.15452	8150	-2.8525000000005907
dc1304e0-8d97-4239-b4e4-b9544cc9234d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	08:15:00	2026-08-06	08:35:00	1.15452	1.15468	8150	-1.3039999999994945
60dae43b-7f3c-4550-9609-baa6d690341f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	08:35:00	2026-08-06	09:35:00	1.15468	1.15447	8148	-1.711079999998545
6f817b5b-effc-426e-aa98-f5be5c8e756e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	09:35:00	2026-08-06	10:35:00	1.15447	1.15444	8148	0.24444000000160138
8b7b7315-5fb7-497f-baba-cf33fe9e4243	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	10:35:00	2026-08-06	10:40:00	1.15444	1.15432	8148	-0.9777599999991686
9f10bbb2-6786-47a0-8b09-9d292778f3e4	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	10:40:00	2026-08-06	10:45:00	1.15432	1.15444	8148	-0.9777599999991686
e1ece638-ddf6-494e-807c-eaaaf47fc796	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	10:45:00	2026-08-06	10:50:00	1.15444	1.15419	8147	-2.036749999998871
9afca346-4242-4360-bfb1-d3ad96577c10	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	10:50:00	2026-08-06	10:55:00	1.15419	1.15439	8147	-1.6293999999998205
f85c5c05-d121-4c57-9747-9644750dddf3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	10:55:00	2026-08-06	11:30:00	1.15439	1.1541	8144	-2.3617600000010057
fb6c6f97-9dc5-4f88-9964-475c3791f278	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	11:30:00	2026-08-06	11:45:00	1.1541	1.15431	8144	-1.7102400000003541
d15354dc-623e-49a8-a6e9-0696131d95b8	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	11:45:00	2026-08-06	11:50:00	1.15431	1.1541	8141	-1.709610000000354
c7bf3b37-0bcb-4252-bc84-8f7df3ce3bed	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	11:50:00	2026-08-06	11:55:00	1.1541	1.15423	8141	-1.0583300000015103
0d68fd67-8f67-410a-a3e2-50d297e0685b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	11:55:00	2026-08-06	12:40:00	1.15423	1.15395	8139	-2.278920000000472
c1137720-8913-4a8b-abe6-71e52631be9c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	12:40:00	2026-08-06	13:30:00	1.15395	1.1541	8140	-1.2209999999989618
3f61ddd9-b311-48a7-aad6-deb6c1a55cd1	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	13:30:00	2026-08-06	14:45:00	1.1541	1.15384	8138	-2.1158799999994056
5e0d078f-fc66-4fa7-8b36-8fb17ea0f784	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	14:45:00	2026-08-06	15:00:00	1.15384	1.15449	8138	-5.289700000000321
157d3231-27dc-4af6-bf07-abb44742224d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	15:00:00	2026-08-06	15:15:00	1.15449	1.15397	8129	-4.227080000000617
ca562d5f-b385-4779-b8a8-3228a6cc7b71	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	15:15:00	2026-08-06	15:35:00	1.15397	1.15442	8129	-3.6580500000004994
332c0674-47a8-4f87-9372-35af2fa34681	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	15:35:00	2026-08-06	15:45:00	1.15442	1.15418	8122	-1.949280000000146
9cc3032a-41a7-4e82-865a-13e35e81d17a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	15:45:00	2026-08-06	16:40:00	1.15418	1.15412	8123	0.4873799999995856
81cb6c3c-56ad-4fb4-b32f-7c88fc57e8c7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	16:40:00	2026-08-06	17:10:00	1.15412	1.15342	8123	-5.686100000001177
c74e4aa7-098b-4823-b5c0-139490dc9b07	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	17:10:00	2026-08-06	19:35:00	1.15342	1.15189	8124	12.42971999999845
befcbfe7-7b01-41d8-8601-ae41c8570346	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	19:35:00	2026-08-06	22:25:00	1.15189	1.15202	8145	1.0588499999997025
309a3be4-5231-483c-b864-16fca917eb54	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	22:25:00	2026-08-06	23:00:00	1.15202	1.15227	8145	-2.0362499999988715
fa73a1d3-74f5-4953-b1e9-85b96a0f924a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	23:00:00	2026-08-06	23:20:00	1.15227	1.15203	8141	-1.9538399999983387
06790bba-e5ca-43e7-9734-aa052dfe19fe	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-06	23:20:00	2026-08-06	23:45:00	1.15203	1.15219	8141	-1.302559999999495
80e1f6f0-e211-47de-910e-d17924682f24	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-06	23:45:00	2026-08-07	00:25:00	1.15219	1.15208	8139	-0.8952900000004436
513c9cea-91fc-4df0-9a28-c1dcaac1cedf	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	00:25:00	2026-08-07	01:10:00	1.15208	1.1521	8139	-0.16277999999925918
13666c0f-24c7-4a1a-a8b2-0bdeea668119	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	01:10:00	2026-08-07	03:10:00	1.1521	1.15222	8139	0.9766800000009768
26cf619f-fd1c-4c71-a9b9-401fcdbcdc80	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	03:10:00	2026-08-07	04:25:00	1.15222	1.15213	8139	0.7325099999993772
42faba26-b09c-41db-a67d-421bbe3d151c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	04:25:00	2026-08-07	05:20:00	1.15213	1.15206	8140	-0.569800000000118
55b05e55-7fd5-42cf-8b52-b932d25505b9	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	05:20:00	2026-08-07	05:25:00	1.15206	1.15225	8140	-1.5465999999992874
4a07530a-0388-4333-8876-ce2e17ce2b16	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	05:25:00	2026-08-07	05:45:00	1.15225	1.15207	8137	-1.4646600000005614
9463b902-394e-44dc-adf3-09a0ceb5e22b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	05:45:00	2026-08-07	05:50:00	1.15207	1.15231	8138	-1.9531200000001463
87c443a6-c303-4639-8d40-22cd1be11d62	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	05:50:00	2026-08-07	06:00:00	1.15231	1.15214	8134	-1.3827800000000283
1ed37c42-83ff-4882-802e-9788b1c7b9ef	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	06:00:00	2026-08-07	06:40:00	1.15214	1.15215	8134	-0.08134000000053287
0c49201e-afb3-4642-94f2-5f6ab6d3c5a7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	06:40:00	2026-08-07	08:25:00	1.15215	1.15224	8134	0.7320599999993775
c1add881-da76-4c6b-86f8-af13ab122072	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	08:25:00	2026-08-07	09:25:00	1.15224	1.15244	8134	-1.6267999999998208
9de498dd-0383-41e3-b7bf-7278ca9c6331	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	09:25:00	2026-08-07	09:35:00	1.15244	1.15225	8131	-1.5448899999992882
711bb0bb-9b02-4dfb-bc93-d3ea73d3baa0	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	09:35:00	2026-08-07	11:00:00	1.15225	1.15222	8132	0.24395999999979257
1e1a4ed2-6987-4c5a-abf4-7753767d369c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	11:00:00	2026-08-07	11:10:00	1.15222	1.15205	8132	-1.3824400000000283
23c35193-48d5-432d-b6bd-f1b3a645fb7b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	11:10:00	2026-08-07	11:40:00	1.15205	1.15219	8132	-1.1384800000002357
5098b0c3-b819-4809-b057-c8b40940ce48	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	11:40:00	2026-08-07	13:15:00	1.15219	1.15262	8130	3.4958999999994345
fd2550e4-17c8-400f-b9f5-75b8b6c483b1	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	13:15:00	2026-08-07	14:45:00	1.15262	1.15316	8130	-4.3901999999998775
54c34303-bf83-47c9-95cd-1e4d4e692fd6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	14:45:00	2026-08-07	15:30:00	1.15316	1.15279	8122	-3.0051399999998494
104dddc5-0bfb-4a18-a1fc-7e8a4355a482	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	15:30:00	2026-08-07	15:35:00	1.15279	1.15721	8123	-35.903660000000734
e065a7eb-2150-448f-a419-430dc1c43b32	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	15:35:00	2026-08-07	16:35:00	1.15721	1.15635	8062	-6.933320000000668
423a8557-72bd-4870-a89b-0c5593a2c7aa	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	16:35:00	2026-08-07	18:45:00	1.15635	1.15612	8062	1.8542599999996168
b01d4a03-dc05-4ec8-9bbc-a57c18fa1395	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	18:45:00	2026-08-07	20:00:00	1.15612	1.15589	8066	-1.8551799999996166
bbdb9fb8-041b-4ac8-9d71-d08e301c002a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	20:00:00	2026-08-07	20:55:00	1.15589	1.15625	8066	-2.903759999999322
fce219cc-b480-4695-977f-1a7361d5d01d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	20:55:00	2026-08-07	21:00:00	1.15625	1.15611	8061	-1.1285400000002337
cd314b66-7658-4278-a244-4c3e88042e1a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	21:00:00	2026-08-07	21:35:00	1.15611	1.15633	8061	-1.7734200000008786
21da980f-3158-47cc-8b46-1afb04f51125	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-07	21:35:00	2026-08-07	22:50:00	1.15633	1.15655	8058	1.772759999999089
c352992a-8c0c-47a4-8f51-674c02ebfb36	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-07	22:50:00	2026-08-10	00:10:00	1.15655	1.1563	8058	2.0144999999988835
13a2e634-8fac-4e23-bc95-40be7087ee36	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	00:10:00	2026-08-10	01:05:00	1.1563	1.15571	8061	-4.755990000000729
0e814db1-c59f-43f5-aecf-7cc19e1a2e55	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	01:05:00	2026-08-10	02:05:00	1.15571	1.15569	8061	0.16121999999926628
5729d380-760f-434a-942b-682864be5537	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	02:05:00	2026-08-10	03:35:00	1.15569	1.15555	8061	-1.1285400000002337
a7803447-0dae-42b0-88ce-7db9c4acc866	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	03:35:00	2026-08-10	03:55:00	1.15555	1.15577	8062	-1.7736399999990886
a5f39315-051c-4e29-9f73-8c2ca76dc794	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	03:55:00	2026-08-10	04:10:00	1.15577	1.15533	8059	-3.545959999999967
d34dc0d0-2aa8-475b-b7cd-1ab2edc628ed	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	04:10:00	2026-08-10	05:20:00	1.15533	1.15541	8059	-0.6447200000006448
bb53f525-5926-48c7-bc4e-e22e233cbcaf	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	05:20:00	2026-08-10	05:45:00	1.15541	1.1552	8057	-1.6919700000003504
073b6702-e956-4b94-ba96-b04a4140c540	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	05:45:00	2026-08-10	07:25:00	1.1552	1.15494	8058	2.0950799999994114
5399a818-363c-4de2-bb26-1707c3aef00f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	07:25:00	2026-08-10	09:55:00	1.15494	1.15529	8061	2.8213499999987945
515e520c-8c35-4e50-bdc6-9c80581cb52a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	09:55:00	2026-08-10	10:25:00	1.15529	1.15567	8061	-3.0631800000003784
64d830ac-01fc-4e96-94cf-6ed11d100b56	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	10:25:00	2026-08-10	11:45:00	1.15567	1.15623	8056	4.511360000000934
fbef03b6-8638-499b-84d2-ab69392889e2	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	11:45:00	2026-08-10	15:05:00	1.15623	1.15517	8056	8.53936000000049
0be956c2-9f95-493b-ba31-7ca0ca88c92d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	15:05:00	2026-08-10	15:30:00	1.15517	1.15485	8070	-2.5824000000007907
dc96f184-eb55-43d8-8d1c-e18d776c3195	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	15:30:00	2026-08-10	16:10:00	1.15485	1.15486	8070	-0.08070000000052868
f8530a42-3682-4f8c-92d5-bf904799938a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	16:10:00	2026-08-10	16:55:00	1.15486	1.15445	8070	-3.308700000000173
ee7629c3-afa6-4cc9-aec6-ac44806ae38c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	16:55:00	2026-08-10	17:15:00	1.15445	1.15486	8070	-3.308700000000173
f186aaf6-af31-4d87-bed2-1980cba160f9	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	17:15:00	2026-08-10	18:10:00	1.15486	1.15481	8065	-0.403250000000851
e0d6c0ca-ed0a-4668-9bfe-8f27f8b86557	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	18:10:00	2026-08-10	18:20:00	1.15481	1.15518	8065	-2.9840500000016412
b7a00f91-bba6-4777-a933-e1c934885dd6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	18:20:00	2026-08-10	18:30:00	1.15518	1.15486	8060	-2.5792000000007897
392c7527-5a2a-4d0d-bb13-fbc2b95a805a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	18:30:00	2026-08-10	19:05:00	1.15486	1.15524	8060	-3.0628000000003786
55e0c26a-de8f-42a4-b6b4-ee70bb55ed6c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	19:05:00	2026-08-10	19:45:00	1.15524	1.15467	8055	-4.591349999999673
8c5b3971-ee79-48b6-b941-ce654544e33f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	19:45:00	2026-08-10	21:15:00	1.15467	1.15434	8055	2.658150000001317
ef1eef48-e8c9-47e7-9205-adad3cc92cb8	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	21:15:00	2026-08-10	21:20:00	1.15434	1.15421	8059	-1.0476699999997057
85df1ceb-3e09-4fca-8050-2065d66dfae7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	21:20:00	2026-08-10	21:25:00	1.15421	1.15426	8059	-0.40295000000085035
a9baa20a-640a-43fa-910f-f308442ef588	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	21:25:00	2026-08-10	21:30:00	1.15426	1.15419	8059	-0.5641300000001168
f82846ac-9d20-4771-8a52-b6db07221f47	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	21:30:00	2026-08-10	21:35:00	1.15419	1.15432	8059	-1.0476699999997057
f996e9f7-ace5-4e62-bc0d-5a4e8a06a524	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	21:35:00	2026-08-10	22:05:00	1.15432	1.15406	8057	-2.0948199999994115
d02cdb09-78ae-49b3-8440-b4493cbd6eef	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-10	22:05:00	2026-08-10	22:20:00	1.15406	1.15414	8057	-0.6445599999988556
39faacef-26ef-48f4-8e34-e5332b1ceb8e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-10	22:20:00	2026-08-11	00:25:00	1.15414	1.15412	8056	-0.16111999999926674
b84f3c97-3734-48d5-807b-69a35d72a39c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	00:25:00	2026-08-11	00:30:00	1.15412	1.15425	8056	-1.0472799999997058
285158f3-7847-4c91-bc13-17f9f9c892bd	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	00:30:00	2026-08-11	00:45:00	1.15425	1.1541	8054	-1.2081000000007611
ef44c679-4c11-4385-aac4-c8bc39c15daf	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	00:45:00	2026-08-11	00:55:00	1.1541	1.15424	8054	-1.1275600000002335
8b6c155c-11f3-495e-ad3b-627bb14c5b28	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	00:55:00	2026-08-11	02:20:00	1.15424	1.1543	8053	0.4831800000013773
0c9a6770-3607-4377-a5d7-4d27d6751827	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	02:20:00	2026-08-11	02:50:00	1.1543	1.15441	8052	-0.8857199999986509
3d492882-2b09-40b4-9478-c1624620aaba	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	02:50:00	2026-08-11	04:00:00	1.15441	1.15456	8051	1.2076500000007608
3c5f3727-494a-4e75-8b34-9954333c5b7d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	04:00:00	2026-08-11	04:35:00	1.15456	1.15494	8051	-3.0593800000003784
7a384f4f-8b57-4d6e-af38-77806af99036	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	04:35:00	2026-08-11	04:45:00	1.15494	1.15462	8046	-2.5747200000007884
513b0f6c-a89f-4dcd-b99f-b902e856c78f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	04:45:00	2026-08-11	06:20:00	1.15462	1.15424	8046	3.057480000000378
bbe51ece-4da4-4ca9-8aaa-737d5c83c3c6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	06:20:00	2026-08-11	07:45:00	1.15424	1.15409	8051	-1.2076499999989732
25bdf0b5-84fe-4ac3-b697-648e6eb9e134	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	07:45:00	2026-08-11	08:40:00	1.15409	1.1542	8051	-0.8856099999986511
c6f5ce40-8757-4186-be51-e786c0a0d76f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	08:40:00	2026-08-11	08:55:00	1.1542	1.15391	8050	-2.3344999999992067
79d181d0-77ca-4bf3-b6b4-48a4eeec24a3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	08:55:00	2026-08-11	09:05:00	1.15391	1.15417	8050	-2.092999999999412
81bcd60f-cb4d-45c3-928d-d1260dd15cf7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	09:05:00	2026-08-11	09:15:00	1.15417	1.154	8046	-1.367820000000028
61eeaabb-1e7a-4740-b3c5-f910b2947ad4	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	09:15:00	2026-08-11	10:10:00	1.154	1.15383	8046	1.367820000000028
302e7ff0-7c82-409a-a49e-86dbc9a3d06e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	10:10:00	2026-08-11	10:40:00	1.15383	1.1534	8048	-3.46063999999944
7f5dbe58-5916-454d-ba48-e63d1dbeb7e0	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	10:40:00	2026-08-11	11:30:00	1.1534	1.15339	8049	0.0804900000005273
254d1f2c-f62c-4b55-9a06-225bc732cc50	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	11:30:00	2026-08-11	12:30:00	1.15339	1.15335	8048	-0.32191999999853493
56f86b9f-68f9-4153-ba04-24c63134e14f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	12:30:00	2026-08-11	12:50:00	1.15335	1.15359	8049	-1.9317599999983575
f7c48dca-ec08-47e2-af64-9c9eb23220af	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	12:50:00	2026-08-11	14:45:00	1.1535899999999997	1.15362	8045	0.24135000000336748
9908614d-efc9-429c-bf28-04811659af33	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	14:45:00	2026-08-11	15:40:00	1.15362	1.1539	8045	-2.2525999999986803
b5633d66-e5a7-41cb-9f64-862c9432b187	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	15:40:00	2026-08-11	17:05:00	1.1539	1.15415	8042	2.0105000000006714
d62312be-25f6-4457-81fa-b3f93c6fa5b8	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	17:05:00	2026-08-11	19:00:00	1.15415	1.1543	8042	-1.20630000000076
7cb402dd-f826-407a-b81c-4a5b5eeffb6a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	19:00:00	2026-08-11	20:00:00	1.1543	1.15396	8040	-2.733600000000056
68c7fdd0-be56-4b96-96b0-e770d3b01294	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	20:00:00	2026-08-11	20:55:00	1.15396	1.15381	8040	1.2060000000007598
fdc2eb79-61a6-4c0e-8cdc-03fe9ea9f471	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-11	20:55:00	2026-08-11	23:20:00	1.15381	1.15418	8042	2.975539999999851
8ab7cd2a-6beb-400e-8134-913e179f6f6d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-11	23:20:00	2026-08-12	01:05:00	1.15418	1.15427	8042	-0.7237799999993846
d12bf739-c37b-4973-b2b1-a9f0e5d8db95	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	01:05:00	2026-08-12	02:30:00	1.15427	1.15417	8040	-0.8039999999999115
4d9ac793-0a2e-4797-a214-0b0287451609	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	02:30:00	2026-08-12	03:00:00	1.15417	1.15434	8040	-1.366800000000028
63edd46e-0f59-4137-8047-4a60fc211cdb	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	03:00:00	2026-08-12	03:40:00	1.15434	1.15432	8038	-0.16075999999926838
9901f0b9-efe4-4d9c-ae8d-d3b18e9239d6	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	03:40:00	2026-08-12	05:35:00	1.15432	1.1538	8038	4.179760000000611
f2d923ae-8ce1-45c0-8274-776d3f214709	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	05:35:00	2026-08-12	06:40:00	1.1538	1.15366	8045	-1.1263000000002332
6b5aa35e-a61c-4099-88d1-d49adcb97595	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	06:40:00	2026-08-12	07:45:00	1.15366	1.15355	8045	0.8849499999986521
d4776624-8243-43a7-9c73-93d08758cb2b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	07:45:00	2026-08-12	08:20:00	1.15355	1.15331	8047	-1.9312800000001447
b45c4aef-9f06-4265-ab69-d4cdd153888e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	08:20:00	2026-08-12	08:40:00	1.15331	1.15346	8047	-1.2070499999989737
66e3e160-9d7b-4dfc-96ff-c49006375623	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	08:40:00	2026-08-12	11:05:00	1.15346	1.15347	8045	0.08045000000052704
b547049b-634a-4f91-9bdf-09997a114d2f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	11:05:00	2026-08-12	11:45:00	1.15347	1.15397	8045	-4.022499999999557
02bb2e06-05a8-4ad9-99eb-dd46070bddc3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	11:45:00	2026-08-12	12:00:00	1.15397	1.15372	8038	-2.0094999999988863
6e99823a-8bc5-4521-bea6-5f3d1dfd9828	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	12:00:00	2026-08-12	12:05:00	1.15372	1.15387	8038	-1.2056999999989748
b6a47d91-9022-4e0d-9660-913d927d5dbf	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	12:05:00	2026-08-12	12:10:00	1.15387	1.15377	8036	-0.8035999999999115
ac2c1374-391e-4c74-bd49-aef8dee9882d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	12:10:00	2026-08-12	12:15:00	1.15377	1.15408	8036	-2.491160000000261
d9639213-8005-4d06-aabb-826f35ce600f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	12:15:00	2026-08-12	12:50:00	1.15408	1.15373	8032	-2.811200000000582
8ac451b4-6843-45df-9f6e-54931af9292d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	12:50:00	2026-08-12	14:25:00	1.15373	1.15371	8032	0.16063999999926892
9c8ab968-c424-4850-9a74-bb5cd7fbde57	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	14:25:00	2026-08-12	16:25:00	1.15371	1.15521	8032	12.048000000000457
6e4d3deb-2713-44b4-b8b9-40ac422b851a	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	16:25:00	2026-08-12	20:15:00	1.15521	1.15277	8032	19.59807999999998
3103403a-be65-4041-bfa4-4b5f195f6353	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	20:15:00	2026-08-12	21:00:00	1.15277	1.15212	8065	-5.242250000000318
c842271c-d8ec-46d6-ac31-eb18252e822e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-12	21:00:00	2026-08-12	21:15:00	1.15212	1.15244	8065	-2.5807999999989994
4fe3bede-cb70-476a-b111-6d3bc4a86c92	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-12	21:15:00	2026-08-13	00:25:00	1.15244	1.15218	8061	-2.095859999999411
0153ef19-498e-43f3-97a2-2cc5aed39bc3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	00:25:00	2026-08-13	01:00:00	1.15218	1.15224	8061	-0.48365999999958875
4ee55996-001b-4174-a69c-a17bf96c97fa	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	01:00:00	2026-08-13	02:45:00	1.15224	1.15267	8060	3.465800000001229
435ec7cd-3145-4a79-a330-56117f1f10df	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	02:45:00	2026-08-13	03:00:00	1.15267	1.15278	8060	-0.8865999999986496
3be6163d-8c2b-413d-99cc-9cc4a5cb0580	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	03:00:00	2026-08-13	03:50:00	1.15278	1.15281	8059	0.24176999999979443
bf3b3be7-f67e-42c8-ab13-c9c947bd42f7	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	03:50:00	2026-08-13	06:15:00	1.15281	1.15219	8058	4.995959999998734
b544062a-b5d9-488e-83c9-b136bd64f508	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	06:15:00	2026-08-13	08:55:00	1.15219	1.15244	8066	2.0164999999988824
af66832c-0562-48aa-a8c5-6b8f54566a4c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	08:55:00	2026-08-13	10:20:00	1.15244	1.15186	8067	4.67885999999841
6629a039-fe51-4f1d-afcc-a63839245a41	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	10:20:00	2026-08-13	12:05:00	1.15186	1.15233	8074	3.7947799999997613
e8603ed6-2c34-445f-88bd-2d408ff1981b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	12:05:00	2026-08-13	12:15:00	1.15233	1.15278	8074	-3.6332999999987035
ec9f17aa-42f4-4ee5-9794-06d0350e1aa1	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	12:15:00	2026-08-13	13:55:00	1.15278	1.15356	8068	6.2930400000000235
3f1dfbed-590e-4897-9963-4157d5add7fc	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	13:55:00	2026-08-13	15:55:00	1.15356	1.15358	8068	-0.1613600000010571
0cbbf6bc-30e7-44be-9907-1eba28fda858	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	15:55:00	2026-08-13	16:35:00	1.15358	1.15331	8068	-2.1783599999999392
ffd37187-4dc1-4194-aaa3-5ceb5ab28dc3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	16:35:00	2026-08-13	17:15:00	1.15331	1.15409	8068	-6.2930400000000235
0f45813a-66ae-49fd-9907-2888b5b215f3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	17:15:00	2026-08-13	18:15:00	1.15409	1.15378	8057	-2.4976700000002614
dda081ba-2a22-4efd-a191-11630af7fa6e	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	18:15:00	2026-08-13	19:55:00	1.15378	1.153	8057	6.284460000000023
acec7f27-1c8f-48f2-8433-de8fb46b11d5	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	19:55:00	2026-08-13	22:50:00	1.153	1.15281	8068	-1.5329200000010852
a1df439b-8aee-4388-8770-f3869d279965	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-13	22:50:00	2026-08-13	23:55:00	1.15281	1.15293	8068	-0.9681600000009682
c7224010-2649-4187-9a03-c6919db1f715	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-13	23:55:00	2026-08-14	00:15:00	1.15293	1.15259	8067	-2.742780000000056
01a6d9bd-f8dc-4361-b692-e80b42351341	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	00:15:00	2026-08-14	00:45:00	1.15259	1.15281	8066	-1.7745199999990882
1189765a-29d5-4d35-965e-289c2b6ab6ed	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	00:45:00	2026-08-14	04:10:00	1.15281	1.15349	8064	5.483520000000112
995c90e9-c745-45d4-b69b-5a1c44b9842f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	04:10:00	2026-08-14	05:40:00	1.15349	1.15368	8063	-1.5319700000010845
5153b5aa-9f9c-4e20-b584-7a16d9b039de	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	05:40:00	2026-08-14	05:50:00	1.15368	1.15357	8061	-0.8867100000004393
cf20740f-c293-42bb-be5f-2b0be79c0975	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	05:50:00	2026-08-14	06:25:00	1.15357	1.15371	8061	-1.1285400000002337
4549d105-dabd-4dc5-a238-159e7720f88c	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	06:25:00	2026-08-14	07:50:00	1.15371	1.15378	8059	0.5641300000001168
56ac8837-7292-414f-a8ae-be1e978cb69b	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	07:50:00	2026-08-14	07:55:00	1.15378	1.15392	8059	-1.1282600000002336
823fc6b3-e4fe-4b2a-99c1-6b7f75c74665	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	07:55:00	2026-08-14	08:00:00	1.15392	1.15385	8057	-0.5639900000001168
216d08dc-91d7-480f-8501-a49610ccfb8f	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	08:00:00	2026-08-14	08:10:00	1.15385	1.1539	8057	-0.4028499999990611
90f7317a-4e55-4bea-85f0-3468dd7f066d	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	08:10:00	2026-08-14	09:20:00	1.1539	1.15405	8056	1.2084000000007613
dde6e2a3-a534-439e-bffa-07007802f5fa	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	09:20:00	2026-08-14	09:50:00	1.15405	1.15427	8056	-1.7723199999990893
0c9427bc-41fd-47a4-93b6-9061a99fffce	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	09:50:00	2026-08-14	11:55:00	1.15427	1.1554	8053	9.099890000000608
73b6d701-ea28-4686-86bd-3b3282f979e5	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	11:55:00	2026-08-14	12:00:00	1.1554	1.15551	8053	-0.8858300000004389
965d67bd-e3ad-4fd2-8732-60dc606103fa	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	12:00:00	2026-08-14	12:05:00	1.15551	1.15545	8051	-0.48305999999958926
5cbd254d-c603-4b12-bcd7-6fd23f563223	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	12:05:00	2026-08-14	14:05:00	1.15545	1.15569	8051	-1.9322400000001447
759825b1-5552-4746-a467-23b1707775b3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	14:05:00	2026-08-14	15:15:00	1.15569	1.15639	8048	5.6335999999993795
1a865268-11c2-47e8-b11b-96b1307d79e0	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	15:15:00	2026-08-14	15:25:00	1.15639	1.15695	8048	-4.506879999999146
c367532b-05d3-485a-9c75-a01ca61cbccd	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	15:25:00	2026-08-14	15:45:00	1.15695	1.15658	8040	-2.974799999999851
cb8fc7c7-0a40-4ae9-8ccd-b06bd0588ffa	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	15:45:00	2026-08-14	16:40:00	1.15658	1.15815	8040	-12.622800000000574
9fa7ec95-436d-4928-8603-48afb5756e57	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	long	2026-08-14	16:40:00	2026-08-14	17:50:00	1.15815	1.15786	8019	-2.3255100000009903
f6d0ee5c-67b6-4510-a562-87b21c0426e3	ed4edd20-bc65-40b5-93c3-41d33851ef84	EURUSD	short	2026-08-14	17:50:00	2026-08-14	21:10:00	1.15786	1.15656	8019	10.424699999998852
\.


--
-- Data for Name: chart_symbol_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_symbol_overrides (id, account_id, symbol, twelve_data_symbol, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dropdown_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dropdown_settings (id, account_id, category, value, sort_order, created_at) FROM stdin;
d180500c-3928-4e6d-8ed4-d45c0544790d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	asset_class	Forex	1	2026-08-11 10:58:03.257114+00
a67773e4-872f-4200-9a3b-cbc56108c94e	00000000-0000-0000-0000-000000000001	session	London	1	2026-07-21 09:46:15.442403+00
1450b3b8-3461-42ee-98ce-ae4ca6e1f8c0	00000000-0000-0000-0000-000000000001	session	New York	2	2026-07-21 09:46:15.442403+00
adef61dc-69db-4a84-a9ab-9b7df0f3c9e1	00000000-0000-0000-0000-000000000001	session	Asia	3	2026-07-21 09:46:15.442403+00
43dbb37a-a1fc-4bd6-83ab-4681a0b8c4dd	00000000-0000-0000-0000-000000000001	emotion	Calm	1	2026-07-21 09:46:15.442403+00
c03b3710-016b-49e4-b320-8df9f8e57847	00000000-0000-0000-0000-000000000001	emotion	Confident	2	2026-07-21 09:46:15.442403+00
baad954f-741a-4914-8729-9b5a5be4ec75	00000000-0000-0000-0000-000000000001	emotion	Anxious	3	2026-07-21 09:46:15.442403+00
ff51bf6e-c038-4eb5-a435-2a8e178f9951	00000000-0000-0000-0000-000000000001	emotion	Impatient	4	2026-07-21 09:46:15.442403+00
681f7159-f15b-41ff-a431-f30dc07d7e1a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	asset_class	Indices	2	2026-08-11 10:58:03.257114+00
3a64ade5-4801-4a51-a38a-54cb23cd7f46	00000000-0000-0000-0000-000000000001	strategy	Test strat	5	2026-07-21 15:24:05.545073+00
3236341d-e3de-4170-b729-04d356208c22	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	asset_class	Crypto	3	2026-08-11 10:58:03.257114+00
0490637d-aed4-4d5a-a497-d4c22fbafc5d	00000000-0000-0000-0000-000000000001	strategy	Trend following	4	2026-07-21 09:46:15.442403+00
29fc6acf-dc48-4790-8add-ac0fbbd75343	00000000-0000-0000-0000-000000000001	strategy	Breakout	2	2026-07-23 18:46:21.131929+00
89e9eb0f-0d0e-4b51-8042-33530c9ffaac	00000000-0000-0000-0000-000000000001	strategy	Mean reversion	3	2026-07-21 09:46:15.442403+00
c4820b79-d1f4-4eea-991b-512d5031c292	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	strategy	Breakout	1	2026-08-11 10:58:03.257114+00
dab239cd-c503-4f66-ac05-564e2eeff8a0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	strategy	Mean reversion	2	2026-08-11 10:58:03.257114+00
0bf410e9-5c5d-4d21-b0dd-e724e68ae789	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	strategy	Trend following	3	2026-08-11 10:58:03.257114+00
1eba9c18-6246-4188-92ca-3b2d1b4ef86b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	session	London	1	2026-08-11 10:58:03.257114+00
3f411feb-53dd-4932-abff-d2addee7de72	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	session	New York	2	2026-08-11 10:58:03.257114+00
ef5f4868-ed64-4696-a9fb-ce4415124704	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	session	Asia	3	2026-08-11 10:58:03.257114+00
510cb5a3-5e46-46de-b8e5-6886a746660c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Calm	1	2026-08-11 10:58:03.257114+00
5f4dadc1-e0ad-4e86-affb-ba35e8eca962	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Confident	2	2026-08-11 10:58:03.257114+00
475ee832-949f-409f-8178-2e2259c59140	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Anxious	3	2026-08-11 10:58:03.257114+00
d1d57019-0102-429e-a5e7-d349c6c932d6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	emotion	Impatient	4	2026-08-11 10:58:03.257114+00
85d31734-0a8a-4518-bb6f-fe10f6b906a1	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	asset_class	Forex	1	2026-09-10 09:15:08.873196+00
47afe1cd-0d4d-46ee-b29e-349ad751ea8e	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	asset_class	Indices	2	2026-09-10 09:15:08.873196+00
db5e2f52-41c9-4ade-9ec6-ed29614fc0e0	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	asset_class	Crypto	3	2026-09-10 09:15:08.873196+00
25a0ece7-9806-4d79-ae50-4edd5e56187f	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	strategy	Breakout	1	2026-09-10 09:15:08.873196+00
a65337ef-9dfc-4a51-886e-a796e4d21edf	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	strategy	Mean reversion	2	2026-09-10 09:15:08.873196+00
d16ca1a7-d1d6-4dcd-9bf9-d1242dffa368	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	strategy	Trend following	3	2026-09-10 09:15:08.873196+00
fd563153-af87-4e24-8bb4-f32ac1f698a0	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	session	London	1	2026-09-10 09:15:08.873196+00
72612add-7832-400c-9ce2-6bf6bc9ed47c	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	session	New York	2	2026-09-10 09:15:08.873196+00
42656d43-3cc1-45d1-bfeb-743a1c1100a9	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	session	Asia	3	2026-09-10 09:15:08.873196+00
1e38ee13-1e22-418d-86c0-7e06693067e8	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	emotion	Calm	1	2026-09-10 09:15:08.873196+00
ec2172cc-fe37-4604-ac2c-d67d7f0cbb96	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	emotion	Confident	2	2026-09-10 09:15:08.873196+00
0d3b66b9-72f5-403e-8ae2-0820bc9b69a8	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	emotion	Anxious	3	2026-09-10 09:15:08.873196+00
82712627-4d45-4206-99bd-9b161d24b1e3	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	emotion	Impatient	4	2026-09-10 09:15:08.873196+00
6e0d97ff-30ed-4265-945b-de02d7f8df99	00000000-0000-0000-0000-000000000001	asset_class	Crypto	3	2026-07-21 09:46:15.442403+00
28495160-5766-4885-a033-69ff8a83379c	00000000-0000-0000-0000-000000000001	asset_class	Indices	2	2026-07-21 09:46:15.442403+00
618b758b-577f-4d94-80f5-0589982e7e46	00000000-0000-0000-0000-000000000001	asset_class	Forex	1	2026-07-21 09:46:15.442403+00
9b1303c3-349e-41a2-922e-fb9577b9c748	40f6a8ae-bc42-4397-8988-577d9373e75c	asset_class	Forex	1	2026-08-14 10:17:24.465091+00
e6c3e775-837e-4ae2-8e6a-fc52e5db2d91	40f6a8ae-bc42-4397-8988-577d9373e75c	asset_class	Indices	2	2026-08-14 10:17:24.465091+00
97b676ff-e39e-4c4c-af4e-9cd4dd076f98	40f6a8ae-bc42-4397-8988-577d9373e75c	asset_class	Crypto	3	2026-08-14 10:17:24.465091+00
40c2e680-6d42-47ce-bb6f-3dd49c2c35ee	40f6a8ae-bc42-4397-8988-577d9373e75c	strategy	Breakout	1	2026-08-14 10:17:24.465091+00
f86124f2-c469-4c6b-adba-0544c93bbed1	40f6a8ae-bc42-4397-8988-577d9373e75c	strategy	Mean reversion	2	2026-08-14 10:17:24.465091+00
a41587fd-8a59-4438-a248-06d71a9c706c	40f6a8ae-bc42-4397-8988-577d9373e75c	strategy	Trend following	3	2026-08-14 10:17:24.465091+00
d7ec426d-de2d-43bb-872e-dc98abcbe7b2	40f6a8ae-bc42-4397-8988-577d9373e75c	session	London	1	2026-08-14 10:17:24.465091+00
51eb8327-586c-4fc6-bb8d-b29e8d49a74f	40f6a8ae-bc42-4397-8988-577d9373e75c	session	New York	2	2026-08-14 10:17:24.465091+00
aac1b5b6-b6cd-476c-819b-ed505022ecca	40f6a8ae-bc42-4397-8988-577d9373e75c	session	Asia	3	2026-08-14 10:17:24.465091+00
43a73411-797b-4e71-af10-e69f15beaa4f	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Calm	1	2026-08-14 10:17:24.465091+00
793e4089-eac2-4301-b087-ebb9f43920b2	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Confident	2	2026-08-14 10:17:24.465091+00
e5883048-1b05-4cc2-8cc0-45dd15707875	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Anxious	3	2026-08-14 10:17:24.465091+00
f99de760-369c-4593-bc2a-f8ed6ef55e07	40f6a8ae-bc42-4397-8988-577d9373e75c	emotion	Impatient	4	2026-08-14 10:17:24.465091+00
\.


--
-- Data for Name: exness_contract_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exness_contract_overrides (id, account_id, symbol, contract_size, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, account_id, title, content, created_at, updated_at, tags, linked_trade_ids, linked_strategy) FROM stdin;
6db23ba6-a28a-4a7d-8ee7-f959399dff94	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	Aug 12, 2026 — 10:50 AM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Extended Standard Paragraph", "type": "text"}]}, {"type": "paragraph"}, {"type": "paragraph", "content": [{"text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", "type": "text"}]}]}	2026-08-12 07:50:55.072619+00	2026-08-12 07:54:41.002+00	{}	{}	\N
14fe8a76-e475-426d-99c5-ece1d2bef65d	00000000-0000-0000-0000-000000000001	Aug 12, 2026 — 10:50 AM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Extended Standard Paragraph", "type": "text"}]}, {"type": "paragraph"}, {"type": "paragraph", "content": [{"text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.", "type": "text"}]}]}	2026-08-12 07:50:55.072619+00	2026-08-12 07:54:41.002+00	{}	{}	\N
3e5d4f6b-f2bd-4ef2-8084-e97f3b1880df	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	Aug 12, 2026 — 10:50 AM	{"type": "doc", "content": [{"type": "paragraph", "content": [{"text": "Test it.", "type": "text"}]}, {"type": "paragraph"}, {"type": "paragraph", "content": [{"text": "hint: Updates were rejected because the remote contains work that you do not", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: have locally. This is usually caused by another repository pushing to", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: the same ref. If you want to integrate the remote changes, use", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: 'git pull' before pushing again.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "hint: See the 'Note about fast-forwards' in 'git push --help' for details.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "~/.../dev/trade-journal $ git pull", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Enumerating objects: 4, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Counting objects: 100% (4/4), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Compressing objects: 100% (3/3), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Total 4 (delta 1), reused 4 (delta 1), pack-reused 0 (from 0)", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Unpacking objects: 100% (4/4), 8.46 KiB | 50.00 KiB/s, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "From https://github.com/Ibex361/trade-journal", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "   755e281..52c30f9  main       -> origin/main", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Merge made by the 'ort' strategy.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "y backups/backup-2026-08-11.sql.gz | Bin 8340 -> 8336 bytes", "type": "text"}]}, {"type": "paragraph", "content": [{"text": " 1 file changed, 0 insertions(+), 0 deletions(-)", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "~/.../dev/trade-journal $ git push", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Enumerating objects: 35, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Counting objects: 100% (27/27), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Delta compression using up to 8 threads", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Compressing objects: 100% (16/16), done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Writing objects: 100% (17/17), 11.32 KiB | 282.00 KiB/s, done.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "Total 17 (delta 9), reused 0 (delta 0), pack-reused 0 (from 0)", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "remote: Resolving deltas: 100% (9/9), completed with 8 local objects.", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "To https://github.com/Ibex361/trade-journal.git", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "   52c30f9..fcaa855  main -> main", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "~/.../dev/trade-journal $ cd ~/storage/downloads                               ~/storage/downloads $ nano test-all-trades-2026-08-                            test-all-trades-2026-08-02-1.csv  test-all-trades-2026-08-10.csv", "type": "text"}]}, {"type": "paragraph", "content": [{"text": "test-all-trades-2026-08-02.csv    test-all-trades-2026-08-12.csv", "type": "text"}]}]}	2026-08-12 07:50:55.072619+00	2026-08-12 07:53:05.326+00	{}	{}	\N
\.


--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trades (id, account_id, entry_date, instrument, asset_class, strategy, session, emotion, direction, entry_price, exit_price, size, pnl, r_multiple, rules_followed, notes, screenshot_url, tags, created_at, stop_loss_price, entry_time, broker_ticket, exit_date, exit_time, take_profit_price, exit_reason, sl_movement, tp_movement, screenshot_file_id) FROM stdin;
42dd0f82-bfa9-4d70-8c18-c157a092b4d0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4115.983	4111.545	1	-4.44	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4111.545	04:27:06	3016500000	2026-07-29	04:27:11	4123.235	stop_loss	\N	\N	\N
1b93524f-d85f-4bd2-9fd2-1f8a5145b492	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4091.594	4089.298	1	2.3	0.4512578616352977	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.682	03:38:59	3016488516	2026-07-29	03:46:55	4089.298	take_profit	\N	\N	\N
9ed025af-0e5a-456b-ad41-447a20cdc30b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4049.329	4053.745	1	4.42	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	02:46:05	3016479490	2026-07-29	02:52:49	\N	take_profit	\N	\N	\N
856f4cd8-1f02-4d2e-9fe6-122fff69430c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	XAUUSD	Metals	\N	\N	\N	short	4118.891	4117.909	1	0.98	0.18058109599116448	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4124.329	05:37:04	3016477130	2026-07-28	05:37:21	4114.417	manual	\N	\N	\N
b1265925-6b47-4ae1-a72b-8f7545714659	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	XAUUSD	Metals	\N	\N	\N	long	4123.996	4120.704	1	-3.29	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4120.704	04:52:50	3016464703	2026-07-28	04:54:27	4126.626	stop_loss	\N	\N	\N
99593009-36b2-4c3d-9d24-bd8c97e63db0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	XAUUSD	Metals	\N	\N	\N	short	4108.117	4100.966	2	14.3	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	04:51:50	3016462040	2026-07-28	04:55:49	4106.68	manual	\N	\N	\N
484a41bb-176f-404a-a425-e5ad5f610386	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4120.759	4117.892	5	14.34	2.458833619210787	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4121.925	11:03:34	3016459162	2026-07-27	11:45:48	4117.892	take_profit	\N	\N	\N
47a2e7eb-f051-4e18-a737-aecd329f9600	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4117.705	4120.409	1	2.7	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	11:02:09	3016456272	2026-07-27	11:02:39	\N	stop_loss	\N	\N	\N
60c16fb7-c7e8-4de0-a281-2e552696074e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4046.059	4040.82	1	-5.24	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4040.82	10:40:34	3016449939	2026-07-27	11:40:10	\N	stop_loss	\N	\N	\N
3f02ad1d-5f6b-45eb-9493-bb6b9ec6f31b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4111.975	4114.305	1	2.33	0.45085139318879025	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4106.807	10:40:00	3016442717	2026-07-27	11:39:31	4114.305	take_profit	\N	\N	\N
42434403-5b28-40b2-a3fc-6e076bf5922f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	BTCUSD	Crypto	\N	\N	\N	short	65070.26	65074.26	0.05	-0.2	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	10:32:10	3016436615	2026-07-27	10:47:03	\N	manual	\N	\N	\N
c1a92487-61ec-4938-a420-3cd5b283f5ec	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4066.018	4072.144	1	6.13	1.6862097440132309	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4062.385	10:30:26	3016433169	2026-07-27	10:30:56	4072.144	take_profit	\N	\N	\N
43d79660-67ab-4d44-bd47-8898e7faa7be	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4093.105	4088.089	1	5.02	5.579532814238827	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4094.004	09:40:34	3016425699	2026-07-27	09:50:19	4088.089	take_profit	\N	\N	\N
29ae21c7-57cf-4693-9c8f-89ce3ac8e46f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4114.305	4111.048	2	6.51	0.7949719306811602	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4118.402	09:38:19	3016422318	2026-07-27	09:44:00	4113.433	manual	\N	\N	\N
6615baf0-640c-4cb4-9341-f8900a9541a3	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4078.628	4085.263	1	6.63	8.517329910140942	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4077.849	09:37:31	3016418778	2026-07-27	09:43:59	4085.263	take_profit	\N	\N	\N
a62832c0-5d8e-4bb8-b61c-4e9e051d95b7	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4055.599	4050.245	1	5.35	4.457951706911051	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4056.8	09:09:45	3016416458	2026-07-27	09:10:43	\N	take_profit	\N	\N	\N
cdb2e2a0-4681-487f-82c0-3434a8b19896	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4114.938	4109.966	2	9.94	1.0925071412877005	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4119.489	08:40:20	3016415120	2026-07-27	09:06:25	\N	take_profit	\N	\N	\N
88b016a7-cc43-45a5-9e07-d04d2e98a2cc	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4028.916	4033.382	2	8.93	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:17:08	3016411232	2026-07-27	08:26:06	4033.382	take_profit	\N	\N	\N
82745480-e65b-4e54-ab98-5814592123b5	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4014.994	4005.139	5	49.28	3.398275862069398	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4017.894	08:11:23	3016402822	2026-07-27	08:11:34	4005.139	take_profit	\N	\N	\N
fd77e9ed-458e-4ab1-8298-103dcf5405e0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4009.097	4003.091	1	-6.01	-1.4409788867562716	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4004.929	07:49:00	3016395869	2026-07-27	08:02:38	4012.898	manual	\N	\N	\N
c90345a2-ebc8-409a-a271-13b2f27a365c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4039.123	4043.695	1	4.57	1.56040955631412	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4036.193	07:30:55	3016391179	2026-07-27	07:31:15	\N	manual	\N	\N	\N
355e4f35-d048-4ea4-950f-5ee3ef00506e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4123.76	4131.021	1	-7.26	-1.536069388618516	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4128.487	06:31:44	3016387499	2026-07-27	06:31:54	4118.77	manual	\N	\N	\N
8bbc7e59-291c-4e42-ad14-595b2db83eac	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4111.857	4113.773	2	3.83	0.34547421565093256	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4106.311	06:27:25	3016379554	2026-07-27	06:34:09	4113.773	take_profit	\N	\N	\N
6c579c0f-35b9-4984-9762-4d08992342ba	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4071.223	4068.222	2	6	0.9481832543443234	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4074.388	05:30:52	3016371106	2026-07-27	05:41:32	4068.222	take_profit	\N	\N	\N
6b9c71f0-81a3-486b-928b-48e8d1607cb0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAGUSD	Metals	\N	\N	\N	long	56.463	51.382	0.01	-254.05	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	51.382	05:25:00	3016366347	2026-07-27	05:26:09	\N	stop_loss	\N	\N	\N
04ba7d01-28be-4024-8cba-c5999a0015fd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	short	4050.698	4044.333	1	6.36	2.0072532324185515	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4053.869	05:23:40	3016363727	2026-07-27	05:35:51	\N	take_profit	\N	\N	\N
c2d93d8c-1047-4b49-aec6-56cce2627fc3	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAGUSD	Metals	\N	\N	\N	long	57.184	57.294	0.05	27.5	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	04:29:14	3016360881	2026-07-27	04:29:50	\N	take_profit	\N	\N	\N
08529a27-5475-4630-b791-2e00cc440eff	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	BTCUSD	Crypto	\N	\N	\N	short	63663.81	63793.22	0.01	-1.29	-193.14925372975438	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	63664.48	04:22:40	3016357388	2026-07-27	04:22:43	\N	manual	\N	\N	\N
de498289-81c8-41b3-8aa1-30520298d9ab	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4028.335	4035.755	1	7.42	5.296216987866467	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4026.934	04:21:20	3016354171	2026-07-27	04:22:55	4031.997	manual	\N	\N	\N
4db88acc-f2ce-49d0-ab21-4b940747f278	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-27	XAUUSD	Metals	\N	\N	\N	long	4100.423	4109.039	1	8.62	3.6247370635262115	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4098.046	04:20:31	3016346680	2026-07-27	04:21:31	4109.039	take_profit	\N	\N	\N
3831cea3-f2d1-4f99-8f0c-1b97b0c8a52d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	long	4095.393	4098.452	1	3.06	1.345798504179503	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4093.12	04:42:04	3016339721	2026-07-26	04:55:34	4098.452	take_profit	\N	\N	\N
d9eb3892-d46d-49af-8841-38f77599adf9	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	short	4110.624	4109.731	1	0.89	0.4422981674095721	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4112.643	04:20:26	3016331486	2026-07-26	04:27:03	4109.731	take_profit	\N	\N	\N
0070903c-efaf-485f-9cb7-610badbd1605	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	short	4063.807	4058.123	1	5.68	1.8317757009344575	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4066.91	04:15:19	3016325134	2026-07-26	04:15:47	4058.123	take_profit	\N	\N	\N
b03d11e8-6f97-4882-987d-a1d323892ba6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	long	4041.021	4036.34	1	-4.68	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4036.34	04:08:41	3016321644	2026-07-26	04:09:07	4047.311	stop_loss	\N	\N	\N
fca45144-b7ed-4ef3-a913-448d70f18cbd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-26	XAUUSD	Metals	\N	\N	\N	long	4126.658	4130.703	1	4.05	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	04:04:23	3016316385	2026-07-26	04:06:07	\N	take_profit	\N	\N	\N
bf88a619-5f66-4484-9e38-e39f927f7a93	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4008.495	4009.463	1	-0.97	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4009.463	20:51:39	3016310648	2026-07-25	21:04:29	4005.412	stop_loss	\N	\N	\N
380b53b3-8f8e-45dc-9e8f-5f33f38882b8	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAGUSD	Metals	\N	\N	\N	short	57.98	57.908	0.02	7.2	0.043347381095722795	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	59.641	20:46:48	3016308068	2026-07-25	20:49:43	\N	manual	\N	\N	\N
7c148a34-4afd-41d0-829e-f9b30062243e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-29	XAGUSD	Metals	\N	\N	\N	long	4099.254	4096.227	1	-3.027	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.227	04:21:00	3016491881	2026-07-29	04:22:00	\N	stop_loss	\N	\N	\N
b77f3819-2cd5-458a-93aa-73a84af81eb0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4061.089	4065.922	1	-4.83	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4065.922	20:46:18	3016302803	2026-07-25	20:54:13	4054.538	stop_loss	\N	\N	\N
fe781cf1-af66-4d2b-b043-f35de1bd58ec	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4009.283	4011.997	2	-5.43	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4011.997	20:38:03	3016296935	2026-07-25	21:31:54	\N	stop_loss	\N	\N	\N
e4e8e029-aa20-4a0b-8cea-da414f15bc39	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAGUSD	Metals	\N	\N	\N	short	56.052	56	0.01	2.6	0.011161193389139217	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	60.711	20:03:10	3016295296	2026-07-25	20:19:34	\N	take_profit	\N	\N	\N
31647a24-c1fc-45aa-8f22-161343d3f686	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4061.101	4063.824	5	-13.61	-0.4778031233549611	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4066.8	12:56:42	3016289154	2026-07-25	13:05:10	\N	manual	\N	\N	\N
cad9dc30-17c0-4558-b1b8-7c0a76308c06	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4107.241	4106.946	2	0.59	0.10064824292054401	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4110.172	12:55:05	3016284588	2026-07-25	12:55:08	4105.966	manual	\N	\N	\N
d0dbbd92-276d-4211-a519-d0bec1a1078b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	BTCUSD	Crypto	\N	\N	\N	long	64121.5	64223.92	0.01	1.02	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	12:54:39	3016280298	2026-07-25	12:54:42	64128.26	manual	\N	\N	\N
05b18439-3a55-490a-90f4-586e6be4e657	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4071.664	4077.48	1	-5.82	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	12:48:41	3016272680	2026-07-25	13:01:54	4063.003	stop_loss	\N	\N	\N
be148cae-3c82-46f8-8f2d-44533c6e8044	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4058.051	4063.945	2	-11.79	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4063.945	12:39:02	3016266638	2026-07-25	12:47:42	4055.054	stop_loss	\N	\N	\N
9a52f702-f65d-450b-a621-025d1928c5cb	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4086.28	4078.834	1	7.45	1.4463869463871066	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4091.428	12:31:04	3016264544	2026-07-25	12:31:33	\N	take_profit	\N	\N	\N
0379c174-80e1-4764-b85f-8774547b77e6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	long	4101.598	4107.226	1	5.63	2.172972972972736	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4099.008	12:29:49	3016259423	2026-07-25	12:31:45	4105.311	manual	\N	\N	\N
2b514341-dfd6-4936-a44d-81027aed1b9f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4097.08	4093.976	10	31.04	0.636195941791325	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4101.959	11:47:53	3016250115	2026-07-25	11:48:48	\N	take_profit	\N	\N	\N
aa1528c4-970f-49bb-b9f1-392b85f5c668	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	long	4010.266	4011.597	1	1.33	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	11:39:32	3016242593	2026-07-25	11:41:39	4015.294	stop_loss	\N	\N	\N
49f72349-8c17-4158-8d31-fb323144813c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4038.89	4042.536	10	-36.46	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4042.536	11:37:40	3016239546	2026-07-25	11:37:56	\N	stop_loss	\N	\N	\N
d0f980de-0321-44cb-ae72-6122841bdc6f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	long	4096.872	4092.376	5	-22.48	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	11:31:38	3016234397	2026-07-25	11:38:33	\N	manual	\N	\N	\N
4a1ed65b-c2bc-449a-aa5b-2611efac1d14	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-25	XAUUSD	Metals	\N	\N	\N	short	4004.337	4005.689	2	-2.7	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:29:23	3016225012	2026-07-25	07:30:26	3995.474	stop_loss	\N	\N	\N
1e1e965f-89db-43f0-bc6b-d5c4d380c24f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	BTCUSD	Crypto	\N	\N	\N	short	64177.43	64180.12	0.01	-0.03	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64180.12	21:38:02	3016222649	2026-07-24	21:42:19	64168.85	stop_loss	\N	\N	\N
51b3f513-e895-4591-b77d-956845fed107	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	short	4106.914	4105.001	1	1.91	0.4962386511022883	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4110.769	21:30:18	3016221252	2026-07-24	21:31:15	\N	manual	\N	\N	\N
a6c9945f-0ea8-4a81-b24d-caee3474faad	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4039.567	4034.98	5	-22.93	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4034.98	20:37:27	3016214136	2026-07-24	20:42:06	4049.07	stop_loss	\N	\N	\N
c1a79575-68ad-4e0c-9e7c-6351df58707b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	short	4048.169	4043.706	1	4.46	1.8046906591184055	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4050.642	20:04:08	3016207751	2026-07-24	20:04:25	4043.706	take_profit	\N	\N	\N
c79a7305-ff14-468c-a9ed-8a61243cc49b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4043.356	4041.575	1	-1.78	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4041.575	19:52:53	3016204389	2026-07-24	19:59:23	4051.28	stop_loss	\N	\N	\N
692a1b27-c510-45df-8401-095320f4953d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4112.638	4109.823	1	-2.81	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4109.823	14:06:49	3016196852	2026-07-24	14:07:22	\N	stop_loss	\N	\N	\N
cadc66da-1d34-455f-80de-5e2be0164e44	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	long	4005.637	3998.135	5	-37.51	-2.6369068541298	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4002.792	13:57:42	3016188757	2026-07-24	14:00:25	4007.43	manual	\N	\N	\N
52c4963b-76d7-4a39-9821-96a0d5cd2920	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-24	XAUUSD	Metals	\N	\N	\N	short	4076.097	4076.838	1	-0.74	-0.16995412844037638	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4080.457	13:47:12	3016181571	2026-07-24	13:49:05	\N	take_profit	\N	\N	\N
a758eec4-b162-4386-91df-d88d3dd6f841	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	short	4094.85	4099.925	1	-5.08	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4099.925	20:50:46	3016177541	2026-07-23	20:53:05	\N	stop_loss	\N	\N	\N
3c5346eb-d51c-4d70-b786-064218674220	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	BTCUSD	Crypto	\N	\N	\N	short	64321.62	64366.13	0.01	-0.45	-10.829683698294028	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64325.73	20:50:24	3016168624	2026-07-23	20:52:42	\N	manual	\N	\N	\N
9688115e-1737-45aa-8abb-1b5096f7aa37	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	long	4109.87	4115.141	2	10.54	1.2075601374570435	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4105.505	20:50:01	3016166229	2026-07-23	21:46:35	\N	take_profit	\N	\N	\N
9ba1adb5-920c-4c39-bfa5-c433ff446950	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	short	4096.326	4097.068	1	-0.74	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:43:44	3016164756	2026-07-23	13:44:37	\N	manual	\N	\N	\N
88f411a4-ebbb-4c05-b2ee-861c82f0ad08	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	long	4086.052	4081.822	1	-4.23	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4081.822	13:42:22	3016162450	2026-07-23	13:42:40	\N	stop_loss	\N	\N	\N
0f7b2059-e23b-4e33-b485-69eee8d3c019	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-23	XAUUSD	Metals	\N	\N	\N	long	4122.892	4115.016	1	-7.88	-3.0397529911238546	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4120.301	13:36:07	3016161025	2026-07-23	13:37:12	\N	manual	\N	\N	\N
37c94a8e-bad3-4b9d-a486-f904f820a3c3	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4010.122	4004.308	1	-5.81	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4004.308	22:38:43	3016155530	2026-07-22	22:41:40	4012.503	stop_loss	\N	\N	\N
6e19ec40-db6c-48f3-93dc-5eccbce105d5	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4051.45	4053.016	1	-1.57	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4053.016	22:27:43	3016150796	2026-07-22	22:34:29	4043.509	stop_loss	\N	\N	\N
d9dfd9dc-e175-4133-9c08-a5311910a11c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4085.216	4084.398	2	-1.64	-0.20480721081617936	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4081.222	22:25:49	3016148944	2026-07-22	22:36:44	4091.762	manual	\N	\N	\N
c0a0178c-ec64-4bf7-8632-8449f092eb13	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4076.885	4084.283	2	-14.8	-1.8284725654967893	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4080.931	22:24:19	3016146754	2026-07-22	22:26:58	\N	take_profit	\N	\N	\N
1b19a24a-1a08-4b9a-b576-99cc1be99c9e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	BTCUSD	Crypto	\N	\N	\N	long	65119.63	65014.89	0.01	-1.05	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	21:53:05	3016139034	2026-07-22	21:54:23	\N	take_profit	\N	\N	\N
dae1f4a4-cafa-43aa-b6b9-b10eab417b95	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4079.275	4083.335	1	-4.06	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4083.335	21:52:12	3016129534	2026-07-22	21:54:17	4077.869	stop_loss	\N	\N	\N
61ecbc4f-740c-4ed7-b149-9123a6ec3824	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4075.756	4074.027	1	-1.73	-0.7848388561052357	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4073.553	21:27:49	3016123641	2026-07-22	21:36:06	4080.021	manual	\N	\N	\N
d7836a24-1b5b-4068-b5c0-1090869c8a6a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4040.153	4045.952	1	-5.8	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	21:25:55	3016114232	2026-07-22	21:26:04	4038.423	manual	\N	\N	\N
becb3b3f-1add-454f-bfa0-e201f2b73e4c	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4023.51	4020.688	1	2.82	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:40:15	3016106226	2026-07-22	08:41:27	4020.089	manual	\N	\N	\N
f525e699-d16b-453c-b58b-fd145bd6ea61	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-22	XAUUSD	Metals	\N	\N	\N	short	4025.222	4020.772	5	22.25	3.1991373112879105	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4026.613	08:35:16	3016098087	2026-07-22	08:45:47	4022.585	manual	\N	\N	\N
d6ab750d-cc1b-4789-ba17-0a53040df310	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4067.068	4076.575	1	9.51	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:35:25	3016090297	2026-07-21	14:37:07	4076.575	take_profit	\N	\N	\N
9fcd77c4-072f-4421-a688-0b013966e672	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4010.609	4013.008	1	2.4	1.154475457170316	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4008.531	14:34:18	3016087747	2026-07-21	14:42:44	\N	manual	\N	\N	\N
b858436c-fbff-48d8-a741-e12ec215be11	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4028.035	4032.454	1	4.42	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:30:56	3016084046	2026-07-21	14:33:46	\N	take_profit	\N	\N	\N
6eb07521-8d59-4149-8a44-38db05b8cbe7	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4074.756	4070.581	1	-4.17	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4070.581	14:21:39	3016078300	2026-07-21	14:22:04	\N	stop_loss	\N	\N	\N
5692d342-0dc2-48e7-b49a-f737252f6e21	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	BTCUSD	Crypto	\N	\N	\N	long	64440.27	64397.4	0.01	-0.43	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:19:30	3016075731	2026-07-21	14:28:52	\N	stop_loss	\N	\N	\N
7d0bd28c-63f6-4259-a720-9097c1edc35b	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4089.009	4086.895	2	-4.23	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4086.895	14:12:50	3016069454	2026-07-21	14:26:36	4090.212	stop_loss	\N	\N	\N
5a6ad7df-f054-498e-a807-d20777f9b407	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4097.928	4100.617	1	-2.69	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	14:06:27	3016066960	2026-07-21	14:15:32	4088.945	manual	\N	\N	\N
57de3834-0a5f-49f4-9e8a-0a4e2ad57a13	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4094.521	4097.382	2	-5.72	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:48:42	3016062431	2026-07-21	13:51:02	4090.901	manual	\N	\N	\N
bb8c7f07-8e52-4570-b37c-90ded914fb99	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4056.542	4056.333	1	0.21	0.31147540983568783	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4057.213	13:44:52	3016058686	2026-07-21	13:45:36	\N	take_profit	\N	\N	\N
0eb1f702-e236-49be-95dc-6c5dadcb6a1d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4123.431	4125.479	1	-2.05	-0.6002344665886655	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4126.843	13:43:16	3016052133	2026-07-21	14:28:58	4118.969	manual	\N	\N	\N
86897632-27b0-4127-8520-e5719054b820	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4033.838	4041.816	1	7.98	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:40:20	3016044532	2026-07-21	13:53:46	\N	take_profit	\N	\N	\N
090622b4-ada2-4f91-9030-0a42af1eeb6f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4110.677	4102.915	2	15.52	2.412806963008512	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4113.894	13:29:21	3016042249	2026-07-21	13:29:46	\N	take_profit	\N	\N	\N
97c7732a-6b97-4192-a7c1-c34966960f52	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAGUSD	Metals	\N	\N	\N	long	57.999	64.709	0.01	335.5	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	13:27:58	3016035968	2026-07-21	13:39:56	64.709	take_profit	\N	\N	\N
3e8f3736-37ac-4c10-b58a-df87a121b726	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4016.774	4011.409	2	-10.73	-2.2326258843113793	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4014.371	08:17:37	3016027601	2026-07-21	08:17:56	4026.23	manual	\N	\N	\N
9ee88e75-a2aa-4990-ab56-619f11e7a4b6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4079.876	4081.166	1	1.29	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:55:31	3016022492	2026-07-21	07:58:09	4088.974	manual	\N	\N	\N
7acfb630-249f-423c-b92f-28d24fae7045	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4099.705	4097.434	1	2.27	0.4597165991901815	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4104.645	07:54:09	3016020344	2026-07-21	07:54:46	\N	take_profit	\N	\N	\N
dadc0da8-e5e3-44ad-9527-c2dd1ca21dc4	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4078.866	4081.932	1	-3.07	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4081.932	07:53:01	3016015139	2026-07-21	07:53:14	\N	stop_loss	\N	\N	\N
8dc0f4f3-ceba-4b42-adaf-9f9a0aa3a122	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4112.49	4117.825	1	-5.34	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4117.825	07:49:37	3016012527	2026-07-21	07:49:45	4107.114	stop_loss	\N	\N	\N
13eadf68-c67b-4e1f-b205-01554771b28e	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4077.677	4071.397	1	-6.28	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:40:00	3016004209	2026-07-21	07:40:29	\N	stop_loss	\N	\N	\N
2f6c3216-55f1-4361-a7ab-931cb8d848cb	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4009.559	4007.587	1	1.97	1.9108527131790547	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4010.591	07:38:59	3016001109	2026-07-21	07:51:22	\N	take_profit	\N	\N	\N
52373e84-0465-42ed-bb1d-d6486f341fd0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4017.815	4021.545	1	3.73	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	07:38:06	3015992481	2026-07-21	07:38:19	4021.545	take_profit	\N	\N	\N
fd4c7932-e4f8-4019-9f14-603397e1a9f2	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4038.973	4031.843	1	7.13	1.5883270216083887	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4043.462	07:32:00	3015990380	2026-07-21	07:41:17	4031.843	take_profit	\N	\N	\N
735cbc18-db7f-4c6a-a974-9d5428d930a0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4081.773	4074.602	1	7.17	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	06:42:15	3015984113	2026-07-21	06:42:37	\N	take_profit	\N	\N	\N
4905ce37-f787-49fe-9be9-56d73fd2e24d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4095.659	4090.63	2	10.06	0.8727872266573841	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4101.421	06:34:13	3015980036	2026-07-21	06:35:18	4090.63	take_profit	\N	\N	\N
429f239b-6b5a-412d-bc85-d8fff358613a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4032.047	4035.186	1	-3.14	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4035.186	05:43:05	3015976880	2026-07-21	05:49:55	4026.091	stop_loss	\N	\N	\N
df0b1586-a043-47c7-8aaf-1abd13894af2	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4124.099	4118.891	2	10.42	2.7267015706811177	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4126.009	05:18:27	3015975473	2026-07-21	05:19:34	4118.891	take_profit	\N	\N	\N
7d41b86a-e361-40d7-a130-d15ed3e6eb61	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4087.078	4085.691	1	-1.39	-0.29267778012242274	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4082.339	05:17:09	3015972025	2026-07-21	05:17:28	\N	manual	\N	\N	\N
d87062c1-c8dd-4de9-8c3c-34ab9a1f1a94	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4083.967	4080.148	1	3.82	0.685883620689678	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4089.535	05:13:28	3015970640	2026-07-21	05:13:55	\N	take_profit	\N	\N	\N
d3dab64f-cf46-460c-95fa-d6e8c1c948cb	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	short	4001.205	3995.766	2	10.88	4.393376413569147	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4002.443	05:06:00	3015966756	2026-07-21	05:06:57	3995.766	take_profit	\N	\N	\N
55a86922-68c4-438d-83cc-e082e3de0213	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-21	XAUUSD	Metals	\N	\N	\N	long	4043.825	4049.523	1	5.7	1.7090581883625093	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4040.491	04:38:26	3015957423	2026-07-21	04:38:38	4045.423	manual	\N	\N	\N
58c8e340-9c1b-4562-917d-b09ef3c79946	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-20	XAUUSD	Metals	\N	\N	\N	short	4097.988	4095.529	1	2.46	2.138260869566144	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4099.138	16:21:31	3015950543	2026-07-20	16:21:44	\N	take_profit	\N	\N	\N
004bb123-cc27-43d5-b05c-e99e0165cadd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-20	XAUUSD	Metals	\N	\N	\N	short	4028.71	4027.018	1	1.69	0.5475728155339572	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4031.8	15:28:30	3015945096	2026-07-20	15:34:06	4022.965	manual	\N	\N	\N
e2ecce40-e6f9-4ab8-8f34-63dc9e548a6f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	short	4047.032	4052.232	1	-5.2	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4052.232	17:16:56	3015941161	2026-07-19	18:09:19	\N	stop_loss	\N	\N	\N
81be8a89-1faa-4c04-9336-32b12f20c967	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAGUSD	Metals	\N	\N	\N	short	56.907	59.585	0.02	-267.8	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	59.585	17:12:26	3015933869	2026-07-19	17:12:45	48.596	stop_loss	\N	\N	\N
1c14e13c-6f40-4806-abe1-2dc9db41d1d6	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4008.972	4003.139	5	-29.17	-1.0055162902947243	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4003.171	17:10:12	3015930590	2026-07-19	17:10:30	4013.217	manual	\N	\N	\N
030c4b0f-4489-4f68-9fb6-3521239789fc	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4045.21	4052.87	1	7.66	1.3022781366881628	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4039.328	16:39:34	3015924987	2026-07-19	16:39:42	4050.27	manual	\N	\N	\N
f5e091dc-7762-42f1-b1be-2a8b927f2491	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4094.253	4101.233	5	34.9	8.02298850574396	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4093.383	16:32:06	3015921853	2026-07-19	16:32:44	\N	manual	\N	\N	\N
e57b6de9-b00c-4ab0-9d7f-584582fe510a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4100.888	4104.638	2	7.5	0.8930697785187769	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.689	16:30:17	3015920173	2026-07-19	16:38:13	4104.638	take_profit	\N	\N	\N
ba03d575-7e1d-4beb-9f1d-36cbeafde024	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4055.536	4060.109	1	4.57	3.461771385314283	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4054.215	16:20:24	3015913485	2026-07-19	16:29:16	4059.799	manual	\N	\N	\N
55a96bb2-a739-4102-93f6-d8ee7fafade8	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	short	4073.11	4076.084	5	-14.87	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4076.084	04:53:26	3015905251	2026-07-19	04:56:18	\N	stop_loss	\N	\N	\N
c0a71789-4141-4907-9164-924287c04428	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-19	XAUUSD	Metals	\N	\N	\N	long	4024.461	4018.962	2	-11	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4018.962	04:49:11	3015899595	2026-07-19	04:49:38	\N	stop_loss	\N	\N	\N
614c00e9-313c-4e6e-b9de-9ae652e185b4	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-18	XAUUSD	Metals	\N	\N	\N	long	4031.113	4032.82	1	1.71	0.5276661514684722	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4027.878	10:52:58	3015897349	2026-07-18	10:54:40	4032.82	take_profit	\N	\N	\N
99efd8b2-7d24-4f48-9be4-c62052c35f19	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-18	XAUUSD	Metals	\N	\N	\N	long	4002.109	3997.248	1	-4.86	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	10:46:31	3015891841	2026-07-18	10:49:30	4005.17	stop_loss	\N	\N	\N
aedea703-3cec-4572-beaf-24e44b270c39	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	short	4095.26	4088.59	1	6.67	8.104495747271992	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4096.083	16:29:07	3015889379	2026-07-17	16:30:20	4094.149	manual	\N	\N	\N
ade4fe85-de53-420f-a279-bd562e79d0ef	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAGUSD	Metals	\N	\N	\N	long	56.302	57.247	0.01	47.25	0.22903538536112478	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	52.176	16:27:18	3015880051	2026-07-17	16:27:27	57.247	take_profit	\N	\N	\N
c1dfb002-0fd9-43f2-871f-22a0eff7ab3a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	short	4105.71	4105.32	1	0.39	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	16:21:10	3015871394	2026-07-17	16:43:28	4102.588	manual	\N	\N	\N
3b42982c-0bd0-463a-8b8f-9bfa74cfa766	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	long	4029.361	4028.552	10	-8.09	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4028.552	02:16:14	3015864294	2026-07-17	02:30:23	4030.248	stop_loss	\N	\N	\N
cd9bb2cc-fac0-466d-80fc-72b0b14b563d	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAGUSD	Metals	\N	\N	\N	long	57.838	57.702	0.02	-13.6	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	01:27:13	3015862186	2026-07-17	01:28:37	66.912	stop_loss	\N	\N	\N
73ba39c0-371d-48ca-b547-55865131991a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	short	4038.906	4031.764	5	35.71	1.4731848184818255	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4043.754	00:23:01	3015852801	2026-07-17	00:35:41	4031.764	take_profit	\N	\N	\N
5e9368de-4cb5-484b-8def-ccb54b34abe0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAGUSD	Metals	\N	\N	\N	short	57.228	57.143	0.01	4.25	0.023997741389045965	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	60.77	00:16:07	3015848867	2026-07-17	00:18:18	\N	take_profit	\N	\N	\N
3206e0f9-a58c-441a-97c1-c8d370ebeb0a	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-17	XAUUSD	Metals	\N	\N	\N	long	4020.049	4015.362	1	-4.69	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4015.362	00:08:38	3015841643	2026-07-17	00:09:47	4021.79	stop_loss	\N	\N	\N
83e075c3-fafe-4112-9325-9a0809cc7933	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	long	4012.098	4021.226	1	9.13	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	23:59:59	3015837866	2026-07-17	00:01:52	4021.226	take_profit	\N	\N	\N
f8e00d31-3798-4871-99e2-64e40ba1ff73	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	short	4008.225	4012.163	1	-3.94	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4012.163	23:58:36	3015832487	2026-07-17	00:00:16	\N	stop_loss	\N	\N	\N
d6e1144b-96bd-419c-915e-f4132056e8b2	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	BTCUSD	Crypto	\N	\N	\N	short	64259.78	64162.72	0.02	1.94	45.14418604647999	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64261.93	23:49:48	3015829602	2026-07-16	23:51:42	64253.43	manual	\N	\N	\N
271ee799-3620-439d-935d-f2990963b8ff	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	short	4101.657	4094.744	5	34.57	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:49:50	3015826513	2026-07-16	08:51:56	4099.202	manual	\N	\N	\N
ec403b91-732a-475c-8010-a9ee0d078b21	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAUUSD	Metals	\N	\N	\N	long	4103.435	4099.478	2	-7.91	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:40:58	3015821571	2026-07-16	08:43:35	4107.703	stop_loss	\N	\N	\N
638bce64-894d-4f6a-b661-697f301fa451	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-16	XAGUSD	Metals	\N	\N	\N	short	57.581	57.698	0.01	-5.85	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	08:31:48	3015820329	2026-07-16	09:30:21	55.251	manual	\N	\N	\N
b19361d4-96d4-400a-b9f4-2af112391942	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4028.86	4024.622	1	-4.24	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4024.622	19:57:25	3015818408	2026-07-15	20:09:56	4036.012	stop_loss	\N	\N	\N
f1b1c2d9-a97b-489a-b9b1-a3fa2d022161	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	BTCUSD	Crypto	\N	\N	\N	long	64960.3	64966.63	0.02	0.13	1.4161073825487296	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64955.83	19:48:11	3015817007	2026-07-15	19:57:02	\N	manual	\N	\N	\N
df67ec07-f199-4d1c-ae67-ba31309cef27	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4021.366	4016.478	1	-4.89	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4016.478	19:47:53	3015811801	2026-07-15	19:49:25	4027.96	stop_loss	\N	\N	\N
8f112e76-9a06-465b-bbbb-dc7a0ae854c1	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAGUSD	Metals	\N	\N	\N	short	56.778	56.685	0.01	4.65	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	19:15:53	3015809848	2026-07-15	19:22:23	\N	stop_loss	\N	\N	\N
5009a01f-b8c2-464a-92ec-f116f7dd0cfd	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4083.084	4088.06	1	-4.98	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4088.06	19:08:39	3015800919	2026-07-15	19:10:48	4075.789	stop_loss	\N	\N	\N
4b1ed3ae-935b-4f64-b1fe-24aa6e5a1521	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4090.147	4088.286	1	-1.86	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	19:06:13	3015793756	2026-07-15	19:06:32	4097.327	manual	\N	\N	\N
ac26d19c-0f45-4e17-9b5e-53032321e100	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4112.518	4105.097	1	7.42	1.7395686826068764	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4116.784	19:05:41	3015786282	2026-07-15	19:11:00	4107.894	manual	\N	\N	\N
b46d6a54-0e22-4d77-ae7e-8bde60ff5b37	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4029.23	4024.975	1	4.26	3.7721631205669497	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4030.358	19:04:29	3015782624	2026-07-15	19:15:17	\N	manual	\N	\N	\N
80a4eec2-f604-4ee3-9558-9355f20f1b36	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4013.314	4007.347	10	-59.67	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4007.347	18:22:29	3015778492	2026-07-15	18:24:02	4021.25	stop_loss	\N	\N	\N
596a6d49-a852-498d-afa3-16fd33a55c61	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4105.759	4107.309	2	3.1	\N	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	\N	17:28:58	3015776713	2026-07-15	17:29:43	4109.251	manual	\N	\N	\N
e51db471-0aaf-45c1-81e5-ed835d8dcdb0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4129.023	4125.641	5	16.91	0.8016117563404778	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4133.242	17:26:59	3015768643	2026-07-15	17:27:29	4123.72	manual	\N	\N	\N
5d33bbb6-7a0e-45b5-80c5-e0ed6773463f	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4097.474	4089.514	1	-7.96	-1.76106194690267	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4092.954	17:26:15	3015763765	2026-07-15	17:28:19	4102.492	manual	\N	\N	\N
50eff410-6489-4667-87a1-19eccb5fe7d7	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	BTCUSD	Crypto	\N	\N	\N	long	64145.73	64141.04	0.01	-0.05	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	64141.04	17:24:11	3015757293	2026-07-15	17:24:23	64146.95	stop_loss	\N	\N	\N
66d758ce-ff3d-4e88-be40-1c57097f7561	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	short	4124.544	4126.421	1	-1.88	-1	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4126.421	12:22:47	3015752026	2026-07-15	12:22:56	4120.323	stop_loss	\N	\N	\N
79bcbf1b-f327-43e2-942c-689a49899c40	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-15	XAUUSD	Metals	\N	\N	\N	long	4011.856	4013.355	1	1.5	2.7555147058803384	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	4011.312	12:20:54	3015744007	2026-07-15	12:21:00	4015.817	manual	\N	\N	\N
79cbc77f-9106-4e88-b04d-dcbf02fd1cd0	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-07-28	USTEC	Metals	\N	\N	\N	long	57.584	57.574	0.01	-0.5	-0.00175963	\N	\N	\N	{}	2026-08-12 10:26:02.212631+00	51.901	04:58:00	3016472179	2026-07-28	04:59:00	64.643	manual	\N	\N	\N
d4c90196-88c2-4318-8e09-d781296e2a02	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-13	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-13 18:35:08.033321+00	\N	21:30:00	\N	2026-08-13	21:34:00	\N	\N	\N	\N	\N
87bf0743-3c27-4175-bea3-9ff2f09ecd77	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-13	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-13 19:25:02.261412+00	\N	03:30:00	\N	2026-08-13	11:00:00	\N	\N	\N	\N	\N
c8335101-3135-4921-8dd2-48497ec7ec32	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-12	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-14 08:39:34.442777+00	\N	10:50:00	\N	2026-08-12	11:39:00	\N	\N	\N	\N	\N
aa79b2d2-f0e7-45c4-9253-d74f1ba719da	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4014.6	4019.51	1	-4.91	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4019.51	04:12:46	3016221392	2026-07-29	04:29:00	4004.456	stop_loss	\N	\N	\N
e390281f-a8f1-4ef7-a43b-ec908253cbe4	adcd73dd-7f12-4fff-a0e6-62bde1ebd6cc	2026-08-14	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	12	\N	\N	\N	\N	{}	2026-08-14 05:55:39.050552+00	\N	03:01:00	\N	2026-08-14	03:30:00	\N	\N	\N	\N	\N
c1bfc702-0c6f-484b-aee8-8c9d88fd4fa8	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAGUSD	Metals	\N	\N	\N	short	56.928	57.028000000000006	0.01	-5	-1.010101010101058	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	57.027	04:14:09	3016225586	2026-07-29	04:15:21	56.865	stop_loss	\N	\N	\N
a3b0a14b-4c0b-4ce8-8016-f487beb9232b	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4014.354	4015.859	1	-1.51	-0.3810126582278494	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4018.304	04:07:08	3016205204	2026-07-29	04:12:09	4012.469	manual	\N	\N	\N
984c7f3b-002a-43ed-a895-38807cff88e5	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4017.054	4012.8179999999998	1	4.23	3.670710571924042	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4018.208	04:01:53	3016183906	2026-07-29	04:04:38	4008.708	manual	\N	\N	\N
1b9e0109-856f-40aa-bec6-6111cd88d7df	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAGUSD	Metals	\N	\N	\N	short	57.124	57.168	0.01	-2.2	-1.0232558139534347	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	57.167	03:58:23	3016169199	2026-07-29	03:59:51	57.071	stop_loss	\N	\N	\N
481575c1-afa2-4c50-9e53-7b4207fc328b	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4021.453	4022.066	1	0.62	0.4915797914995236	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4020.206	03:58:19	3016172263	2026-07-29	03:58:54	4022.066	take_profit	\N	\N	\N
d980af04-d866-444f-ae4e-55058af3adb2	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4020.497	4021.3979999999997	1	-0.9	-1.1206467661688335	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4021.301	03:57:45	3016170411	2026-07-29	03:57:46	4019.652	stop_loss	\N	\N	\N
4573605d-22e9-4d69-99ef-705ff583277d	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4023.107	4021.883	1	-1.23	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4021.883	03:55:17	3016167161	2026-07-29	03:55:37	4023.725	stop_loss	\N	\N	\N
e0c2eb09-8097-4b68-a895-00a8a42f6cf0	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4023.137	4024.1059999999998	1	-0.97	-1.0319488817888713	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.076	03:54:16	3016165665	2026-07-29	03:55:00	\N	stop_loss	\N	\N	\N
725fedb4-ba6f-48ea-80e5-259c229c4aa2	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4022.797	4023.2439999999997	1	-0.44	-1.0849514563103662	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4023.209	03:53:52	3016165060	2026-07-29	03:54:09	\N	stop_loss	\N	\N	\N
018330a8-709c-4d38-9961-745d7c4d266d	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4025.14	4025.73	1	0.59	0.3042805569882367	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4023.201	03:39:54	3016144257	2026-07-29	03:43:21	4025.73	take_profit	\N	\N	\N
9d134275-eeef-4899-ab64-31ebc70d1fc1	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4026.142	4025.562	1	-0.58	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4025.562	03:38:47	3016142383	2026-07-29	03:39:21	4027.461	stop_loss	\N	\N	\N
0a5d3e44-ecbc-44c7-886e-c41bbb1b721f	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4022.489	4025.897	1	3.41	0.9281045751633655	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4026.161	03:32:31	3016131486	2026-07-29	03:38:22	4030.819	stop_loss	\N	\N	\N
aa161daa-af71-485b-91f4-226f51b0b165	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4024.311	4026.368	1	2.06	3.540447504304536	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.892	03:36:47	3016137372	2026-07-29	03:37:59	\N	manual	\N	\N	\N
fb5a9d57-f206-4a95-a0f1-9a02bbdab048	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4022.976	4022.018	1	-0.96	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4022.018	03:29:20	3016125507	2026-07-29	03:30:41	4023.95	stop_loss	\N	\N	\N
1cbbf01b-75b1-423e-a809-a614bb6245bd	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4022.336	4022.741	1	-0.4	-0.21797631862226158	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.194	03:28:38	3016124339	2026-07-29	03:30:39	\N	manual	\N	\N	\N
19411617-2f64-4489-9eda-7608181a6a6a	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	long	4026.621	4022.269	1	-4.35	-1	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4022.269	03:22:29	3016110561	2026-07-29	03:29:02	\N	stop_loss	\N	\N	\N
77785262-3936-4584-a1d9-214579a67925	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4023.749	4023.5429999999997	1	0.21	0.17024793388440063	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	4024.959	03:28:12	3016123556	2026-07-29	03:28:28	\N	manual	\N	\N	\N
c1416d2f-d9fb-4973-92ef-f51020606972	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	XAUUSD	Metals	\N	\N	\N	short	4023.879	4023.421	1	0.46	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	03:27:41	3016122567	2026-07-29	03:27:58	\N	manual	\N	\N	\N
c67fd7e9-a5d9-40e5-8f7f-cecbc144bcdd	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-29	BTCUSD	Crypto	\N	\N	\N	long	64001.46	63949.840000000004	0.01	-0.51	-1.0080062487794614	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	63950.25	03:17:21	3016097478	2026-07-29	03:20:53	\N	stop_loss	\N	\N	\N
0b7234cb-03d4-4c6d-b670-65718c82584c	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-28	XAUUSD	Metals	\N	\N	\N	long	4049.529	4049.3140000000003	1	-0.22	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	09:33:11	3011745614	2026-07-28	09:33:22	\N	manual	\N	\N	\N
688efc45-cd8c-45bc-9a36-8fec3566be2c	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-28	XAUUSD	Metals	\N	\N	\N	short	4049.021	4049.6569999999997	1	-0.64	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	09:32:57	3011744895	2026-07-28	09:33:09	\N	manual	\N	\N	\N
b1a28813-ea6e-4974-8bb5-3b7af5cf6369	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-28	XAUUSD	Metals	\N	\N	\N	long	4049.568	4049.525	1	-0.04	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	09:32:43	3011744014	2026-07-28	09:32:47	\N	manual	\N	\N	\N
ebb98f5c-77df-458e-b0ee-625432c14434	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-22	XAUUSD	Metals	\N	\N	\N	long	4120.155	4119.847	10	-3.08	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	14:12:59	2991037348	2026-07-22	14:13:04	\N	manual	\N	\N	\N
d8bae59b-3482-4262-887f-98876c189486	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-19	BTCUSD	Crypto	\N	\N	\N	long	64543.95	64534.07	0.01	-0.1	\N	\N	\N	\N	{}	2026-08-14 10:17:43.138549+00	\N	19:47:11	2978668763	2026-07-19	19:47:19	\N	manual	\N	\N	\N
6e951fd2-2aaf-41c1-bf5e-a8ba87e7bbbf	40f6a8ae-bc42-4397-8988-577d9373e75c	2026-07-31	XAUUSD	\N	\N	\N	\N	long	\N	\N	\N	10	\N	\N	\N	\N	{}	2026-08-14 10:45:00.282238+00	\N	13:44:00	\N	2026-07-31	17:44:00	\N	\N	\N	\N	\N
d161661b-b713-43f2-9e3b-781ae1a4b467	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-10	XAUUSD	Metals	\N	\N	\N	short	4404.347	4401.22	1	3.13	0.7995397596521225	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4408.258	11:27:56	3208145496	2026-09-10	11:37:12	4398.097	manual	\N	\N	\N
2ef16f8a-1b59-46b0-ad2e-fa4753435b23	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-10	USTEC	Indices	\N	\N	\N	long	29489.95	29434.46	0.05	-2.77	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	29434.46	09:50:01	3207740471	2026-09-10	10:29:54	29558.6	stop_loss	\N	\N	\N
7118b1f1-cd0e-4cb4-92df-3b99421e23a2	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-10	XAUUSD	Metals	\N	\N	\N	long	4417.036	4410.578	1	-6.46	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4410.578	09:29:00	3207645217	2026-09-10	10:22:22	4434.751	stop_loss	\N	\N	\N
f7d7d97e-7a29-411a-aad2-53d3c9464700	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	UKOIL	\N	\N	\N	\N	long	97.915	98.703	0.01	7.88	1.0102564102564229	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	98.695	10:46:41	3202019835	2026-09-09	13:48:39	99.216	manual	\N	\N	\N
3d691166-fd19-47f7-82fe-15ddae417c2a	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	XAUUSD	Metals	\N	\N	\N	short	4399.163	4387.787	1	11.37	2.448557899267698	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4403.809	11:40:36	3202271118	2026-09-09	13:01:34	4387.787	take_profit	\N	\N	\N
b606cde5-f838-4727-bf3c-cdb15fac1312	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	XAUUSD	Metals	\N	\N	\N	long	4409.891	4406.245	1	-3.64	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4406.245	11:05:36	3202100443	2026-09-09	11:10:08	4425.507	stop_loss	\N	\N	\N
22d11973-866d-4906-beeb-59e357d312bc	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	XAUUSD	Metals	\N	\N	\N	long	4410.718	4409.997	1	-0.72	-0.26973438084534596	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4408.045	10:45:01	3202008316	2026-09-09	10:57:18	4409.997	take_profit	\N	\N	\N
d67fc0f6-1890-4b86-83ec-b6ca62e0be39	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	EURUSD	Forex	\N	\N	\N	long	1.16405	1.1640000000000001	5000	-0.25	-0.17241379310297303	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	1.16376	10:05:10	3201842951	2026-09-09	10:08:15	1.16442	manual	\N	\N	\N
b1e7272f-b5bb-4ec5-9cf9-e36c218d8d72	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	XAUUSD	Metals	\N	\N	\N	long	4399.236	4404.259	1	5.02	5.0129740518988575	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4398.234	09:30:25	3201730054	2026-09-09	10:07:55	4404.259	take_profit	\N	\N	\N
67e7d402-29fc-4a8c-b6eb-d846e8d81b7c	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	XAUUSD	Metals	\N	\N	\N	long	4389.987	4400	1	10.01	1.4543209876542633	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4383.102	08:36:45	3201538480	2026-09-09	08:54:55	4400	take_profit	\N	\N	\N
298a4a81-b2b0-4f64-99c9-2bd63edaf901	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	UKOIL	\N	\N	\N	\N	short	97.136	97.228	0.01	-0.92	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	97.228	08:30:23	3201519321	2026-09-09	08:31:29	96.953	stop_loss	\N	\N	\N
31dd1a0c-5796-42a9-9ca0-d287e8ae13c8	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-09	USDJPY	Forex	\N	\N	\N	long	153.448	153.324	1000	-0.81	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	153.324	08:13:37	3201472322	2026-09-09	08:27:41	153.812	stop_loss	\N	\N	\N
63b819f4-fd8f-41be-baed-6e2db36373fe	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	XAUUSD	Metals	\N	\N	\N	long	4401.312	4400.274	1	-1.04	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4400.274	18:30:44	3199025244	2026-09-08	18:36:30	4405.176	stop_loss	\N	\N	\N
b8f7ca49-a4af-4b79-a7e5-27502970e8db	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	USTEC	Indices	\N	\N	\N	long	29522.31	29594.67	0.05	3.62	8.911330049257833	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	29514.19	17:44:40	3198701040	2026-09-08	18:13:20	29594.67	take_profit	\N	\N	\N
87d0729e-02e9-4b59-a2b4-908d5707b0c3	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	XAUUSD	Metals	\N	\N	\N	long	4400.669	4405.263	1	4.59	3.168275862069398	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4399.219	14:55:11	3197397244	2026-09-08	14:58:49	4405.263	take_profit	\N	\N	\N
268e1bd3-6f3e-40ee-a53c-aeea21d496e8	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	USTEC	Indices	\N	\N	\N	short	29550.44	29544.31	0.05	0.31	0.31452026680332873	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	29569.93	14:41:05	3197326681	2026-09-08	14:46:41	29482.3	manual	\N	\N	\N
bdd51072-fc59-4ee3-bff9-b81f4653f29f	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	XAUUSD	Metals	\N	\N	\N	long	4402.102	4405.016	1	2.92	1.3700047014576624	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4399.975	14:28:11	3197253263	2026-09-08	14:35:04	4405.016	take_profit	\N	\N	\N
abe0f7d0-8f4e-4a56-9da7-80588d964f50	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	XAUUSD	Metals	\N	\N	\N	short	4393.904	4400.437	1	-6.54	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4400.437	14:10:58	3197156044	2026-09-08	14:16:54	4388.038	stop_loss	\N	\N	\N
2ac1b0b9-8097-4d68-bcd9-ac69c9310550	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-08	XAUUSD	Metals	\N	\N	\N	short	4392.28	4397.221	1	-4.94	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4397.221	12:30:07	3196677465	2026-09-08	12:32:06	4381.743	stop_loss	\N	\N	\N
5a8b8aaf-35cb-47f4-8ebb-54173fde8bda	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-07	XAUUSD	Metals	\N	\N	\N	long	4413.272	4409.512	1	-3.76	-1	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	4409.512	12:03:56	3191793043	2026-09-07	12:17:32	4423.429	stop_loss	\N	\N	\N
7275ba5d-449b-4e95-a818-3867873c27c4	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-07	EURUSD	Forex	\N	\N	\N	long	1.16172	1.16191	1000	0.19	0.5588235294114958	\N	\N	\N	{}	2026-09-10 09:15:25.914051+00	1.16138	10:45:56	3191380713	2026-09-07	10:52:45	1.16191	take_profit	\N	\N	\N
afe808ae-b90c-47f8-b699-cc0606a88402	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-17	USTEC	Indices	\N	\N	\N	short	29110.94	29137.27	0.06	-1.58	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	29137.27	09:10:21	3242509872	2026-09-17	09:25:41	29002.68	stop_loss	\N	\N	\N
fa6afe50-17c6-4992-84ad-9f07741e2d6d	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-17	USTEC	Indices	\N	\N	\N	short	29112.69	29135.96	0.06	-1.4	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	29135.96	08:51:46	3242445911	2026-09-17	09:06:32	29001.07	stop_loss	\N	\N	\N
5ec7330c-3efb-4e15-acc9-3a6cdad79b50	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-16	XAUUSD	Metals	\N	\N	\N	long	4336.603	4329.798	1	-6.8	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	4329.798	10:15:14	3235210488	2026-09-16	10:53:41	4340.783	stop_loss	\N	\N	\N
d430bbf9-f43f-4595-b649-dc2b48181d3e	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-16	USTEC	Indices	\N	\N	\N	short	29102.2	29120.23	0.06	-1.08	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	29120.23	10:16:23	3235215347	2026-09-16	10:30:11	29024.78	stop_loss	\N	\N	\N
66d63d65-37c3-4992-a733-33f6df915e10	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-16	XAUUSD	Metals	\N	\N	\N	long	4335.581	4331.123	1	-4.46	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	4331.123	10:03:13	3235159413	2026-09-16	10:06:22	4354	stop_loss	\N	\N	\N
f373e7db-ca01-421c-a554-737e385a564c	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-16	USTEC	Indices	\N	\N	\N	short	29054.94	29103.32	0.06	-2.9	-1.1316959064327723	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	29097.69	09:27:54	3235039975	2026-09-16	10:00:12	29032.87	stop_loss	\N	\N	\N
7ec8db4e-e9c6-4c5b-a52e-f7a629e99167	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-15	USTEC	Indices	\N	\N	\N	short	29135.19	29075.3	0.07	4.19	1.4664544564152597	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	29176.03	16:51:05	3231639815	2026-09-15	17:15:56	29006.14	manual	\N	\N	\N
ff3b66eb-69e1-4206-97a3-2b0aa1491f81	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-15	XAUUSD	Metals	\N	\N	\N	short	4269.233	4266.947	1	2.28	2.6550522648088113	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	4268.372	11:40:17	3229937726	2026-09-15	11:53:11	4264.442	manual	\N	\N	\N
f15aee42-d70d-458b-87f5-f7f6d08b4a3c	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-15	UKOIL	\N	\N	\N	\N	long	104.526	104.351	0.01	-1.75	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	104.351	10:51:58	3229645965	2026-09-15	11:19:03	105.661	stop_loss	\N	\N	\N
fa8e6f5e-59f6-4aca-ad42-39e6bbd90160	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-15	UKOIL	\N	\N	\N	\N	long	104.481	104.17	0.01	-3.11	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	104.17	09:56:11	3229405683	2026-09-15	10:16:38	105.764	stop_loss	\N	\N	\N
6e350669-80a3-4f1e-9a3e-52691308340c	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-15	UKOIL	\N	\N	\N	\N	long	104.511	104.236	0.01	-2.75	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	104.236	10:11:45	3229464417	2026-09-15	10:16:24	104.872	stop_loss	\N	\N	\N
6065385e-c1bc-42f4-a11f-df1cb900f6c5	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-15	XAUUSD	Metals	\N	\N	\N	short	4294.177	4289.008	1	5.17	5.820945945946323	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	4295.065	08:50:15	3229200199	2026-09-15	09:05:58	4289.008	take_profit	\N	\N	\N
101c49ef-2eda-4eaf-8e1e-3a3c08ed169f	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-11	XAUUSD	Metals	\N	\N	\N	long	4353.31	4348.94	1	-4.37	-1	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	4348.94	09:40:23	3214375365	2026-09-11	10:22:40	4354.043	stop_loss	\N	\N	\N
7c2e45e4-43c9-429d-9f92-97aed8d34803	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-11	UKOIL	\N	\N	\N	\N	short	103.073	102.529	0.01	5.44	2.1935483870967207	\N	\N	\N	{}	2026-09-17 07:48:52.581162+00	103.321	09:52:32	3214420028	2026-09-11	10:10:15	102.529	take_profit	\N	\N	\N
53543df6-52a4-4e1e-9dfb-4bba325f06eb	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-18	XAUUSD	Metals	\N	\N	\N	long	4397.888	4392.529	1	-5.36	-1	\N	\N	\N	{}	2026-09-20 11:47:53.86538+00	4392.529	11:05:05	3248921198	2026-09-18	11:10:29	\N	stop_loss	\N	\N	\N
ad59dad4-dd21-447b-bd38-32051a9d0407	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-18	XAUUSD	Metals	\N	\N	\N	long	4396.179	4393.402	1	-2.78	-1	\N	\N	\N	{}	2026-09-20 11:47:53.86538+00	4393.402	10:30:39	3248776248	2026-09-18	10:31:50	\N	stop_loss	\N	\N	\N
9ef964bf-9be6-42fc-a129-dd7138b0af15	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-17	XAUUSD	Metals	\N	\N	\N	long	4371.035	4364.155	1	-6.88	-1	\N	\N	\N	{}	2026-09-20 11:47:53.86538+00	4364.155	17:25:02	3245535040	2026-09-17	17:32:11	4379.596	stop_loss	\N	\N	\N
afe5d741-e2fe-44bd-97ce-c5e63c450542	c7b56cc2-3d4a-43a8-b940-142c1b68c07c	2026-09-17	EURUSD	Forex	\N	\N	\N	long	1.14744	1.14715	5000	-1.45	-1	\N	\N	\N	{}	2026-09-20 11:47:53.86538+00	1.14715	12:01:36	3243256785	2026-09-17	12:53:30	1.14825	stop_loss	\N	\N	\N
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: backtest_run_feeds backtest_run_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backtest_run_feeds
    ADD CONSTRAINT backtest_run_feeds_pkey PRIMARY KEY (id);


--
-- Name: backtest_runs backtest_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backtest_runs
    ADD CONSTRAINT backtest_runs_pkey PRIMARY KEY (id);


--
-- Name: backtest_trades backtest_trades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backtest_trades
    ADD CONSTRAINT backtest_trades_pkey PRIMARY KEY (id);


--
-- Name: chart_symbol_overrides chart_symbol_overrides_account_id_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_symbol_overrides
    ADD CONSTRAINT chart_symbol_overrides_account_id_symbol_key UNIQUE (account_id, symbol);


--
-- Name: chart_symbol_overrides chart_symbol_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_symbol_overrides
    ADD CONSTRAINT chart_symbol_overrides_pkey PRIMARY KEY (id);


--
-- Name: dropdown_settings dropdown_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dropdown_settings
    ADD CONSTRAINT dropdown_settings_pkey PRIMARY KEY (id);


--
-- Name: exness_contract_overrides exness_contract_overrides_account_id_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_account_id_symbol_key UNIQUE (account_id, symbol);


--
-- Name: exness_contract_overrides exness_contract_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (id);


--
-- Name: accounts_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_name_unique ON public.accounts USING btree (lower(name));


--
-- Name: backtest_run_feeds_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backtest_run_feeds_run_idx ON public.backtest_run_feeds USING btree (run_id);


--
-- Name: backtest_runs_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backtest_runs_created_idx ON public.backtest_runs USING btree (created_at DESC);


--
-- Name: backtest_runs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backtest_runs_status_idx ON public.backtest_runs USING btree (status);


--
-- Name: backtest_trades_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backtest_trades_run_idx ON public.backtest_trades USING btree (run_id);


--
-- Name: chart_symbol_overrides_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chart_symbol_overrides_account_idx ON public.chart_symbol_overrides USING btree (account_id);


--
-- Name: exness_contract_overrides_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exness_contract_overrides_account_idx ON public.exness_contract_overrides USING btree (account_id);


--
-- Name: notes_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_account_idx ON public.notes USING btree (account_id);


--
-- Name: notes_linked_trade_ids_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_linked_trade_ids_idx ON public.notes USING gin (linked_trade_ids);


--
-- Name: notes_tags_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_tags_idx ON public.notes USING gin (tags);


--
-- Name: notes_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_updated_idx ON public.notes USING btree (account_id, updated_at DESC);


--
-- Name: trades_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_account_idx ON public.trades USING btree (account_id);


--
-- Name: trades_broker_ticket_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_broker_ticket_idx ON public.trades USING btree (account_id, broker_ticket);


--
-- Name: trades_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trades_date_idx ON public.trades USING btree (entry_date);


--
-- Name: backtest_run_feeds backtest_run_feeds_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backtest_run_feeds
    ADD CONSTRAINT backtest_run_feeds_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.backtest_runs(id) ON DELETE CASCADE;


--
-- Name: backtest_trades backtest_trades_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backtest_trades
    ADD CONSTRAINT backtest_trades_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.backtest_runs(id) ON DELETE CASCADE;


--
-- Name: chart_symbol_overrides chart_symbol_overrides_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_symbol_overrides
    ADD CONSTRAINT chart_symbol_overrides_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: dropdown_settings dropdown_settings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dropdown_settings
    ADD CONSTRAINT dropdown_settings_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: exness_contract_overrides exness_contract_overrides_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exness_contract_overrides
    ADD CONSTRAINT exness_contract_overrides_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: notes notes_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: trades trades_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts authenticated read/write accounts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write accounts" ON public.accounts USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: backtest_run_feeds authenticated read/write backtest_run_feeds; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write backtest_run_feeds" ON public.backtest_run_feeds USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: backtest_runs authenticated read/write backtest_runs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write backtest_runs" ON public.backtest_runs USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: backtest_trades authenticated read/write backtest_trades; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write backtest_trades" ON public.backtest_trades USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: chart_symbol_overrides authenticated read/write chart_symbol_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write chart_symbol_overrides" ON public.chart_symbol_overrides USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: dropdown_settings authenticated read/write dropdown_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write dropdown_settings" ON public.dropdown_settings USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: exness_contract_overrides authenticated read/write exness_contract_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write exness_contract_overrides" ON public.exness_contract_overrides USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: notes authenticated read/write notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write notes" ON public.notes USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: trades authenticated read/write trades; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated read/write trades" ON public.trades USING ((auth.role() = 'authenticated'::text)) WITH CHECK ((auth.role() = 'authenticated'::text));


--
-- Name: backtest_run_feeds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.backtest_run_feeds ENABLE ROW LEVEL SECURITY;

--
-- Name: backtest_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.backtest_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: backtest_trades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.backtest_trades ENABLE ROW LEVEL SECURITY;

--
-- Name: chart_symbol_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chart_symbol_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: dropdown_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dropdown_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: exness_contract_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.exness_contract_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: trades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict KlvLDgMmYvUnUCSEaGrQ4edhsPtiskah2wshbFAzPCUBC4tRBB9l7CiiN9Nzdzi

